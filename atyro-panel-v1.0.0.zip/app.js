// ================================================
// Minecraft Server Panel - Consolidated App.js
// ================================================
// Load environment variables from .env
require('dotenv').config();

// Dependencies
const express = require('express');
const session = require('express-session');
const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const { exec } = require('child_process');
const util = require('util');
const execAsync = util.promisify(exec);
const multer = require('multer');
const archiver = require('archiver');
const unzipper = require('unzipper');
const axios = require('axios');
const pidusage = require('pidusage');
const sanitize = require('sanitize-filename');
const zlib = require('zlib');
const prismarineNbt = require('prismarine-nbt');
const { promisify } = require('util');
const http = require('http');
const socketIo = require('socket.io');
const os = require('os');
const net = require('net'); // Added for IP validation
const flash = require('connect-flash');
const terminalColorParser = require('./utilities/terminal-color-parser');
// RCON removed - remote-only architecture uses remote node agent for RCON

// ================================================
// LOGGER - Console + File Logging
// ================================================
const LOGS_DIR = path.join(__dirname, 'logs');
const LATEST_LOG = path.join(LOGS_DIR, 'latest.log');

// Ensure logs directory exists
if (!fs.existsSync(LOGS_DIR)) {
  fs.mkdirSync(LOGS_DIR, { recursive: true });
}

// Create or open latest.log
if (!fs.existsSync(LATEST_LOG)) {
  fs.writeFileSync(LATEST_LOG, '');
}

class Logger {
  constructor() {
    this.logStream = fs.createWriteStream(LATEST_LOG, { flags: 'a' });
  }

  format(level, message, data = {}) {
    const timestamp = new Date().toISOString();
    const dataStr = Object.keys(data).length > 0 ? ` ${JSON.stringify(data)}` : '';
    return `[${timestamp}] [${level}] ${message}${dataStr}`;
  }

  writeToFile(message) {
    try {
      this.logStream.write(message + '\n');
    } catch (err) {
      // If file write fails, continue
    }
  }

  log(level, message, data = {}) {
    const formatted = this.format(level, message, data);
    console.log(formatted);
    this.writeToFile(formatted);
  }

  info(message, data = {}) {
    this.log('INFO', message, data);
  }

  warn(message, data = {}) {
    this.log('WARN', message, data);
  }

  error(message, data = {}) {
    this.log('ERROR', message, data);
  }

  debug(message, data = {}) {
    this.log('DEBUG', message, data);
  }

  success(message, data = {}) {
    this.log('SUCCESS', message, data);
  }

  expressMiddleware() {
    return (req, res, next) => {
      const start = Date.now();
      
      res.on('finish', () => {
        const duration = Date.now() - start;
        const method = req.method;
        const pathStr = req.path;
        const status = res.statusCode;
        
        if (status >= 400) {
          let levelName = status >= 500 ? 'ERROR' : 'WARN';
          this.log(levelName, `${method} ${pathStr}`, { status, duration: `${duration}ms` });
        }
      });
      
      next();
    };
  }

  close() {
    if (this.logStream) {
      this.logStream.end();
    }
  }
}

const logger = new Logger();
// NBT parsing - handle both callback and promise-based APIs with proper gzip handling
const nbtParse = (buffer) => new Promise((resolve, reject) => {
  // .dat files are gzip-compressed, decompress first
  zlib.gunzip(buffer, (err, decompressed) => {
    if (err) {
      // If gzip fails, try parsing as raw NBT
      return prismarineNbt.parse(buffer, 'big', (err, data) => {
        if (err) return reject(err);
        if (!data || !data.value) return reject(new Error('NBT parser returned an empty root tag'));
        resolve(data);
      });
    }
    // Parse decompressed NBT
    prismarineNbt.parse(decompressed, 'big', (err, data) => {
      if (err) return reject(err);
      if (!data || !data.value) return reject(new Error('NBT parser returned an empty root tag'));
      resolve(data);
    });
  });
});
// Initialize Express app
const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  pingInterval: 30000,
  pingTimeout: 10000,
  transports: ['polling', 'websocket'],  // Try polling first, then WebSocket
  cors: { origin: "*" },
  allowEIO3: true  // Support older Socket.IO clients
});
const router = express.Router();
// Configuration
const port = process.env.PORT || 3000;
const DATA_DIR = __dirname;
const DB_PATH = path.join(DATA_DIR, 'database.db');

// ================================================
// MIDDLEWARE SETUP
// ================================================
app.use(express.json({ limit: '200mb' }));
app.use(express.urlencoded({ limit: '200mb', extended: true }));
app.use(logger.expressMiddleware()); // ✅ Add logger middleware
app.use(flash());
app.use(express.static(path.join(__dirname, 'public')));
// Server-rendered pages must never come from browser cache — a stale form
// (e.g. startup toggles) silently submits wrong data.
app.use((req, res, next) => {
    if (req.accepts('html')) {
        res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
        res.set('Pragma', 'no-cache');
        res.set('Expires', '0');
    }
    next();
});
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
// Global state
const serverStartTimes = {};
const onlinePlayers = {};
const serverLogWatchers = {};

// ================================================
// COLOR STRIPPING FUNCTION (Pterodactyl-style)
// ================================================
// Remove ALL color codes from console output before emitting to clients
// Server sends ONLY clean text; client applies colors based on log level
function stripAllColors(text) {
  if (!text) return '';
  
  let cleaned = String(text);
  
  // Remove Minecraft color codes (§0-§f for colors, §k-§o for formatting, §r for reset)
  cleaned = cleaned.replace(/§[0-9a-fk-orx]/gi, '');
  
  // Remove ANSI escape sequences
  // Handles: \x1b[...m, \u001b[...m, [38;2;...m (RGB), [38;5;...m (256-color), etc.
  cleaned = cleaned.replace(/\x1b\[[0-9;]*m/g, '');          // Standard ANSI
  cleaned = cleaned.replace(/\u001b\[[0-9;]*m/g, '');        // Unicode variant
  cleaned = cleaned.replace(/\[38;2;[0-9;]*m/g, '');         // RGB ANSI (fallback)
  cleaned = cleaned.replace(/\[38;5;[0-9;]*m/g, '');         // 256-color ANSI (fallback)
  cleaned = cleaned.replace(/\[[0-9;]*m/g, '');              // Bracket-only variant
  
  // Remove other ANSI control sequences
  cleaned = cleaned.replace(/\x1b\[[^m]*m/g, '');            // Comprehensive ANSI
  
  // Trim whitespace
  cleaned = cleaned.trim();
  
  return cleaned;
}

// ================================================
// UNIFIED LOG DEDUPLICATION CACHE (Pterodactyl-style)
// ================================================
// Global dedup cache: serverLogDedupCache[serverId] = Map of normalized line hashes
// Each entry tracks: hash -> { normalized, timestamp }
// Keep last 500 lines per server, 10-minute rolling window
const serverLogDedupCache = {};

function initDedupCache(serverId) {
  if (!serverLogDedupCache[serverId]) {
    serverLogDedupCache[serverId] = {
      cache: new Map(),  // hash -> { normalized, timestamp }
      maxSize: 500
    };
  }
}

function normalizeLogLine(line) {
  // Extract core message by removing timestamp and thread info variations
  // Handles formats like:
  // [04:20:06] [Server thread/INFO]: message
  // [04:20:06 INFO]: message
  // [info] message
  // [Server thread/INFO]: message (without time)
  let normalized = String(line || '').trim();
  
  // Remove ALL timestamp patterns - be VERY aggressive
  // [HH:MM:SS], [HH:MM:SS.mmm], [HH:MM:SS anything]
  normalized = normalized.replace(/^\[\d{1,2}:\d{2}:\d{2}[^\]]*\]\s*/i, '');
  // ISO dates [YYYY-MM-DD HH:MM:SS...]
  normalized = normalized.replace(/^\[\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}[^\]]*\]\s*/i, '');
  
  // Remove thread info with log level: [Server thread/INFO]:, [Server thread/WARN]:, etc.
  normalized = normalized.replace(/^\[[^\]]*\/[A-Z]+\]:\s*/i, '');
  // Remove just log level with colon: [INFO]:, [WARN]:, [ERROR]:, [DEBUG]:
  normalized = normalized.replace(/^\[[A-Z]+\]:\s*/i, '');
  // Remove any remaining brackets at start: [anything]:
  normalized = normalized.replace(/^\[[^\]]*\]:\s*/i, '');
  
  // Remove standalone colon at start
  normalized = normalized.replace(/^\s*:\s*/, '');
  
  // Remove common prefixes like "ℹ️" or other unicode symbols
  normalized = normalized.replace(/^[\s\p{So}\p{Sk}]+/u, '');
  
  // Collapse multiple spaces to single space
  normalized = normalized.replace(/\s+/g, ' ').trim();
  
  // Lowercase for case-insensitive comparison
  normalized = normalized.toLowerCase();
  
  return normalized;
}

function createLineHash(normalized) {
  // Simple hash function for dedup checking
  let hash = 0;
  for (let i = 0; i < normalized.length; i++) {
    const char = normalized.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32-bit
  }
  return Math.abs(hash).toString(36); // Base36 for compact string
}

function isDuplicateLogLine(serverId, line) {
  initDedupCache(serverId);
  const cache = serverLogDedupCache[serverId];
  const now = Date.now();
  
  // Normalize the line: remove timestamps and thread info but KEEP ANSI codes
  const normalized = normalizeLogLine(line);
  if (!normalized) return false; // Empty lines always go through
  
  const hash = createLineHash(normalized);
  
  // Check if we've seen this normalized content recently
  const existing = cache.cache.get(hash);
  if (existing && (now - existing.timestamp) < 60000) {
    // We've seen this line before within 60 seconds
    // Check if this version is better (has ANSI codes when previous didn't)
    const currentHasAnsi = /\x1b\[|\[38;2;|\[38;5;|\[0m/.test(line);
    
    if (!currentHasAnsi && existing.hasAnsi) {
      // Current is plain-text, previous was formatted → FILTER this one (keep formatted)
      return true; // IS DUPLICATE - skip it
    }
    
    // If both are same type or current is upgraded (has ANSI when previous didn't), it might be legitimate
    // But for most cases where timestamps differ, filter it
    if (currentHasAnsi === existing.hasAnsi) {
      // Both same type → likely duplicate
      return true; // IS DUPLICATE - skip it
    }
  }
  
  // Not a duplicate - record this version
  cache.cache.set(hash, {
    normalized,
    timestamp: now,
    hasAnsi: /\x1b\[|\[38;2;|\[38;5;|\[0m/.test(line)
  });
  
  // Cleanup old entries to prevent memory bloat
  if (cache.cache.size > cache.maxSize) {
    let oldest = null;
    let oldestTime = Infinity;
    
    for (const [k, v] of cache.cache.entries()) {
      if (v.timestamp < oldestTime) {
        oldestTime = v.timestamp;
        oldest = k;
      }
    }
    
    if (oldest) cache.cache.delete(oldest);
  }
  
  return false; // NOT DUPLICATE - allow it through
}

// ================================================
// SERVER SOFTWARE MANAGEMENT SYSTEM
// ================================================

// Comprehensive server software definitions
const SERVER_SOFTWARE = {
    // Java Edition Servers
    vanilla: {
        name: 'Vanilla',
        description: 'Official Minecraft server software from Mojang',
        category: 'Java Edition',
        icon: 'fas fa-cube',
        color: '#8B4513',
        downloadUrl: 'https://launcher.mojang.com/v1/objects/{hash}/server.jar',
        manifestUrl: 'https://launchermeta.mojang.com/mc/game/version_manifest.json',
        supports: ['plugins: false', 'mods: false', 'datapacks: true']
    },
paper: {
    name: 'Paper',
    description: 'High-performance Spigot fork with optimizations, bug fixes, and advanced server performance',
    category: 'Java Edition',
    icon: 'fas fa-scroll',
    color: '#2196F3',

    // PaperMC Downloads API v3
    manifestUrl: 'https://fill.papermc.io/v3/projects/paper',

    // Fetch available builds for the selected Minecraft version.
    buildsUrl: 'https://fill.papermc.io/v3/projects/paper/versions/{version}/builds',

    // Fetch the actual JAR URL from the selected build's API response.
    downloadUrl: 'https://fill.papermc.io/v3/projects/paper/versions/{version}/builds',

    supports: {
        plugins: true,
        mods: false,
        datapacks: true
    }
},
    purpur: {
        name: 'Purpur',
        description: 'Paper fork with additional features and configuration options',
        category: 'Java Edition',
        icon: 'fas fa-gem',
        color: '#9C27B0',
        downloadUrl: 'https://api.purpurmc.org/v2/purpur/{version}/latest/download',
        manifestUrl: 'https://api.purpurmc.org/v2/purpur',
        supports: ['plugins: true', 'mods: false', 'datapacks: true']
    },
    spigot: {
        name: 'Spigot',
        description: 'Popular server software with plugin support and performance improvements',
        category: 'Java Edition',
        icon: 'fas fa-fire',
        color: '#FF9800',
        downloadUrl: 'https://hub.spigotmc.org/jenkins/job/BuildTools/lastSuccessfulBuild/artifact/target/BuildTools.jar',
        manifestUrl: null, // Requires BuildTools
        supports: ['plugins: true', 'mods: false', 'datapacks: true']
    },
    bukkit: {
        name: 'CraftBukkit',
        description: 'Original modded server software with plugin API',
        category: 'Java Edition',
        icon: 'fas fa-hammer',
        color: '#795548',
        downloadUrl: 'https://hub.spigotmc.org/jenkins/job/BuildTools/lastSuccessfulBuild/artifact/target/BuildTools.jar',
        manifestUrl: null, // Requires BuildTools
        supports: ['plugins: true', 'mods: false', 'datapacks: true']
    },
    fabric: {
        name: 'Fabric',
        description: 'Lightweight modding platform for modern Minecraft versions',
        category: 'Java Edition',
        icon: 'fas fa-thread',
        color: '#4CAF50',
        downloadUrl: 'https://meta.fabricmc.net/v2/versions/loader/{version}/{loader}/server/jar',
        manifestUrl: 'https://meta.fabricmc.net/v2/versions/game',
        supports: ['plugins: false', 'mods: true', 'datapacks: true']
    },
    forge: {
        name: 'Forge',
        description: 'Popular modding platform with extensive mod ecosystem',
        category: 'Java Edition',
        icon: 'fas fa-anvil',
        color: '#FF5722',
        downloadUrl: 'https://maven.minecraftforge.net/net/minecraftforge/forge/{version}/forge-{version}-installer.jar',
        manifestUrl: 'https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json',
        supports: ['plugins: false', 'mods: true', 'datapacks: true']
    },
    quilt: {
        name: 'Quilt',
        description: 'Modern modding platform forked from Fabric with enhanced features',
        category: 'Java Edition',
        icon: 'fas fa-puzzle-piece',
        color: '#673AB7',
        downloadUrl: 'https://meta.quiltmc.org/v3/versions/loader/{version}/{loader}/server/jar',
        manifestUrl: 'https://meta.quiltmc.org/v3/versions/game',
        supports: ['plugins: false', 'mods: true', 'datapacks: true']
    },
    
    // Proxy Servers
    velocity: {
        name: 'Velocity',
        description: 'Modern, high-performance Minecraft proxy server',
        category: 'Proxy Servers',
        icon: 'fas fa-rocket',
        color: '#00BCD4',
        downloadUrl: 'https://api.papermc.io/v2/projects/velocity/versions/{version}/builds/{build}/downloads/velocity-{version}-{build}.jar',
        manifestUrl: 'https://api.papermc.io/v2/projects/velocity',
        supports: ['plugins: true', 'networks: true', 'modern: true']
    },
    bungeecord: {
        name: 'BungeeCord',
        description: 'Popular proxy server for connecting multiple Minecraft servers',
        category: 'Proxy Servers',
        icon: 'fas fa-network-wired',
        color: '#FF6B35',
        downloadUrl: 'https://ci.md-5.net/job/BungeeCord/lastSuccessfulBuild/artifact/bootstrap/target/BungeeCord.jar',
        manifestUrl: null, // Uses CI builds
        supports: ['plugins: true', 'networks: true', 'legacy: true']
    },
    waterfall: {
        name: 'Waterfall',
        description: 'Paper fork of BungeeCord with performance improvements',
        category: 'Proxy Servers',
        icon: 'fas fa-water',
        color: '#2196F3',
        downloadUrl: 'https://api.papermc.io/v2/projects/waterfall/versions/{version}/builds/{build}/downloads/waterfall-{version}-{build}.jar',
        manifestUrl: 'https://api.papermc.io/v2/projects/waterfall',
        supports: ['plugins: true', 'networks: true', 'optimized: true']
    }
};

// Enhanced version fetching with comprehensive support and complete version history
async function fetchMinecraftVersions(serverType = 'vanilla', limit = null) {
    try {
        const software = SERVER_SOFTWARE[serverType];
        let versions = [];
        
        switch (serverType) {
            case 'vanilla':
                try {
                    const vanillaResponse = await axios.get(software.manifestUrl, { timeout: 10000 });
                    versions = vanillaResponse.data.versions
                        .filter(v => v.type === 'release')
                        .map(v => v.id);
                } catch (err) {
                    console.error('Error fetching vanilla versions:', err.message);
                    versions = getCompleteMinecraftVersions();
                }
                break;
                
            case 'paper':
            case 'waterfall':
            case 'velocity':
                try {
                    const userAgent = 'MinecraftPanel/1.0.0 (https://github.com/your-repo)';
                    const paperResponse = (await axios.get(`https://fill.papermc.io/v3/projects/${serverType}`, { 
                        timeout: 10000,
                        headers: { 'User-Agent': userAgent }
                    })).data;
                    
                    if (paperResponse.versions) {
                        // versions is an object with version groups, flatten them
                        const allVersions = [];
                        Object.values(paperResponse.versions).forEach(group => {
                            if (Array.isArray(group)) {
                                allVersions.push(...group);
                            }
                        });
                        versions = allVersions;
                    }
                } catch (err) {
                    console.error(`Error fetching ${serverType} versions:`, err.message);
                    versions = getCommonModernVersions();
                }
                break;
                
            case 'purpur':
                try {
                    const purpurResponse = await axios.get(software.manifestUrl, { timeout: 10000 });
                    versions = purpurResponse.data.versions.reverse();
                } catch (err) {
                    console.error('Error fetching purpur versions:', err.message);
                    versions = getCommonModernVersions();
                }
                break;
                
            case 'fabric':
            case 'quilt':
                try {
                    const fabricResponse = await axios.get(software.manifestUrl, { timeout: 10000 });
                    versions = fabricResponse.data
                        .filter(v => v.stable)
                        .map(v => v.version);
                } catch (err) {
                    console.error(`Error fetching ${serverType} versions:`, err.message);
                    versions = getCommonModernVersions();
                }
                break;
                
            case 'forge':
                try {
                    const forgeResponse = await axios.get(software.manifestUrl, { timeout: 10000 });
                    const promos = forgeResponse.data.promos;
                    versions = Object.keys(promos)
                        .filter(key => key.includes('-recommended') || key.includes('-latest'))
                        .map(key => key.split('-')[0])
                        .filter((v, i, arr) => arr.indexOf(v) === i) // Remove duplicates
                        .sort((a, b) => compareVersions(b, a)); // Sort newest first
                } catch (err) {
                    console.error('Error fetching forge versions:', err.message);
                    versions = getForgeCompatibleVersions();
                }
                break;
                
            case 'mohist':
                try {
                    const mohistResponse = await axios.get(software.manifestUrl, { timeout: 10000 });
                    versions = mohistResponse.data.versions.reverse();
                } catch (err) {
                    console.error('Error fetching mohist versions:', err.message);
                    versions = getCommonModernVersions();
                }
                break;
                
            case 'spigot':
            case 'bukkit':
                // Spigot/Bukkit use BuildTools, so we provide common versions
                versions = getSpigotCompatibleVersions();
                break;
                
            case 'bungeecord':
                // BungeeCord is version-independent but we show compatible MC versions
                versions = getProxyCompatibleVersions();
                break;
                
            default:
                versions = getCompleteMinecraftVersions();
        }
        
        // Apply limit if specified
        if (limit && limit > 0 && versions.length > limit) {
            versions = versions.slice(0, limit);
        }
        
        return versions.length > 0 ? versions : getCompleteMinecraftVersions();
        
    } catch (err) {
        console.error(`Error fetching versions for ${serverType}:`, err.message);
        return getCompleteMinecraftVersions();
    }
}

// Fetch builds (with build numbers) for a specific version
async function fetchVersionBuilds(serverType = 'paper', version = 'latest') {
    try {
        const software = SERVER_SOFTWARE[serverType];
        if (!software || !software.manifestUrl) {
            return [];
        }
        
        let builds = [];
        const userAgent = 'MinecraftPanel/1.0.0 (https://github.com/your-repo)';
        
        switch (serverType) {
            case 'paper':
            case 'waterfall':
            case 'velocity':
                try {
                    // First, get the version if 'latest' was specified
                    let targetVersion = version;
                    if (version === 'latest') {
                        const versionsResp = (await axios.get(`https://fill.papermc.io/v3/projects/${serverType}`, { 
                            timeout: 10000,
                            headers: { 'User-Agent': userAgent }
                        })).data;
                        
                        if (versionsResp.versions) {
                            const allVersions = [];
                            Object.values(versionsResp.versions).forEach(group => {
                                if (Array.isArray(group)) {
                                    allVersions.push(...group);
                                }
                            });
                            
                            if (allVersions.length > 0) {
                                targetVersion = allVersions[0];
                            }
                        }
                    }
                    
                    // Now fetch builds for this version
                    const buildsResp = (await axios.get(`https://fill.papermc.io/v3/projects/${serverType}/versions/${targetVersion}/builds`, { 
                        timeout: 10000,
                        headers: { 'User-Agent': userAgent }
                    })).data;
                    
                    if (Array.isArray(buildsResp) && buildsResp.length > 0) {
                        builds = buildsResp
                            .slice(0, 20) // Show last 20 builds
                            .map(b => ({
                                version: targetVersion,
                                build: b.id,
                                channel: b.channel || 'default',
                                timestamp: b.created?.date || null,
                                downloads: b.downloads ? Object.keys(b.downloads).length : 0
                            }));
                    }
                } catch (err) {
                    console.error(`Error fetching ${serverType} builds for ${version}:`, err.message);
                }
                break;
                
            case 'purpur':
                try {
                    let targetVersion = version;
                    if (version === 'latest') {
                        const versionsResp = (await axios.get('https://api.purpurmc.org/v2/purpur', { timeout: 10000 })).data;
                        if (versionsResp.versions && versionsResp.versions.length > 0) {
                            targetVersion = versionsResp.versions[versionsResp.versions.length - 1];
                        }
                    }
                    
                    const latestResp = (await axios.get(`https://api.purpurmc.org/v2/purpur/${targetVersion}/latest`, { timeout: 10000 })).data;
                    
                    if (latestResp && latestResp.build) {
                        builds = [{
                            version: targetVersion,
                            build: latestResp.build,
                            channel: 'latest',
                            timestamp: latestResp.timestamp || null,
                            downloads: 1
                        }];
                    }
                } catch (err) {
                    console.error(`Error fetching Purpur builds for ${version}:`, err.message);
                }
                break;
        }
        
        return builds;
    } catch (err) {
        console.error(`Error fetching builds for ${serverType}:`, err.message);
        return [];
    }
}


function getCompleteMinecraftVersions() {
    return [
        // Latest versions (1.21+)
        '1.21.11', '1.21.10', '1.21.9', '1.21.8', '1.21.7', '1.21.6', '1.21.5', '1.21.4', '1.21.3', '1.21.2', '1.21.1', '1.21',
        '1.20.6', '1.20.5', '1.20.4', '1.20.3', '1.20.2', '1.20.1', '1.20',
        
        // 1.19.x series
        '1.19.4', '1.19.3', '1.19.2', '1.19.1', '1.19',
        
        // 1.18.x series
        '1.18.2', '1.18.1', '1.18',
        
        // 1.17.x series
        '1.17.1', '1.17',
        
        // 1.16.x series (very popular)
        '1.16.5', '1.16.4', '1.16.3', '1.16.2', '1.16.1', '1.16',
        
        // 1.15.x series
        '1.15.2', '1.15.1', '1.15',
        
        // 1.14.x series
        '1.14.4', '1.14.3', '1.14.2', '1.14.1', '1.14',
        
        // 1.13.x series
        '1.13.2', '1.13.1', '1.13',
        
        // 1.12.x series (very popular for mods)
        '1.12.2', '1.12.1', '1.12',
        
        // 1.11.x series
        '1.11.2', '1.11.1', '1.11',
        
        // 1.10.x series
        '1.10.2', '1.10.1', '1.10',
        
        // 1.9.x series
        '1.9.4', '1.9.3', '1.9.2', '1.9.1', '1.9',
        
        // 1.8.x series (very popular for PvP)
        '1.8.9', '1.8.8', '1.8.7', '1.8.6', '1.8.5', '1.8.4', '1.8.3', '1.8.2', '1.8.1', '1.8',
        
        // 1.7.x series (legacy but still used)
        '1.7.10', '1.7.9', '1.7.8', '1.7.7', '1.7.6', '1.7.5', '1.7.4', '1.7.2',
        
        // Older versions (for historical servers)
        '1.6.4', '1.6.2', '1.6.1',
        '1.5.2', '1.5.1',
        '1.4.7', '1.4.6', '1.4.5', '1.4.4', '1.4.2',
        '1.3.2', '1.3.1',
        '1.2.5', '1.2.4', '1.2.3', '1.2.1',
        '1.1', '1.0'
    ];
}

// Modern versions (1.16+) for newer server software
function getCommonModernVersions() {
    return [
        '1.21.4', '1.21.3', '1.21.2', '1.21.1', '1.21',
        '1.20.6', '1.20.5', '1.20.4', '1.20.3', '1.20.2', '1.20.1', '1.20',
        '1.19.4', '1.19.3', '1.19.2', '1.19.1', '1.19',
        '1.18.2', '1.18.1', '1.18',
        '1.17.1', '1.17',
        '1.16.5', '1.16.4', '1.16.3', '1.16.2', '1.16.1', '1.16'
    ];
}

// Forge-compatible versions (popular modding versions)
function getForgeCompatibleVersions() {
    return [
        '1.21.1', '1.21', '1.20.6', '1.20.4', '1.20.1', '1.20',
        '1.19.4', '1.19.2', '1.19', '1.18.2', '1.18.1', '1.17.1',
        '1.16.5', '1.16.4', '1.16.3', '1.16.1', '1.15.2', '1.14.4',
        '1.13.2', '1.12.2', '1.11.2', '1.10.2', '1.9.4', '1.8.9', '1.7.10'
    ];
}

// Spigot-compatible versions
function getSpigotCompatibleVersions() {
    return [
        '1.21.4', '1.21.3', '1.21.2', '1.21.1', '1.21',
        '1.20.6', '1.20.4', '1.20.2', '1.20.1', '1.20',
        '1.19.4', '1.19.3', '1.19.2', '1.19.1', '1.19',
        '1.18.2', '1.18.1', '1.18', '1.17.1', '1.17',
        '1.16.5', '1.16.4', '1.16.3', '1.16.2', '1.16.1',
        '1.15.2', '1.15.1', '1.14.4', '1.13.2', '1.12.2',
        '1.11.2', '1.10.2', '1.9.4', '1.8.8'
    ];
}

// Proxy-compatible versions (shows MC versions the proxy supports)
function getProxyCompatibleVersions() {
    return [
        '1.21.x', '1.20.x', '1.19.x', '1.18.x', '1.17.x', '1.16.x',
        '1.15.x', '1.14.x', '1.13.x', '1.12.x', '1.11.x', '1.10.x',
        '1.9.x', '1.8.x', '1.7.x'
    ];
}

// Version comparison utility
function compareVersions(a, b) {
    const aParts = a.split('.').map(Number);
    const bParts = b.split('.').map(Number);
    
    for (let i = 0; i < Math.max(aParts.length, bParts.length); i++) {
        const aPart = aParts[i] || 0;
        const bPart = bParts[i] || 0;
        
        if (aPart > bPart) return 1;
        if (aPart < bPart) return -1;
    }
    
    return 0;
}

// Validate custom version format
function isValidMinecraftVersion(version) {
    // Allow standard version formats
    const patterns = [
        /^\d+\.\d+(\.\d+)?$/, // 1.20.1, 1.20, etc.
        /^\d+\.\d+\.\d+-\w+$/, // 1.20.1-pre1, 1.20.1-rc1
        /^\d+w\d+[a-z]$/, // 20w14a (snapshots)
        /^latest$/i, // "latest"
        /^snapshot$/i // "snapshot"
    ];
    
    return patterns.some(pattern => pattern.test(version.trim()));
}

// Get all available server software organized by category
function getAvailableServerSoftware() {
    const categories = {};
    
    Object.entries(SERVER_SOFTWARE).forEach(([key, software]) => {
        if (!categories[software.category]) {
            categories[software.category] = [];
        }
        categories[software.category].push({
            key,
            ...software
        });
    });
    
    return categories;
}
function saveServerStartTime(serverId, startTime) {
  // Remote-only architecture: server start time is managed by remote node agent
  console.log(`ℹ️ [Remote-Only] Server start time tracking managed by remote node for server ${serverId}`);
}

function loadServerStartTime(serverId) {
  try {
    // Remote-only architecture: start times are managed by remote node
    // This function is deprecated but kept for compatibility
    return null;
  } catch (err) {
    console.error(`Failed to load start time for server ${serverId}:`, err.message);
    return null;
  }
}

function deleteServerStartTime(serverId) {
  // Remote-only architecture: server start time is managed by remote node agent
  console.log(`ℹ️ [Remote-Only] Server start time cleanup managed by remote node for server ${serverId}`);
}
const serverLogPositions = {};
let globalSettings = {
    registrationEnabled: true,
    panelName: 'Atyro Panel',
    panelDescription: 'Powerful Minecraft Server Management',
    siteIcon: '/logo.png',
    headerIcon: '/logo.png',
    footerText: '© 2026 Atyro Panel',
    theme: 'default'
};
// Legacy keys removed from the panel; stripped again after the DB load below
// so old panel_settings rows cannot resurrect them.
const RETIRED_SETTING_KEYS = ['maxServersPerUser', 'defaultRam', 'defaultPort'];
// Live stats cache (Pterodactyl-style real-time monitoring)
const liveStats = {};
// Initialize database
const db = new sqlite3.Database(DB_PATH, (err) => {
    if (err) {
        logger.error('Failed to open database:', { error: err.message });
        process.exit(1);
    }
    logger.success('Connected to SQLite database');
});

// Create tables
db.serialize(() => {
    // Users table
    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT DEFAULT 'user',
        status TEXT DEFAULT 'active',
        display_name TEXT,
        profile_picture TEXT,
        theme_preference TEXT DEFAULT 'dark',
        theme_primary_color TEXT DEFAULT '#2d6a4f',
        theme_accent_color TEXT DEFAULT '#40916c',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);
    
    // Notifications table
    db.run(`CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        type TEXT DEFAULT 'info',
        icon TEXT DEFAULT 'info-circle',
        is_read BOOLEAN DEFAULT 0,
        action_url TEXT,
        action_text TEXT,
        server_id INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id),
        FOREIGN KEY (server_id) REFERENCES servers (id)
    )`);
    
    // User profiles table for extended user information
    db.run(`CREATE TABLE IF NOT EXISTS user_profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL UNIQUE,
        display_name TEXT,
        bio TEXT,
        location TEXT,
        website TEXT,
        profile_picture TEXT,
        theme_preference TEXT DEFAULT 'dark',
        theme_primary_color TEXT DEFAULT '#2d6a4f',
        theme_accent_color TEXT DEFAULT '#40916c',
        language TEXT DEFAULT 'en',
        timezone TEXT DEFAULT 'UTC',
        email_notifications BOOLEAN DEFAULT 1,
        push_notifications BOOLEAN DEFAULT 1,
        security_notifications BOOLEAN DEFAULT 1,
        notification_frequency TEXT DEFAULT 'immediate',
        quiet_hours_start TEXT,
        quiet_hours_end TEXT,
        two_factor_enabled BOOLEAN DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    )`);
    
    // Notification preferences table
    db.run(`CREATE TABLE IF NOT EXISTS notification_preferences (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        category TEXT NOT NULL,
        enabled BOOLEAN DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
        UNIQUE(user_id, category)
    )`);
    
    // User activity table for tracking user actions
    db.run(`CREATE TABLE IF NOT EXISTS user_activity (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        action TEXT NOT NULL,
        description TEXT,
        ip_address TEXT,
        user_agent TEXT,
        metadata TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    )`);
    
    // Update notifications table to include category and metadata
    db.run('ALTER TABLE notifications ADD COLUMN category TEXT DEFAULT "general"', (err) => {
        if (err && !err.message.includes('duplicate column name')) {
            console.error('Error adding category column to notifications:', err.message);
        }
    });
    
    db.run('ALTER TABLE notifications ADD COLUMN metadata TEXT', (err) => {
        if (err && !err.message.includes('duplicate column name')) {
            console.error('Error adding metadata column to notifications:', err.message);
        }
    });
    
    db.run('ALTER TABLE notifications ADD COLUMN updated_at DATETIME DEFAULT CURRENT_TIMESTAMP', (err) => {
        if (err && !err.message.includes('duplicate column name')) {
            console.error('Error adding updated_at column to notifications:', err.message);
        }
    });
    
    // Servers table (added server_ip, ip_alias, port_alias, additional_ports)
    db.run(`CREATE TABLE IF NOT EXISTS servers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        owner_id INTEGER NOT NULL,
        ram INTEGER NOT NULL,
        cpu INTEGER DEFAULT 1,
        disk INTEGER DEFAULT 1024,
        port INTEGER NOT NULL,
        server_ip TEXT DEFAULT '',
        ip_alias TEXT,
        port_alias TEXT,
        additional_ports TEXT DEFAULT '[]',
        status TEXT DEFAULT 'stopped',
        version TEXT DEFAULT 'latest',
        server_type TEXT DEFAULT 'vanilla',
        node_id INTEGER,
        settings TEXT DEFAULT '{}',
        startup_command TEXT DEFAULT 'java -Xms{xms}M -Xmx{ram}M -jar server.jar nogui',
        backup_limit INTEGER DEFAULT 10,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (owner_id) REFERENCES users (id)
    )`);
    
    // FIX: Ensure all existing servers have a valid disk value (not NULL or 0)
    db.run(`UPDATE servers SET disk = 10240 WHERE disk IS NULL OR disk = 0`, function(err) {
        if (err) {
            console.error('Failed to fix disk values:', err);
        } else if (this.changes > 0) {
            console.log(`✅ Fixed ${this.changes} servers with invalid disk values (set to 10240 MB = 10GB)`);
        }
    });
    
    // ADD startup_command column if it doesn't exist
    db.run(`ALTER TABLE servers ADD COLUMN startup_command TEXT DEFAULT 'java -Xms{xms}M -Xmx{ram}M -jar server.jar nogui'`, function(err) {
        if (err && err.message.includes('duplicate column')) {
            // Column already exists, that's fine
        } else if (err) {
            console.error('Error adding startup_command column:', err);
        } else {
            console.log('✅ Added startup_command column to servers table');
        }
    });
    
    // ADD backup_limit column if it doesn't exist
    db.run(`ALTER TABLE servers ADD COLUMN backup_limit INTEGER DEFAULT 10`, function(err) {
        if (err && err.message.includes('duplicate column')) {
            // Column already exists, that's fine
        } else if (err) {
            console.error('Error adding backup_limit column:', err);
        } else {
            console.log('✅ Added backup_limit column to servers table');
        }
    });
    
    // CLEANUP: Remove old start.sh and startup.sh files from server folders
    // These are no longer needed since startup command is now stored in database
    try {
        const serversDir = path.join(__dirname, 'daemon', 'servers');
        if (fs.existsSync(serversDir)) {
            const serverFolders = fs.readdirSync(serversDir);
            let cleanedCount = 0;
            
            serverFolders.forEach(folder => {
                const serverPath = path.join(serversDir, folder);
                const startShPath = path.join(serverPath, 'start.sh');
                const startupShPath = path.join(serverPath, 'startup.sh');
                
                // Remove start.sh if it exists
                if (fs.existsSync(startShPath)) {
                    try {
                        fs.unlinkSync(startShPath);
                        cleanedCount++;
                        console.log(`🧹 Removed start.sh from server ${folder}`);
                    } catch (err) {
                        console.warn(`Failed to remove start.sh from server ${folder}:`, err.message);
                    }
                }
                
                // Remove startup.sh if it exists
                if (fs.existsSync(startupShPath)) {
                    try {
                        fs.unlinkSync(startupShPath);
                        cleanedCount++;
                        console.log(`🧹 Removed startup.sh from server ${folder}`);
                    } catch (err) {
                        console.warn(`Failed to remove startup.sh from server ${folder}:`, err.message);
                    }
                }
            });
            
            if (cleanedCount > 0) {
                console.log(`✅ Cleaned up ${cleanedCount} startup script files from server folders`);
            }
        }
    } catch (cleanupErr) {
        console.warn('Error cleaning up startup files:', cleanupErr.message);
    }
    
    // Subusers table
    db.run(`CREATE TABLE IF NOT EXISTS subusers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        server_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        permissions TEXT DEFAULT '[]',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (server_id) REFERENCES servers(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
    )`);
    // Backups table
    db.run(`CREATE TABLE IF NOT EXISTS backups (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        server_id INTEGER NOT NULL,
        file TEXT NOT NULL,
        name TEXT,
        description TEXT,
        size TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (server_id) REFERENCES servers(id)
    )`);
    // File logs table
    db.run(`CREATE TABLE IF NOT EXISTS file_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        server_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        action TEXT NOT NULL,
        file_path TEXT NOT NULL,
        details TEXT DEFAULT '{}',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (server_id) REFERENCES servers(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
    )`);
    // Global settings table
    db.run(`CREATE TABLE IF NOT EXISTS panel_settings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        key TEXT UNIQUE NOT NULL,
        value TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);
    // Create admin user if not exists
    db.get('SELECT * FROM users WHERE username = ?', ['admin'], (err, row) => {
        if (err) console.error('Error checking admin:', err);
        if (!row) {
            const hashedPassword = bcrypt.hashSync('admin123', 10);
            db.run('INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)',
                ['admin', 'admin@example.com', hashedPassword, 'admin'],
                (err) => {
                    if (err) console.error('Error creating admin:', err);
                    else console.log('Admin user created (username: admin, password: admin123)');
                }
            );
        }
    });
    // Load global settings from database
    db.all('SELECT * FROM panel_settings', (err, rows) => {
        if (!err && rows) {
            rows.forEach(row => {
                if (RETIRED_SETTING_KEYS.includes(row.key)) return;
                try {
                    globalSettings[row.key] = JSON.parse(row.value);
                } catch {
                    globalSettings[row.key] = row.value;
                }
            });
        }
    });
    
    // All servers are now handled by remote nodes
    console.log('✅ Panel initialized - all servers managed by remote nodes');
});
// Restore running servers after DB init
async function restoreServers() {
    const servers = await dbAll('SELECT id, status FROM servers');
    for (const { id, status } of servers) {
        const isRunning = await isServerRunning(id);
        if (isRunning) {
            // Load start time from file, or use current time if not found
            const savedStartTime = loadServerStartTime(id);
            serverStartTimes[id] = savedStartTime || Date.now();
            console.log(`Loaded start time for server ${id}: ${new Date(serverStartTimes[id]).toISOString()}`);
            
            onlinePlayers[id] = [];
            startLogTail(id);
            if (status !== 'running') {
                await dbRun('UPDATE servers SET status = ? WHERE id = ?', ['running', id]);
            }
        } else if (status === 'running') {
            await dbRun('UPDATE servers SET status = ? WHERE id = ?', ['stopped', id]);
        }
    }
    // Server states restored silently
}
restoreServers().catch(err => console.error('Restore servers error:', err));

// Live stats emission now handled by:
// 1. getServerStats() - unified function for local and remote servers
// 2. refreshRemoteServerStats() - keeps remote node data fresh
// 3. Global broadcast interval - emits consolidated stats every 2 seconds

// Removed: updateLiveStats() function (lines 879-1082) - was causing duplicate stat broadcasts
// Now using consolidated getServerStats() + refreshRemoteServerStats() for all updates

// Helper: Save global settings to database
function saveGlobalSettings() {
    Object.entries(globalSettings).forEach(([key, value]) => {
        db.run(`INSERT OR REPLACE INTO panel_settings (key, value) VALUES (?, ?)`,
            [key, JSON.stringify(value)],
            (err) => {
                if (err) console.error('Error saving setting:', err);
            }
        );
    });
}
// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Test route - simple version (before /api middleware)
app.get('/test-json', (req, res) => {
    res.json({ test: 'working' });
});

// Test endpoint for nodes API
app.get('/api/nodes/test/list', async (req,res)=>{ 
    try {
        const rows = await dbAll('SELECT id,name FROM nodes ORDER BY id');
        res.json({success:true, count:rows.length, nodes:rows}); 
    } catch(e) {
        console.error('[TEST] Error:', e);
        res.status(500).json({error: e.message});
    }
});

// Add a catch-all for all /api requests to trace routing
app.use((req, res, next) => {
    // Removed verbose [TRACE] logging for cleaner console
    next();
});

// Request logging middleware
app.use((req, res, next) => {
    if (req.path.includes('/admin/users/') && req.path.includes('/edit')) {
        console.log('=== REQUEST TO USER EDIT ===');
        console.log('Method:', req.method);
        console.log('URL:', req.url);
        console.log('Path:', req.path);
        console.log('Params:', req.params);
        console.log('========================');
    }
    next();
});
// Session configuration (fixed - single proper session with flash after)
// Never fall back to a hardcoded session secret: without SESSION_SECRET a
// persistent random secret is generated and stored locally so sessions
// survive restarts but cannot be forged by anyone who knows a default.
function loadOrCreateSessionSecret() {
    if (process.env.SESSION_SECRET) return process.env.SESSION_SECRET;
    const secretPath = path.join(DATA_DIR, '.session-secret');
    try {
        const existing = fs.readFileSync(secretPath, 'utf8').trim();
        if (existing.length >= 32) return existing;
    } catch (e) {}
    const secret = require('crypto').randomBytes(48).toString('hex');
    try { fs.writeFileSync(secretPath, secret, { mode: 0o600 }); } catch (e) {}
    return secret;
}

const sessionMiddleware = session({
    secret: loadOrCreateSessionSecret(),
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: false,
        maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
});
app.use(sessionMiddleware);

// Only authenticated browser sessions may open socket connections. The
// session middleware is re-run on the handshake request itself because
// express middleware is not guaranteed to have run before engine.io
// processes the polling request.
io.use((socket, next) => sessionMiddleware(socket.request, {}, next));
io.use((socket, next) => {
  const req = socket.request;
  if (req && req.session && req.session.user) return next();
  next(new Error('unauthorized'));
});
app.use(flash());
app.use((req, res, next) => {
    res.locals.messages = req.flash();
    next();
});
// View engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
// Make global data available to views
app.use((req, res, next) => {
    res.locals.user = req.session.user || null;
    res.locals.settings = globalSettings;
    next();
});
// File upload configuration
const upload = multer({
    dest: 'uploads/',
    limits: { fileSize: 5 * 1024 * 1024 * 1024 } // 5GB limit
});
// ================================================
// HELPER FUNCTIONS
// ================================================
// Promisified database functions
function dbGet(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.get(sql, params, (err, row) => err ? reject(err) : resolve(row));
    });
}
function dbAll(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows || []));
    });
}
function dbRun(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function (err) {
            err ? reject(err) : resolve({ lastID: this.lastID, changes: this.changes });
        });
    });
}



async function getUserNotifications(userId, limit = 50, unreadOnly = false) {
    try {
        let sql = `SELECT * FROM notifications WHERE user_id = ?`;
        const params = [userId];
        
        if (unreadOnly) {
            sql += ` AND is_read = 0`;
        }
        
        sql += ` ORDER BY created_at DESC LIMIT ?`;
        params.push(limit);
        
        return await dbAll(sql, params);
    } catch (error) {
        console.error('Error getting user notifications:', error);
        return [];
    }
}

async function markNotificationAsRead(notificationId, userId) {
    try {
        await dbRun(
            `UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?`,
            [notificationId, userId]
        );
        return true;
    } catch (error) {
        console.error('Error marking notification as read:', error);
        return false;
    }
}

async function markAllNotificationsAsRead(userId) {
    try {
        await dbRun(
            `UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0`,
            [userId]
        );
        return true;
    } catch (error) {
        console.error('Error marking all notifications as read:', error);
        return false;
    }
}

async function clearAllNotifications(userId) {
    try {
        await dbRun(`DELETE FROM notifications WHERE user_id = ?`, [userId]);
        return true;
    } catch (error) {
        console.error('Error clearing notifications:', error);
        return false;
    }
}

async function getUnreadNotificationCount(userId) {
    try {
        const result = await dbGet(
            `SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0`,
            [userId]
        );
        return result ? result.count : 0;
    } catch (error) {
        console.error('Error getting unread notification count:', error);
        return 0;
    }
}

// Utility: Local path resolution returns safe default in remote-only architecture
// All server file operations should go through remote node agent via queueNodeAction()
function resolveServerPath(serverId, requestedPath = '') {
    // Return a non-existent path so file operations fail gracefully
    // This prevents errors while signaling that local operations won't work
    return path.join(__dirname, '.disabled', 'servers', serverId.toString(), requestedPath);
}

// Utility: Format file size
function formatFileSize(bytes) {
    if (!bytes || bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}
// Utility: Parse server.properties
function parseProperties(content) {
    const properties = {};
    content.split('\n').forEach(line => {
        line = line.trim();
        if (line && !line.startsWith('#')) {
            const [key, ...valueParts] = line.split('=');
            const value = valueParts.join('=').trim();
            if (key && value !== undefined) {
                if (value === 'true' || value === 'false') {
                    properties[key.trim()] = value === 'true';
                } else if (!isNaN(parseInt(value, 10))) {
                    properties[key.trim()] = parseInt(value, 10);
                } else {
                    properties[key.trim()] = value;
                }
            }
        }
    });
    return properties;
}
// Utility: Write server.properties
function writeProperties(properties, filePath) {
    const content = Object.entries(properties)
        .map(([key, value]) => `${key}=${value}`)
        .join('\n');
    // Ensure directory exists
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(filePath, content, 'utf8');
}

// ================================================
// ENHANCED PORT MANAGEMENT SYSTEM WITH SMART PROTECTION
// ================================================

// Enhanced port configuration with server-type specific ranges
const PORT_CONFIG = {
    // Java Edition Servers (Standard Minecraft)
    JAVA_EDITION: {
        START_PORT: 25565,      // Default Minecraft port
        MAX_PORT: 25665,        // Allow 100 Java servers (25565-25665)
        DEFAULT_PORT: 25565,
        CATEGORY: 'Java Edition'
    },
    
    // Proxy Servers (BungeeCord, Velocity, Waterfall)
    PROXY_SERVERS: {
        START_PORT: 25700,      // Proxy server range
        MAX_PORT: 25799,        // Allow 100 proxy servers (25700-25799)
        DEFAULT_PORT: 25700,
        CATEGORY: 'Proxy Servers'
    },
    
    // Reserved system ports (never assign these)
    RESERVED_PORTS: [
        3000,               // Panel port
        22,                 // SSH
        80,                 // HTTP
        443,                // HTTPS
        3306,               // MySQL
        5432,               // PostgreSQL
        6379,               // Redis
        27017,              // MongoDB
        8080, 8443,         // Common web ports
        21, 23,             // FTP, Telnet
        53,                 // DNS
        110, 143, 993, 995, // Email ports
        1433, 1521,         // Database ports
        5000, 5001,         // Common app ports
        9000, 9001          // Common service ports
    ]
};

// Get appropriate port range for server type
function getPortRangeForServerType(serverType) {
    // Proxy servers
    if (['velocity', 'bungeecord', 'waterfall'].includes(serverType)) {
        return PORT_CONFIG.PROXY_SERVERS;
    }
    
    // Default to Java Edition for all other servers
    return PORT_CONFIG.JAVA_EDITION;
}

// Enhanced port finder with server-type awareness
async function findAvailablePortForServerType(serverType) {
    try {
        const portRange = getPortRangeForServerType(serverType);
        const usedPorts = await dbAll('SELECT port FROM servers WHERE port IS NOT NULL');
        const usedPortNumbers = usedPorts.map(row => parseInt(row.port));
        
        // Add reserved ports to used ports
        usedPortNumbers.push(...PORT_CONFIG.RESERVED_PORTS);
        
        // Find first available port in the appropriate range
        for (let port = portRange.START_PORT; port <= portRange.MAX_PORT; port++) {
            if (!usedPortNumbers.includes(port)) {
                // Double-check port is not in use by system
                if (await isPortAvailable(port)) {
                    console.log(`Assigned ${portRange.CATEGORY} port ${port} for ${serverType} server`);
                    return port;
                }
            }
        }
        
        throw new Error(`No available ports in ${portRange.CATEGORY} range (${portRange.START_PORT}-${portRange.MAX_PORT})`);
    } catch (err) {
        console.error(`Error finding available port for ${serverType}:`, err);
        throw new Error(`Failed to find available port for ${serverType}: ${err.message}`);
    }
}

// Enhanced port availability checker with better system integration
function isPortAvailable(port) {
    return new Promise((resolve) => {
        const net = require('net');
        const server = net.createServer();
        
        server.listen(port, '0.0.0.0', (err) => {
            if (err) {
                resolve(false);
            } else {
                server.once('close', () => resolve(true));
                server.close();
            }
        });
        
        server.on('error', () => resolve(false));
        
        // Timeout after 2 seconds
        setTimeout(() => {
            try {
                server.close();
            } catch (e) {}
            resolve(false);
        }, 2000);
    });
}

// Enhanced server port management with type-specific handling
async function ensureServerPortForType(serverId, serverType) {
    try {
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) throw new Error('Server not found');
        
        const portRange = getPortRangeForServerType(serverType);
        let assignedPort = server.port;
        
        // Check if current port is in the correct range for server type
        const isPortInCorrectRange = assignedPort >= portRange.START_PORT && assignedPort <= portRange.MAX_PORT;
        
        // If no port assigned, wrong range, or port conflicts, assign a new one
        if (!assignedPort || !isPortInCorrectRange || !(await isPortAvailable(assignedPort))) {
            const oldPort = assignedPort;
            assignedPort = await findAvailablePortForServerType(serverType);
            
            // Update database with new port
            await dbRun('UPDATE servers SET port = ? WHERE id = ?', [assignedPort, serverId]);
            
            if (oldPort && oldPort !== assignedPort) {
                console.log(`Migrated server ${serverId} from port ${oldPort} to ${assignedPort} (${portRange.CATEGORY} range)`);
            } else {
                console.log(`Assigned ${portRange.CATEGORY} port ${assignedPort} to server ${serverId}`);
            }
        }
        
        // Update server configuration files with correct port
        await updateServerConfigurationPort(serverId, serverType, assignedPort);
        
        return assignedPort;
    } catch (err) {
        console.error(`Error ensuring port for server ${serverId} (${serverType}):`, err);
        throw err;
    }
}

// Enhanced configuration file updates for different server types
async function updateServerConfigurationPort(serverId, serverType, port) {
    try {
        // Remote-only architecture: configuration updates are handled by remote node
        console.log(`ℹ️ [Remote-Only] Configuration updates for server ${serverId} managed by remote node`);
        return; // Silently return without attempting local file operations
    } catch (err) {
        console.warn(`[Remote-Only] Skipping local configuration for server ${serverId}`);
    }
}

// Proxy server configuration management
async function updateProxyServerPort(serverId, serverType, port) {
    try {
        console.log(`ℹ️ [Remote-Only] Proxy configuration update for server ${serverId} managed by remote node`);
        return;
    } catch (err) {
        console.warn(`[Remote-Only] Skipping local proxy configuration for server ${serverId}`);
    }
}

// Bedrock server configuration management
// Validate and sanitize server.properties to prevent port changes
function sanitizeServerProperties(content, serverPort) {
    try {
        const properties = parseProperties(content);
        
        // ONLY force the correct port (users CAN change everything else)
        properties['server-port'] = serverPort;
        
        // Allow all other properties to be edited freely
        // No validation or restrictions on other settings
        
        return writePropertiesString(properties);
    } catch (err) {
        console.error('Error sanitizing server.properties:', err);
        throw err;
    }
}

// Convert properties object to string format
function writePropertiesString(properties) {
    return Object.entries(properties)
        .map(([key, value]) => `${key}=${value}`)
        .join('\n') + '\n';
}

// Validate and sanitize velocity.toml to prevent bind port changes
function sanitizeVelocityToml(content, serverPort) {
    try {
        // Replace any bind port with the correct one
        const bindRegex = /bind\s*=\s*"[^"]*"/g;
        const correctBind = `bind = "0.0.0.0:${serverPort}"`;
        
        // If there's already a bind setting, replace it
        if (bindRegex.test(content)) {
            content = content.replace(bindRegex, correctBind);
        } else {
            // If no bind setting exists, add it at the beginning
            const lines = content.split('\n');
            const insertIndex = lines.findIndex(line => 
                line.trim() && !line.trim().startsWith('#')
            );
            
            if (insertIndex >= 0) {
                lines.splice(insertIndex, 0, correctBind);
            } else {
                lines.unshift(correctBind);
            }
            
            content = lines.join('\n');
        }
        
        return content;
    } catch (err) {
        console.error('Error sanitizing velocity.toml:', err);
        throw err;
    }
}

// Validate and sanitize BungeeCord config.yml to prevent port changes
function sanitizeBungeeCordConfig(content, serverPort) {
    try {
        // Replace any host port with the correct one
        const hostRegex = /host:\s*([^:]+):(\d+)/g;
        const correctHost = `host: 0.0.0.0:${serverPort}`;
        
        // Replace all host entries with the correct port
        content = content.replace(hostRegex, (match, ip, port) => {
            return `host: 0.0.0.0:${serverPort}`;
        });
        
        // Also handle listen entries if they exist
        const listenRegex = /listen:\s*([^:]+):(\d+)/g;
        content = content.replace(listenRegex, (match, ip, port) => {
            return `listen: 0.0.0.0:${serverPort}`;
        });
        
        // Handle bind_local_address entries
        const bindLocalRegex = /bind_local_address:\s*([^:]+):(\d+)/g;
        content = content.replace(bindLocalRegex, (match, ip, port) => {
            return `bind_local_address: 0.0.0.0:${serverPort}`;
        });
        
        return content;
    } catch (err) {
        console.error('Error sanitizing BungeeCord config.yml:', err);
        throw err;
    }
}

// Enforce proxy server port before starting (Velocity, BungeeCord, Waterfall)
async function enforceProxyServerPort(serverId, serverType, correctPort) {
    try {
        // Remote-only architecture: port enforcement handled by remote node
        console.log(`ℹ️ [Remote-Only] Port enforcement for server ${serverId} managed by remote node`);
        return;
    } catch (err) {
        console.warn(`[Remote-Only] Skipping local port enforcement for server ${serverId}`);
    }
}

// Enforce Minecraft server port before starting
async function enforceMinecraftServerPort(serverId, correctPort) {
  try {
    const server = await dbGet('SELECT node_id FROM servers WHERE id = ?', [serverId]);
    if (!server) return;
    
    // Remote-only architecture: all servers must have node_id
    if (!server.node_id) {
      console.error(`❌ Cannot enforce port for server ${serverId} - no node_id assigned (remote-only architecture)`);
      return;
    }
    
    // Queue the port enforcement to the remote node using properties-save
    await queueNodeAction(server.node_id, serverId, 'properties-save', { 
      port: correctPort,
      action: 'update_port'
    });
    
    console.log(`🔒 Queued port enforcement for server ${serverId} on node ${server.node_id} for port ${correctPort}`);
  } catch (err) {
    console.error(`Error enforcing port for server ${serverId}:`, err);
    throw err;
  }
}

// Helper function to get standard template variables
async function getTemplateVars(req, server = null, additionalVars = {}) {
    let userWithTheme = req.session.user;
    
    // Load user theme preferences and profile data from database if user is logged in
    if (req.session.user) {
        try {
            const userProfile = await dbGet(`
                SELECT u.*, up.theme_preference, up.theme_primary_color, up.theme_accent_color,
                       up.language, up.timezone, up.display_name as profile_display_name, 
                       up.profile_picture
                FROM users u
                LEFT JOIN user_profiles up ON u.id = up.user_id
                WHERE u.id = ?
            `, [req.session.user.id]);
            
            if (userProfile) {
                userWithTheme = {
                    ...req.session.user,
                    theme_preference: userProfile.theme_preference || 'dark',
                    theme_primary_color: userProfile.theme_primary_color || '#2d6a4f',
                    theme_accent_color: userProfile.theme_accent_color || '#40916c',
                    language: userProfile.language || 'en',
                    timezone: userProfile.timezone || 'UTC',
                    display_name: userProfile.profile_display_name || userProfile.display_name || req.session.user.username,
                    profile_picture: userProfile.profile_picture || null
                };
            }
        } catch (err) {
            console.error('Error loading user profile:', err);
            // Continue with session user data if profile loading fails
        }
    }
    
    // Get unread notification count if user is logged in
    let unreadCount = 0;
    if (req.session.user) {
        try {
            unreadCount = await getUnreadNotificationCount(req.session.user.id);
        } catch (err) {
            console.error('Error getting unread notification count:', err);
            unreadCount = 0;
        }
    }
    
    return {
        settings: globalSettings,
        user: userWithTheme,
        currentPage: additionalVars.currentPage || 'dashboard',
        server: server,
        unreadCount: unreadCount,
        req: req, // Pass request object for path detection
        ...additionalVars
    };
}
// Authorization middleware
async function isAuthorized(req, serverId) {
    if (!req.session || !req.session.user) return false;
  
    try {
        const server = await dbGet('SELECT owner_id FROM servers WHERE id = ?', [serverId]);
        if (!server) return false;
      
        if (req.session.user.role === 'admin' || server.owner_id === req.session.user.id) {
            return true;
        }
      
        const subuser = await dbGet(
            'SELECT * FROM subusers WHERE server_id = ? AND user_id = ?',
            [serverId, req.session.user.id]
        );
        return !!subuser;
    } catch (err) {
        console.error('Authorization error:', err);
        return false;
    }
}

// Check if user has specific permission for a server
async function hasPermission(req, serverId, permission) {
    if (!req.session || !req.session.user) return false;
  
    try {
        const server = await dbGet('SELECT owner_id FROM servers WHERE id = ?', [serverId]);
        if (!server) return false;
       
        // Owner and admin have all permissions
        if (req.session.user.role === 'admin' || server.owner_id === req.session.user.id) {
            return true;
        }
       
        const subuser = await dbGet(
            'SELECT permissions FROM subusers WHERE server_id = ? AND user_id = ?',
            [serverId, req.session.user.id]
        );
        
        if (!subuser) {
            console.log(`[Permission Debug] No subuser found for server ${serverId}, user ${req.session.user.id}`);
            return false;
        }
        
        console.log(`[Permission Debug] Checking permission '${permission}' for user ${req.session.user.id} on server ${serverId}`);
        console.log(`[Permission Debug] Subuser permissions:`, subuser.permissions);
        
        try {
            const perms = JSON.parse(subuser.permissions || '[]');
            const hasPerm = perms.includes(permission);
            console.log(`[Permission Debug] Permission '${permission}' check result:`, hasPerm);
            return hasPerm;
        } catch (e) {
            console.error('[Permission Debug] Error parsing permissions:', e);
            return false;
        }
    } catch (err) {
        console.error('Permission check error:', err);
        return false;
    }
}

// Middleware factory for permission-based access control
function requirePermission(permission) {
    return async (req, res, next) => {
        const serverId = req.params.id || req.body.serverId || req.query.serverId;
        if (!serverId) {
            return res.status(400).json({ error: 'Server ID required' });
        }
        
        console.log(`[Permission Middleware] Checking permission '${permission}' for server ${serverId}`);
        
        const allowed = await hasPermission(req, serverId, permission);
        if (!allowed) {
            console.log(`[Permission Middleware] Access denied - missing permission '${permission}'`);
            return res.status(403).json({ 
                error: 'Access denied', 
                message: `Required permission: ${permission}` 
            });
        }
        
        console.log(`[Permission Middleware] Access granted for '${permission}'`);
        next();
    };
}
// Admin middleware
const requireAdmin = (req, res, next) => {
    console.log('[requireAdmin] Checking auth for', req.path);
    if (!req.session.user) {
        // Check if this is an API request
        const isApiRequest = req.xhr || 
                           req.headers.accept?.toLowerCase().includes('application/json') || 
                           req.headers['content-type']?.toLowerCase().includes('application/json') ||
                           req.path.startsWith('/api/');
        
        console.log('[requireAdmin] Not logged in, is API request:', isApiRequest);
        if (isApiRequest) {
            console.log('Admin auth failed - not logged in (API request)');
            return res.status(401).json({ error: 'Authentication required' });
        }
        return res.redirect('/auth/login');
    }
    
    if (req.session.user.role !== 'admin') {
        // Check if this is an API request
        const isApiRequest = req.xhr || 
                           req.headers.accept?.toLowerCase().includes('application/json') || 
                           req.headers['content-type']?.toLowerCase().includes('application/json') ||
                           req.path.startsWith('/api/');
        
        if (isApiRequest) {
            console.log('Admin auth failed - not admin (API request):', req.session.user.username);
            return res.status(403).json({ error: 'Admin privileges required' });
        }
        req.flash = req.flash || function(type, msg) { req.session.messages = req.session.messages || []; req.session.messages.push({type, msg}); };
        req.flash('error', 'Access denied. Admin privileges required.');
        return res.redirect('/dashboard');
    }
    console.log('[requireAdmin] Admin authenticated, allowing:', req.session.user.username);
    next();
};
// Authentication middleware
const requireAuth = (req, res, next) => {
    if (!req.session.user) {
        // Check if this is an API request (AJAX/fetch)
        const isApiRequest = req.xhr || 
                           req.headers.accept?.toLowerCase().includes('application/json') || 
                           req.headers['content-type']?.toLowerCase().includes('application/json') ||
                           req.path.startsWith('/api/');
        
        if (isApiRequest) {
            return res.status(401).json({ error: 'Authentication required' });
        }
        return res.redirect('/auth/login');
    }
    next();
};
// Server control helpers
async function isServerRunning(serverId) {
  try {
    const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
    if (!server) return false;
    // All servers are remote - check database status
    return server.status === 'running' || server.status === 'starting';
  } catch (err) {
    console.error(`Error checking if server ${serverId} is running:`, err);
    return false;
  }
}

// Helper function to check if a process is running by PID
function isProcessRunning(pid) {
  try {
    // Sending signal 0 checks if process exists without killing it
    process.kill(pid, 0);
    return true;
  } catch (err) {
    return false;
  }
}

// Helper function to check if a PID is a Java process
async function isJavaProcess(pid) {
  pid = Number(pid);
  if (!Number.isInteger(pid) || pid < 1) return false;
  try {
    if (os.platform() === 'win32') {
      const { stdout } = await execAsync(`tasklist /FI "PID eq ${pid}" /FO CSV /NH`);
      return stdout.toLowerCase().includes('java');
    } else {
      const { stdout } = await execAsync(`ps -p ${pid} -o comm=`);
      return stdout.toLowerCase().includes('java');
    }
  } catch (err) {
    return false;
  }
}

// Auto-enable RCON in server.properties
async function autoEnableRcon(serverId) {
  try {
    const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
    if (!server) return false;
    
    // Remote-only architecture: all servers must have node_id
    if (!server.node_id) {
      console.error(`❌ Cannot enable RCON for server ${serverId} - no node_id assigned (remote-only architecture)`);
      return false;
    }
    
    // Queue RCON enable to remote node
    await queueNodeAction(server.node_id, serverId, 'properties-save', { 
      action: 'enable_rcon',
      rconPort: server.port + 1000,
      rconPassword: 'admin123'
    });
    
    console.log(`Queued RCON enable for server ${serverId} on node ${server.node_id}`);
    return true;
  } catch (err) {
    console.error(`Failed to queue RCON enable for server ${serverId}:`, err);
    return false;
  }
}

// ================================================
// SYSTEM MESSAGE LOGGER - Write status messages to console
// ================================================

function logSystemMessage(serverId, message) {
  const timestamp = new Date().toLocaleTimeString('en-US', { 
    hour12: false, 
    hour: '2-digit', 
    minute: '2-digit', 
    second: '2-digit' 
  });
  
  const logMessage = `[${timestamp}] container@panel~ ${message}`;
  
  // Emit to Socket.IO for live console only - remote-only architecture
  if (io) {
    io.to(`server:${serverId}`).emit('console:output', {
      message: terminalColorParser.processLine(logMessage, 'system'),
      rawMessage: logMessage,
      plainMessage: stripAllColors(logMessage),
      level: 'system'
    });
  }
}

// ================================================
// CONSOLE LOG HELPER - Emit to Socket.IO only (not Node console)
// ================================================

function emitConsoleLog(serverId, message, level = 'log') {
  if (io) {
    const text = String(message);
    io.to(`server:${serverId}`).emit('console:output', {
      message: terminalColorParser.processLine(text, level),
      rawMessage: text,
      plainMessage: stripAllColors(text),
      level: level
    });
  }
}

async function sendCommand(serverId, command) {
  if (!await isServerRunning(serverId)) {
    emitConsoleLog(serverId, `Cannot send command to server ${serverId}: server not running`, 'error');
    return { success: false, response: null };
  }
  
  try {
    const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
    if (!server || !server.node_id) {
      emitConsoleLog(serverId, `Server ${serverId} has no node assigned`, 'error');
      return { success: false, response: null };
    }
    
    // All servers are remote - send command to remote node
    try {
      const remoteResult = await remoteCommand(server.node_id, serverId, 'console-command', { command: String(command) }, 30000);
      return { success: true, response: remoteResult.result?.response ?? remoteResult.result?.output ?? null, method: 'remote' };
    } catch (remoteErr) {
      emitConsoleLog(serverId, `Remote console command failed: ${remoteErr.message}`, 'error');
      return { success: false, response: remoteErr.message, method: 'remote' };
    }
  } catch (err) {
    emitConsoleLog(serverId, `Send command error for server ${serverId}: ${err.message}`, 'error');
    return { success: false, response: err.message };
  }
}

// ================================================
// HELPER: Check if server is remote and route operation
// ================================================
async function executeServerAction(serverId, action, payload = {}) {
  const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
  if (!server) throw new Error('Server not found');
  
  if (server && server.node_id) {
    console.log(`📤 Queuing ${action} command for remote node ${server.node_id}, server ${serverId}`);
    return await queueNodeAction(server.node_id, serverId, action, payload);
  }
  
  return null;
}

async function isRemoteServer(serverId) {
  // All servers are remote nodes now
  return true;
}

async function getServerNode(serverId) {
  const server = await dbGet('SELECT node_id FROM servers WHERE id = ?', [serverId]);
  if (!server?.node_id) {
    throw new Error(`Server ${serverId} has no node_id assigned - remote-only architecture requires all servers to be on a remote node`);
  }
  return server.node_id;
}

// ================================================
// PORT PROTECTION & VALIDATION
// ================================================

// Validate and fix server port before startup
async function validateAndFixServerPort(serverId) {
  try {
    const server = await dbGet('SELECT id, port, node_id FROM servers WHERE id = ?', [serverId]);
    if (!server) throw new Error('Server not found');
    
    // Remote-only architecture: all servers must have node_id
    if (!server.node_id) {
      throw new Error(`Server ${serverId} has no node_id assigned - remote-only architecture requires all servers to be on a remote node`);
    }
    
    const correctPort = server.port;
    
    // For all servers (remote), queue the port validation to the node agent
    // The node agent will handle server.properties locally on the remote node
    await queueNodeAction(server.node_id, serverId, 'properties-save', { 
      port: correctPort,
      action: 'update_port'
    });
    
    console.log(`🔒 Queued port validation for server ${serverId} on node ${server.node_id}, port ${correctPort}`);
    return { status: 'queued', port: correctPort };
  } catch (err) {
    console.error(`🔒 Error queuing port validation for ${serverId}:`, err);
    throw err;
  }
}

// ================================================
// START SERVER
// ================================================

async function startServer(serverId) {
  const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
  if (!server) throw new Error('Server not found');
  
  // Validate and fix port before starting
  const portValidation = await validateAndFixServerPort(serverId);
  console.log(`🔒 Port validation result:`, portValidation);
  
  // All servers are remote - queue action to remote node
  console.log(`📤 Queuing start command for remote server ${serverId} on node ${server.node_id}`);
  await dbRun("UPDATE servers SET status = 'starting' WHERE id = ?", [serverId]);
  try {
    // Queue the command with startup_command from database and PORT from database
    await queueNodeAction(server.node_id, serverId, 'start', { 
      startup_command: server.startup_command,
      ram: server.ram,
      port: server.port  // CRITICAL: Pass actual database port to remote node
    });
    console.log(`✅ Start command queued with port ${server.port} for server ${serverId}`);
    emitConsoleLog(serverId, 'Start command queued to remote node. Server should be starting...', 'system');
    return true;
  } catch (err) {
    await dbRun("UPDATE servers SET status = 'stopped' WHERE id = ? AND node_id = ?", [serverId, server.node_id]);
    emitConsoleLog(serverId, `Remote start failed: ${err.message}`, 'error');
    throw err;
  }
}
async function stopServer(serverId, force = false) {
  const remoteServer = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
  
  // Clean up remote log polling interval if it exists
  if (global.remoteLogIntervals && global.remoteLogIntervals[serverId]) {
    clearInterval(global.remoteLogIntervals[serverId]);
    delete global.remoteLogIntervals[serverId];
    console.log(`📤 Stopped log polling for server ${serverId}`);
  }
  
  // All servers are remote - queue stop action
  console.log(`📤 Queuing stop command for remote server ${serverId} on node ${remoteServer.node_id}`);
  await dbRun("UPDATE servers SET status = 'stopping' WHERE id = ?", [serverId]);
  try {
    // Just queue the command, don't wait for result
    await queueNodeAction(remoteServer.node_id, serverId, 'stop', { force: !!force });
    emitConsoleLog(serverId, 'Stop command queued to remote node. Server should be stopping...', 'system');
    return true;
  } catch (err) {
    emitConsoleLog(serverId, `Remote stop failed: ${err.message}`, 'error');
    throw err;
  }
}
async function readServerLogLines(serverId, lines = 200) {
  const safeLines = Math.min(Math.max(Number.parseInt(lines, 10) || 200, 1), 50000);
  const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
  if (!server) throw new Error(`Server ${serverId} not found`);
  if (!server.node_id) throw new Error(`Server ${serverId} has no node assigned; logs must be read from the node agent`);

  const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
  if (!node || !node.token) throw new Error(`Node ${server.node_id} is missing or has no daemon token`);
  if (!node.ip_address || !node.daemon_port) throw new Error(`Node ${server.node_id} has no valid agent address`);

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);
  try {
    const daemonUrl = `http://${node.ip_address}:${node.daemon_port}/servers/${encodeURIComponent(serverId)}/logs?lines=${safeLines}&ansi=1`;
    const response = await fetch(daemonUrl, {
      headers: { 'Accept': 'application/json', 'x-daemon-token': node.token, 'Cache-Control': 'no-cache' },
      cache: 'no-store',
      signal: controller.signal
    });
    const raw = await response.text();
    let data;
    try { data = raw ? JSON.parse(raw) : {}; } catch { throw new Error(`Node returned non-JSON log response (HTTP ${response.status})`); }
    if (!response.ok) throw new Error(data.error || `Node log API returned HTTP ${response.status}`);

    // Support the direct agent response and wrapped responses from older agents.
    const candidates = [data.logs, data.result?.logs, data.data?.logs, data.result?.result?.logs];
    const logs = candidates.find(Array.isArray);
    if (!logs) throw new Error('Node log API response did not contain a logs array');
    console.log(`[latest.log] server=${serverId} node=${server.node_id} lines=${logs.length} requested=${safeLines}`);
    return logs
      .map(line => String(line ?? ''))
      .filter(line => line.length > 0)
      .map(line => terminalColorParser.processLine(line));
  } catch (err) {
    const message = err.name === 'AbortError' ? 'Node latest.log request timed out after 8 seconds' : err.message;
    console.error(`[latest.log] Failed to read server ${serverId} from node ${server.node_id}: ${message}`);
    throw new Error(message);
  } finally {
    clearTimeout(timeout);
  }
}

function startLogTail(serverId) {
  // Remote-only architecture: ALL logs come from remote node agent
  dbGet('SELECT node_id FROM servers WHERE id = ?', [serverId]).then(server => {
    if (!server || !server.node_id) {
      console.error(`❌ Server ${serverId} has no node_id - cannot set up log polling. Remote-only architecture requires all servers to be on a remote node`);
      return;
    }

    console.log(`📤 Setting up remote log polling for server ${serverId} on node ${server.node_id}`);
    
    // Store last log line count to know when new logs arrive
    if (!serverLogPositions[serverId]) serverLogPositions[serverId] = 0;
    
    // Poll daemon every 1 second with last 50 lines
    const pollInterval = setInterval(async () => {
      try {
        // Fetch logs from daemon API
        const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
        if (!node || !node.token) {
          console.error(`❌ Node ${server.node_id} not found or no token`);
          clearInterval(pollInterval);
          return;
        }
        
        // Fetch logs from daemon
        const daemonUrl = `http://${node.ip_address}:${node.daemon_port}/servers/${serverId}/logs?lines=50`;
        const response = await fetch(daemonUrl, {
          headers: {
            'x-daemon-token': node.token
          }
        });
        
        if (!response.ok) {
          console.error(`❌ Failed to fetch logs from node ${server.node_id}: ${response.status}`);
          return;
        }
        
        const data = await response.json();
        const logs = data.logs || [];
        
        // DISABLED: This global polling caused duplicates with socket streaming
        // Console output is now handled exclusively by per-socket streaming in socket.on('join-server')
        /*
        if (logs.length > serverLogPositions[serverId]) {
          const newLogs = logs.slice(serverLogPositions[serverId]);
          for (let line of newLogs) {
            if (line.trim() && !shouldFilterLine(line)) {
              processLogLine(serverId, line);
              const cleanLine = line.replace(/§[0-9a-fk-orx]/gi, '');
              io.to(`server:${serverId}`).emit('console:output', {
                serverId: serverId,
                message: cleanLine + '\n',
                timestamp: Date.now(),
                level: 'log'
              });
            }
          }
          serverLogPositions[serverId] = logs.length;
        }
        */
      } catch (err) {
        console.error(`Error polling logs for server ${serverId} on node ${server.node_id}:`, err.message);
      }
    }, 1000); // Poll every 1 second
    
    // Store interval ID so we can clear it later if needed
    if (!global.remoteLogIntervals) global.remoteLogIntervals = {};
    global.remoteLogIntervals[serverId] = pollInterval;
  }).catch(err => console.error('Error checking server node:', err));
}

// Filter out noise from console logs (internal RCON messages, thread startup/shutdown, debug logs)
function shouldFilterLine(line) {
  const lineStr = String(line || '').trim();
  
  // Filter out ALL RCON related messages - very aggressive
  if (lineStr.includes('RCON')) {
    return true;
  }
  
  // Filter out Thread startup/shutdown messages
  if ((lineStr.includes('Thread') || lineStr.includes('thread')) && 
      (lineStr.includes('started') || lineStr.includes('shutting down'))) {
    return true;
  }
  
  // Filter out debug messages from app.js console.log that shouldn't appear in game console
  if (lineStr.includes('RCON not available') ||
      lineStr.includes('player query skipped') ||
      lineStr.includes('Cannot send command via stdin') ||
      lineStr.includes('Command sent to server') ||
      lineStr.includes('RCON response:') ||
      lineStr.includes('✅ Client connected') ||
      lineStr.includes('❌ Client disconnected') ||
      lineStr.includes('Socket') && lineStr.includes('joined server') ||
      lineStr.includes('📊 Server')) {
    return true;
  }
  
  // Filter out empty lines
  if (!lineStr) {
    return true;
  }
  
  return false;
}

// Helper function to process log lines for player events
function processLogLine(serverId, line) {
  // Skip filtered lines
  if (shouldFilterLine(line)) {
    return;
  }
  
  // Ensure onlinePlayers array exists
  if (!onlinePlayers[serverId]) {
    onlinePlayers[serverId] = [];
  }
  
  // Match various join patterns:
  // [HH:MM:SS] [Server thread/INFO]: PlayerName joined the game
  // [HH:MM:SS INFO]: PlayerName joined the game
  const joinedMatch = line.match(/\[.*?\].*?:\s*(\w+)\s+joined the game/i);
  if (joinedMatch) {
    const player = joinedMatch[1];
    if (!onlinePlayers[serverId].includes(player)) {
      onlinePlayers[serverId].push(player);
      console.log(`\n========== PLAYER JOINED ==========`);
      console.log(`Player: ${player}`);
      console.log(`Server: ${serverId}`);
      console.log(`Online players: ${JSON.stringify(onlinePlayers[serverId])}`);
      console.log(`Broadcasting to room: server:${serverId}`);
      
      // Broadcast to all clients in the server room (including players page)
      io.to(`server:${serverId}`).emit('playerJoined', {
        player: player,
        playerName: player,
        onlinePlayers: onlinePlayers[serverId],
        count: onlinePlayers[serverId].length,
        serverId: serverId,
        timestamp: Date.now()
      });
      console.log(`✅ playerJoined emitted for ${player}`);
      console.log(`===================================\n`);
    }
  }
  
  // Match various leave patterns:
  // [HH:MM:SS] [Server thread/INFO]: PlayerName left the game
  // [HH:MM:SS INFO]: PlayerName left the game
  const leftMatch = line.match(/\[.*?\].*?:\s*(\w+)\s+left the game/i);
  if (leftMatch) {
    const player = leftMatch[1];
    // Several sockets can tail the same log line; only the first one that
    // actually sees the player as online should broadcast the leave event.
    const wasOnline = onlinePlayers[serverId].includes(player);
    onlinePlayers[serverId] = onlinePlayers[serverId].filter(p => p !== player);
    if (wasOnline) {
      console.log(`\n========== PLAYER LEFT ==========`);
      console.log(`Player: ${player}`);
      console.log(`Server: ${serverId}`);
      console.log(`Online players: ${JSON.stringify(onlinePlayers[serverId])}`);
      console.log(`Broadcasting to room: server:${serverId}`);
      
      // Broadcast to all clients in the server room (including players page)
      io.to(`server:${serverId}`).emit('playerLeft', {
        player: player,
        playerName: player,
        onlinePlayers: onlinePlayers[serverId],
        count: onlinePlayers[serverId].length,
        serverId: serverId,
        timestamp: Date.now()
      });
      console.log(`✅ playerLeft emitted for ${player}`);
      console.log(`==================================\n`);
    }
  }
  
  // Parse /list command response to get current online players
  // Format: "There are X of a max of Y players online: player1, player2, player3"
  // Or: "There are X/Y players online: player1, player2"
  const listMatch = line.match(/There are \d+(?:\/| of a max of )\d+ players online:\s*(.*)/i);
  if (listMatch) {
    const playerList = listMatch[1].trim();
    const players = playerList
      ? playerList.split(',').map(p => p.trim()).filter(p => p && p !== '')
      : [];
    const previous = Array.isArray(onlinePlayers[serverId]) ? onlinePlayers[serverId] : [];
    const key = (list) => list.map(String).sort().join('\u0000');
    const changed = key(previous) !== key(players);
    onlinePlayers[serverId] = players;
    if (changed) {
      console.log(`Updated online players for server ${serverId}:`, players);
      io.to(`server:${serverId}`).emit('playersUpdated', {
        serverId: Number(serverId),
        onlinePlayers: players,
        players,
        count: players.length,
        timestamp: Date.now()
      });
    }
  }
}

// Shared live player-list sync for remote nodes.
// Open player pages listen for `playersUpdated`; this keeps the list fresh
// without relying on console log parsing (custom join messages never match).
global.playerSyncPolls = global.playerSyncPolls || {};

async function syncOnlinePlayers(server, emitToSocket = null) {
  if (!server?.node_id) return null;
  const serverId = Number(server.id);
  const room = `server:${serverId}`;

  let players;
  try {
    const remote = await remoteNodeRequest(server.node_id, 'GET', `/servers/${serverId}/players`, { timeoutMs: 8000 });
    players = Array.isArray(remote?.online) ? remote.online.filter(Boolean) : [];
  } catch (err) {
    if (process.env.DEBUG_PLAYER_SYNC === '1') {
      console.warn(`[player-sync] server ${serverId}: ${err.message}`);
    }
    return null;
  }

  const previous = Array.isArray(onlinePlayers[serverId]) ? onlinePlayers[serverId] : [];
  const key = (list) => list.map(String).sort().join('\u0000');
  const changed = key(previous) !== key(players);

  onlinePlayers[serverId] = players;
  global.remoteServerStats = global.remoteServerStats || {};
  global.remoteServerStats[serverId] = {
    ...(global.remoteServerStats[serverId] || {}),
    playerList: players,
    players: players.length
  };

  const payload = {
    serverId,
    onlinePlayers: players,
    players,
    count: players.length,
    timestamp: Date.now()
  };

  if (changed) {
    io.to(room).emit('playersUpdated', payload);
  } else if (emitToSocket) {
    // Newly joined client may still show a stale list rendered at page load.
    emitToSocket.emit('playersUpdated', payload);
  }

  return players;
}

// One polling loop per server, shared by every socket watching that server.
// It stops itself once the room is empty, so no per-socket timers are needed.
function ensurePlayerSync(server) {
  if (!server?.node_id) return;
  const serverId = Number(server.id);
  const key = String(serverId);
  if (global.playerSyncPolls[key]) return;

  const entry = {
    timer: setInterval(async () => {
      const room = io.sockets.adapter.rooms.get(`server:${serverId}`);
      if (!room || room.size === 0) {
        clearInterval(entry.timer);
        delete global.playerSyncPolls[key];
        return;
      }
      await syncOnlinePlayers(server);
    }, 5000)
  };
  global.playerSyncPolls[key] = entry;
}

// Helper function to query current online players from remote node
async function queryOnlinePlayersRcon(serverId) {
  try {
    const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
    if (!server) return false;

    // Remote-only architecture: all servers must have node_id
    if (!server.node_id) {
      console.warn(`⚠️ Server ${serverId} has no node_id - cannot query players (remote-only architecture)`);
      return false;
    }

    // Fetch player list from remote node via agent
    try {
      const remote = await remoteNodeRequest(server.node_id, 'GET', `/servers/${serverId}/players`, { timeoutMs: 10000 });
      const players = Array.isArray(remote?.online) ? remote.online : [];
      
      // Update the global player list
      onlinePlayers[serverId] = players;
      console.log(`Updated online players for server ${serverId} from remote node:`, players);
      
      // Emit update via Socket.IO
      io.to(`server:${serverId}`).emit('playersUpdated', {
        onlinePlayers: players,
        count: players.length
      });
      
      return true;
    } catch (remoteErr) {
      console.log(`Failed to fetch players from remote node ${server.node_id}:`, remoteErr.message);
      return false;
    }
  } catch (err) {
    console.log(`Player query failed for server ${serverId}:`, err.message);
    return false;
  }
}

// Helper function to query current online players from server
async function queryOnlinePlayers(serverId) {
  try {
    // First try RCON (more reliable)
    const rconSuccess = await queryOnlinePlayersRcon(serverId);
    if (rconSuccess) return true;

    // Fallback to stdin if we have process reference
    const serverProcess = global.serverProcesses && global.serverProcesses[serverId];
    if (serverProcess && !serverProcess.killed && serverProcess.stdin && serverProcess.stdin.writable) {
      // Send /list command to get current players
      serverProcess.stdin.write('list\n');
      console.log(`✅ Sent /list command via stdin to server ${serverId}`);
      return true;
    } else {
      // If we don't have process reference or it's not writable
      // This is expected for remote servers or reconn ected processes
      if (!serverProcess) {
        console.log(`⚠️ No process reference for server ${serverId} - players will be tracked via log parsing`);
      } else if (serverProcess.killed) {
        console.log(`⚠️ Process for server ${serverId} is killed`);
      } else if (!serverProcess.stdin) {
        console.log(`⚠️ No stdin for server ${serverId} - reconnected process`);
      }
      
      // Initialize as empty if not already set - players will be populated via log parsing
      if (!onlinePlayers[serverId]) {
        onlinePlayers[serverId] = [];
      }
      return false;
    }
  } catch (err) {
    console.error(`❌ Failed to query online players for server ${serverId}:`, err.message);
    
    // Initialize as empty if not already set
    if (!onlinePlayers[serverId]) {
      onlinePlayers[serverId] = [];
    }
    return false;
  }
}
async function getPidByPort(port) {
  // Strict numeric validation - port is interpolated into shell commands below.
  port = Number(port);
  if (!Number.isInteger(port) || port < 1 || port > 65535) return null;
  try {
    if (os.platform() === 'win32') {
      // Windows: Use netstat to find PID by port
      const { stdout } = await execAsync(`netstat -ano | findstr :${port}`);
      const lines = stdout.trim().split('\n');
      
      for (const line of lines) {
        // Look for LISTENING state
        if (line.includes('LISTENING')) {
          const parts = line.trim().split(/\s+/);
          const pid = parseInt(parts[parts.length - 1]);
          if (!isNaN(pid) && pid > 0) {
            // Verify this is a Java process
            try {
              const { stdout: taskList } = await execAsync(`tasklist /FI "PID eq ${pid}" /FO CSV /NH`);
              if (taskList.toLowerCase().includes('java')) {
                return pid;
              }
            } catch (err) {
              // Continue checking other PIDs
            }
          }
        }
      }
      return null;
    } else {
      // Linux: Use lsof
      const { stdout } = await execAsync(`lsof -iTCP:${port} -sTCP:LISTEN -t`);
      const pid = parseInt(stdout.trim());
      return isNaN(pid) ? null : pid;
    }
  } catch (err) {
    return null;
  }
}
async function downloadServerJar(serverType, version, dir) {
    let url;
    let actualVersion = version;
    
    try {
        console.log(`🔄 Downloading ${serverType} ${version}...`);
        
        // Handle 'latest' for each server type
        if (version === 'latest') {
            if (serverType === 'vanilla') {
                const manifestRes = await axios.get('https://launchermeta.mojang.com/mc/game/version_manifest.json');
                actualVersion = manifestRes.data.latest.release;
            } else if (serverType === 'paper') {
                const res = await axios.get('https://api.papermc.io/v2/projects/paper');
                actualVersion = res.data.versions[res.data.versions.length - 1];
            } else if (serverType === 'purpur') {
                const res = await axios.get('https://api.purpurmc.org/v2/purpur');
                actualVersion = res.data.versions[res.data.versions.length - 1];
            } else if (serverType === 'velocity') {
                const res = await axios.get('https://api.papermc.io/v2/projects/velocity');
                actualVersion = res.data.versions[res.data.versions.length - 1];
            } else if (serverType === 'waterfall') {
                const res = await axios.get('https://api.papermc.io/v2/projects/waterfall');
                actualVersion = res.data.versions[res.data.versions.length - 1];
            } else if (serverType === 'bungeecord') {
                actualVersion = 'latest'; // BungeeCord uses latest build
            }
        }
        
        // Get download URL for each server type
        if (serverType === 'vanilla') {
            const manifestRes = await axios.get('https://launchermeta.mojang.com/mc/game/version_manifest.json');
            const ver = manifestRes.data.versions.find(v => v.id === actualVersion);
            if (!ver) throw new Error(`Vanilla version ${actualVersion} not found`);
            const verJsonRes = await axios.get(ver.url);
            url = verJsonRes.data.downloads.server.url;
        } else if (serverType === 'paper') {
            try {
                const buildsRes = await axios.get(`https://api.papermc.io/v2/projects/paper/versions/${actualVersion}/builds`);
                if (!buildsRes.data.builds || buildsRes.data.builds.length === 0) {
                    throw new Error(`No builds found for Paper ${actualVersion}`);
                }
                const build = buildsRes.data.builds[buildsRes.data.builds.length - 1];
                url = `https://api.papermc.io/v2/projects/paper/versions/${actualVersion}/builds/${build.build}/downloads/paper-${actualVersion}-${build.build}.jar`;
            } catch (paperErr) {
                console.error(`Paper API error for version ${actualVersion}:`, paperErr.message);
                // Fallback: use latest available version
                try {
                    const latestRes = await axios.get('https://api.papermc.io/v2/projects/paper');
                    const latestVersion = latestRes.data.versions[latestRes.data.versions.length - 1];
                    const fallbackBuildsRes = await axios.get(`https://api.papermc.io/v2/projects/paper/versions/${latestVersion}/builds`);
                    const build = fallbackBuildsRes.data.builds[fallbackBuildsRes.data.builds.length - 1];
                    url = `https://api.papermc.io/v2/projects/paper/versions/${latestVersion}/builds/${build.build}/downloads/paper-${latestVersion}-${build.build}.jar`;
                    actualVersion = latestVersion;
                    console.log(`Falling back to Paper latest version: ${latestVersion}`);
                } catch (fallbackErr) {
                    throw new Error(`Failed to download Paper: ${paperErr.message}`);
                }
            }
        } else if (serverType === 'purpur') {
            const latestBuildRes = await axios.get(`https://api.purpurmc.org/v2/purpur/${actualVersion}/latest`);
            const build = latestBuildRes.data.build;
            url = `https://api.purpurmc.org/v2/purpur/${actualVersion}/${build}/download`;
        } else if (serverType === 'spigot') {
            // Spigot requires BuildTools - provide direct download link
            url = 'https://hub.spigotmc.org/jenkins/job/BuildTools/lastSuccessfulBuild/artifact/target/BuildTools.jar';
        } else if (serverType === 'fabric') {
            const loaderRes = await axios.get('https://meta.fabricmc.net/v2/versions/loader');
            const loader = loaderRes.data[0].version;
            url = `https://meta.fabricmc.net/v2/versions/loader/${actualVersion}/${loader}/server/jar`;
        } else if (serverType === 'forge') {
            // Forge installer
            url = `https://maven.minecraftforge.net/net/minecraftforge/forge/${actualVersion}/forge-${actualVersion}-installer.jar`;
        } else if (serverType === 'velocity') {
            const buildsRes = await axios.get(`https://api.papermc.io/v2/projects/velocity/versions/${actualVersion}/builds`);
            const build = buildsRes.data.builds[buildsRes.data.builds.length - 1];
            url = `https://api.papermc.io/v2/projects/velocity/versions/${actualVersion}/builds/${build.build}/downloads/velocity-${actualVersion}-${build.build}.jar`;
        } else if (serverType === 'waterfall') {
            const buildsRes = await axios.get(`https://api.papermc.io/v2/projects/waterfall/versions/${actualVersion}/builds`);
            const build = buildsRes.data.builds[buildsRes.data.builds.length - 1];
            url = `https://api.papermc.io/v2/projects/waterfall/versions/${actualVersion}/builds/${build.build}/downloads/waterfall-${actualVersion}-${build.build}.jar`;
        } else if (serverType === 'bungeecord') {
            url = 'https://ci.md-5.net/job/BungeeCord/lastSuccessfulBuild/artifact/bootstrap/target/BungeeCord.jar';
        } else {
            throw new Error(`Unsupported server type: ${serverType}`);
        }
        
        const jarPath = path.join(dir, 'server.jar');
        let downloadPath = jarPath;
        
        // Ensure the directory exists
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
            console.log(`📁 Created directory: ${dir}`);
        }
        
        console.log(`📥 Downloading from: ${url}`);
        
        try {
            const response = await axios({
                url,
                method: 'GET',
                responseType: 'stream',
                headers: { 
                    'User-Agent': 'Mozilla/5.0 (compatible; Minecraft Server Panel)',
                    'Accept': 'application/java-archive, application/octet-stream, */*'
                },
                timeout: 300000, // 5 minute timeout
                validateStatus: () => true // Don't throw on 410/404, handle manually
            });
            
            // Check for error status codes
            if (response.status === 410) {
                throw new Error(`The requested build is no longer available on the API (410 Gone). Version ${actualVersion} may be too old. Please try a newer version.`);
            } else if (response.status === 404) {
                throw new Error(`${serverType} version ${actualVersion} not found (404). Please check if this version exists.`);
            } else if (response.status >= 400) {
                throw new Error(`Download failed with status ${response.status}: ${response.statusText}`);
            }
            
            const writer = fs.createWriteStream(downloadPath);
            const totalLength = parseInt(response.headers['content-length'], 10);
            let downloadedLength = 0;
            
            return new Promise((resolve, reject) => {
                response.data.on('data', (chunk) => {
                    downloadedLength += chunk.length;
                    if (totalLength) {
                        const percent = Math.round((downloadedLength / totalLength) * 100);
                        if (percent % 10 === 0) { // Log every 10%
                            console.log(`📊 Download progress: ${percent}% (${Math.round(downloadedLength / 1024 / 1024)}MB)`);
                        }
                    }
                });
                
                response.data.pipe(writer);
                
                writer.on('finish', () => {
                    const fileSizeMB = Math.round(downloadedLength / 1024 / 1024);
                    console.log(`✅ Successfully downloaded ${serverType} ${actualVersion} (${fileSizeMB}MB)`);
                    resolve(actualVersion);
                });
                
                writer.on('error', (err) => {
                    console.error(`❌ Error writing ${serverType} file:`, err.message);
                    reject(err);
                });
                
                response.data.on('error', (err) => {
                    console.error(`❌ Error downloading ${serverType}:`, err.message);
                    reject(err);
                });
            });
        } catch (downloadErr) {
            console.error(`❌ Download error for ${serverType} ${actualVersion}:`, downloadErr.message);
            throw downloadErr;
        }
    } catch (err) {
        console.error(`❌ Failed to download ${serverType} ${version}:`, err.message);
        
        // Provide helpful error messages
        if (err.code === 'ENOTFOUND') {
            throw new Error(`Network error: Could not connect to download server for ${serverType}`);
        } else if (err.code === 'ETIMEDOUT') {
            throw new Error(`Download timeout: ${serverType} download took too long (>5 minutes)`);
        } else if (err.response && err.response.status === 404) {
            throw new Error(`Version not found: ${serverType} ${version} is not available`);
        } else if (err.response && err.response.status === 403) {
            throw new Error(`Access denied: Cannot download ${serverType} ${version}`);
        } else {
            throw new Error(`Download failed: ${err.message}`);
        }
    }
}
// Plugin search and download helpers
async function searchModrinth(query, page = 1, limit = 12) {
    try {
        const offset = (page - 1) * limit;
        const res = await axios.get(`https://api.modrinth.com/v2/search`, {
            params: {
                query: query || '',
                limit: limit,
                offset: offset,
                facets: JSON.stringify([["project_type:plugin"], ["categories:bukkit", "categories:spigot", "categories:paper"]]),
            },
            headers: {
                'User-Agent': 'MinecraftPanel/1.0'
            }
        });
        
        return {
            plugins: (res.data.hits || []).map(p => ({
                id: p.project_id,
                name: p.title,
                slug: p.slug,
                description: p.description,
                author: p.author,
                downloads: p.downloads,
                follows: p.follows,
                categories: p.categories || [],
                source: 'modrinth',
                projectId: p.project_id,
                icon: p.icon_url || null,
                url: `https://modrinth.com/plugin/${p.slug}`,
                dateModified: p.date_modified,
                clientSide: p.client_side,
                serverSide: p.server_side,
                hasVersions: true
            })),
            totalHits: res.data.total_hits || 0
        };
    } catch (err) {
        console.error('Modrinth search error:', err.message);
        return { plugins: [], totalHits: 0 };
    }
}

async function searchSpigot(query, page = 1, limit = 12) {
    try {
        const searchQuery = query || 'popular';
        const res = await axios.get(`https://api.spiget.org/v2/search/resources/${encodeURIComponent(searchQuery)}`, {
            params: {
                size: limit,
                page: page - 1,
                sort: '-downloads',
                fields: 'id,name,tag,likes,downloads,rating,icon,premium,price,currency,file,author'
            },
            headers: {
                'User-Agent': 'MinecraftPanel/1.0'
            }
        });
        
        const plugins = (res.data || [])
            .filter(p => !p.premium)
            .map(p => ({
                id: p.id,
                name: p.name,
                description: p.tag || 'No description available',
                author: p.author?.name || 'Unknown',
                downloads: p.downloads || 0,
                rating: p.rating?.average || 0,
                likes: p.likes || 0,
                source: 'spiget',
                resourceId: p.id,
                icon: p.icon?.url ? `https://www.spigotmc.org/${p.icon.url}` : null,
                url: `https://www.spigotmc.org/resources/${p.id}/`,
                version: p.file?.version || 'Unknown',
                testedVersions: p.testedVersions || [],
                hasVersions: true
            }));
        
        return {
            plugins: plugins,
            totalHits: plugins.length
        };
    } catch (err) {
        console.error('Spigot search error:', err.message);
        return { plugins: [], totalHits: 0 };
    }
}

async function searchHangar(query, page = 1, limit = 12) {
    try {
        const offset = (page - 1) * limit;
        const res = await axios.get(`https://hangar.papermc.io/api/v1/projects`, {
            params: {
                q: query || '',
                limit: limit,
                offset: offset,
                sort: '-downloads',
                category: 'plugin'
            },
            headers: {
                'User-Agent': 'MinecraftPanel/1.0'
            }
        });
        
        const plugins = (res.data.result || []).map(p => ({
            id: p.name,
            name: p.name,
            slug: p.name,
            description: p.description || 'No description available',
            author: p.owner,
            downloads: p.stats?.downloads || 0,
            views: p.stats?.views || 0,
            stars: p.stats?.stars || 0,
            watchers: p.stats?.watchers || 0,
            categories: p.category ? [p.category] : [],
            source: 'hangar',
            projectId: p.name,
            icon: p.avatarUrl || null,
            url: `https://hangar.papermc.io/${p.owner}/${p.name}`,
            hasVersions: true
        }));
        
        return {
            plugins: plugins,
            totalHits: res.data.pagination?.count || plugins.length
        };
    } catch (err) {
        console.error('Hangar search error:', err.message);
        return { plugins: [], totalHits: 0 };
    }
}

async function searchBukkit(query, page = 1, limit = 12) {
    try {
        // CurseForge API for Bukkit plugins
        const res = await axios.get(`https://api.curseforge.com/v1/mods/search`, {
            params: {
                gameId: 432, // Minecraft
                classId: 5, // Bukkit Plugins
                searchFilter: query || '',
                pageSize: limit,
                index: (page - 1) * limit,
                sortField: 2, // Popularity
                sortOrder: 'desc'
            },
            headers: {
                'User-Agent': 'MinecraftPanel/1.0',
                'x-api-key': '$2a$10$bL4bIL5pUWqfcO7KQtnMReakwtfHbNKh6v1uTpKlzhwoueEJQnPnm' // Public demo key
            }
        });
        
        const plugins = (res.data.data || []).map(p => ({
            id: p.id,
            name: p.name,
            slug: p.slug,
            description: p.summary || 'No description available',
            author: p.authors?.[0]?.name || 'Unknown',
            downloads: p.downloadCount || 0,
            categories: (p.categories || []).map(c => c.name),
            source: 'bukkit',
            projectId: p.id,
            icon: p.logo?.thumbnailUrl || null,
            url: p.links?.websiteUrl || `https://www.curseforge.com/minecraft/bukkit-plugins/${p.slug}`,
            dateModified: p.dateModified,
            hasVersions: true
        }));
        
        return {
            plugins: plugins,
            totalHits: res.data.pagination?.totalCount || plugins.length
        };
    } catch (err) {
        console.error('Bukkit search error:', err.message);
        return { plugins: [], totalHits: 0 };
    }
}

async function searchPlugins(query, page = 1, limit = 12, provider = 'all') {
    const perProvider = Math.ceil(limit / 4);
    
    if (provider === 'modrinth') {
        return await searchModrinth(query, page, limit);
    } else if (provider === 'spiget') {
        return await searchSpigot(query, page, limit);
    } else if (provider === 'hangar') {
        return await searchHangar(query, page, limit);
    } else if (provider === 'bukkit') {
        return await searchBukkit(query, page, limit);
    } else {
        // Search all providers
        const [modrinth, spigot, hangar, bukkit] = await Promise.all([
            searchModrinth(query, page, perProvider),
            searchSpigot(query, page, perProvider),
            searchHangar(query, page, perProvider),
            searchBukkit(query, page, perProvider)
        ]);
        
        return {
            plugins: [...modrinth.plugins, ...spigot.plugins, ...hangar.plugins, ...bukkit.plugins],
            totalHits: modrinth.totalHits + spigot.totalHits + hangar.totalHits + bukkit.totalHits
        };
    }
}
async function getModrinthDownloadUrl(projectId, versionId = null) {
    try {
        // Get all versions for the project
        const res = await axios.get(`https://api.modrinth.com/v2/project/${projectId}/version`, {
            headers: {
                'User-Agent': 'MinecraftPanel/1.0'
            }
        });
        
        if (res.data && res.data.length > 0) {
            // If specific version requested, find it
            let targetVersion = versionId 
                ? res.data.find(v => v.id === versionId)
                : res.data[0]; // Latest version
            
            if (!targetVersion) targetVersion = res.data[0];
            
            // Get the primary file (usually the first one)
            if (targetVersion.files && targetVersion.files.length > 0) {
                const primaryFile = targetVersion.files.find(f => f.primary) || targetVersion.files[0];
                return {
                    url: primaryFile.url,
                    filename: primaryFile.filename,
                    version: targetVersion.version_number,
                    versionId: targetVersion.id
                };
            }
        }
        throw new Error('No files found for this project');
    } catch (err) {
        console.error('Modrinth URL fetch error:', err.message);
        return null;
    }
}

async function getModrinthVersions(projectId) {
    try {
        const res = await axios.get(`https://api.modrinth.com/v2/project/${projectId}/version`, {
            headers: {
                'User-Agent': 'MinecraftPanel/1.0'
            }
        });
        
        return (res.data || []).map(v => ({
            id: v.id,
            name: v.name,
            versionNumber: v.version_number,
            gameVersions: v.game_versions || [],
            loaders: v.loaders || [],
            datePublished: v.date_published,
            downloads: v.downloads || 0,
            featured: v.featured || false
        }));
    } catch (err) {
        console.error('Modrinth versions fetch error:', err.message);
        return [];
    }
}

async function getSpigetDownloadUrl(resourceId, versionId = null) {
    try {
        // Get resource details to get the latest version
        const res = await axios.get(`https://api.spiget.org/v2/resources/${resourceId}`, {
            headers: {
                'User-Agent': 'MinecraftPanel/1.0'
            }
        });
        
        if (res.data) {
            return {
                url: versionId 
                    ? `https://api.spiget.org/v2/resources/${resourceId}/versions/${versionId}/download`
                    : `https://api.spiget.org/v2/resources/${resourceId}/download`,
                filename: `${sanitize(res.data.name)}.jar`,
                version: res.data.file?.version || 'latest'
            };
        }
        throw new Error('Resource not found');
    } catch (err) {
        console.error('Spiget URL fetch error:', err.message);
        return null;
    }
}

async function getSpigetVersions(resourceId) {
    try {
        const res = await axios.get(`https://api.spiget.org/v2/resources/${resourceId}/versions`, {
            params: {
                size: 50,
                sort: '-releaseDate'
            },
            headers: {
                'User-Agent': 'MinecraftPanel/1.0'
            }
        });
        
        return (res.data || []).map(v => ({
            id: v.id,
            name: v.name,
            versionNumber: v.name,
            releaseDate: v.releaseDate,
            downloads: v.downloads || 0
        }));
    } catch (err) {
        console.error('Spiget versions fetch error:', err.message);
        return [];
    }
}

async function getHangarDownloadUrl(projectId, versionId = null) {
    try {
        const res = await axios.get(`https://hangar.papermc.io/api/v1/projects/${projectId}/versions`, {
            params: {
                limit: 25,
                offset: 0
            },
            headers: {
                'User-Agent': 'MinecraftPanel/1.0'
            }
        });
        
        if (res.data.result && res.data.result.length > 0) {
            const targetVersion = versionId
                ? res.data.result.find(v => v.name === versionId)
                : res.data.result[0];
            
            if (targetVersion) {
                // Hangar uses platform-specific downloads
                const platforms = Object.keys(targetVersion.downloads || {});
                if (platforms.length > 0) {
                    const platform = platforms[0]; // Use first available platform (usually PAPER)
                    const downloadUrl = `https://hangar.papermc.io/api/v1/projects/${projectId}/versions/${targetVersion.name}/${platform}/download`;
                    
                    return {
                        url: downloadUrl,
                        filename: `${sanitize(projectId)}-${targetVersion.name}.jar`,
                        version: targetVersion.name
                    };
                }
            }
        }
        throw new Error('No versions found');
    } catch (err) {
        console.error('Hangar URL fetch error:', err.message);
        return null;
    }
}

async function getHangarVersions(projectId) {
    try {
        const res = await axios.get(`https://hangar.papermc.io/api/v1/projects/${projectId}/versions`, {
            headers: {
                'User-Agent': 'MinecraftPanel/1.0'
            }
        });
        
        return (res.data.result || []).map(v => ({
            id: v.name,
            name: v.name,
            versionNumber: v.name,
            platformDependencies: v.platformDependencies || {},
            downloads: v.stats?.downloads || 0
        }));
    } catch (err) {
        console.error('Hangar versions fetch error:', err.message);
        return [];
    }
}

async function getBukkitDownloadUrl(projectId, fileId = null) {
    try {
        if (fileId) {
            // Get specific file
            const res = await axios.get(`https://api.curseforge.com/v1/mods/${projectId}/files/${fileId}`, {
                headers: {
                    'User-Agent': 'MinecraftPanel/1.0',
                    'x-api-key': '$2a$10$bL4bIL5pUWqfcO7KQtnMReakwtfHbNKh6v1uTpKlzhwoueEJQnPnm'
                }
            });
            
            if (res.data.data && res.data.data.downloadUrl) {
                return {
                    url: res.data.data.downloadUrl,
                    filename: res.data.data.fileName,
                    version: res.data.data.displayName
                };
            }
        } else {
            // Get latest file
            const res = await axios.get(`https://api.curseforge.com/v1/mods/${projectId}/files`, {
                params: {
                    pageSize: 10,
                    index: 0
                },
                headers: {
                    'User-Agent': 'MinecraftPanel/1.0',
                    'x-api-key': '$2a$10$bL4bIL5pUWqfcO7KQtnMReakwtfHbNKh6v1uTpKlzhwoueEJQnPnm'
                }
            });
            
            if (res.data.data && res.data.data.length > 0) {
                // Find first file with a download URL
                const file = res.data.data.find(f => f.downloadUrl);
                if (file && file.downloadUrl) {
                    return {
                        url: file.downloadUrl,
                        filename: file.fileName,
                        version: file.displayName
                    };
                }
            }
        }
        throw new Error('No downloadable files found');
    } catch (err) {
        console.error('Bukkit URL fetch error:', err.message);
        return null;
    }
}

async function getBukkitVersions(projectId) {
    try {
        const res = await axios.get(`https://api.curseforge.com/v1/mods/${projectId}/files`, {
            params: {
                pageSize: 50,
                index: 0
            },
            headers: {
                'User-Agent': 'MinecraftPanel/1.0',
                'x-api-key': '$2a$10$bL4bIL5pUWqfcO7KQtnMReakwtfHbNKh6v1uTpKlzhwoueEJQnPnm'
            }
        });
        
        return (res.data.data || []).map(f => ({
            id: f.id,
            name: f.displayName,
            versionNumber: f.displayName,
            gameVersions: f.gameVersions || [],
            fileDate: f.fileDate,
            downloads: f.downloadCount || 0
        }));
    } catch (err) {
        console.error('Bukkit versions fetch error:', err.message);
        return [];
    }
}
async function downloadPluginJar(downloadUrl, destPath) {
    try {
        console.log(`Attempting to download from: ${downloadUrl}`);
        console.log(`Destination: ${destPath}`);
        
        // Validate URL
        if (!downloadUrl || !downloadUrl.startsWith('http')) {
            throw new Error('Invalid download URL');
        }
        
        const response = await axios({
            url: downloadUrl,
            method: 'GET',
            responseType: 'stream',
            maxRedirects: 10,
            timeout: 60000, // 60 second timeout
            headers: { 
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': '*/*'
            },
            validateStatus: function (status) {
                return status >= 200 && status < 400; // Accept redirects
            }
        });
        
        // Check if response is valid
        if (!response.data) {
            throw new Error('No data received from download URL');
        }
        
        // Ensure directory exists
        fs.mkdirSync(path.dirname(destPath), { recursive: true });
        
        const writer = fs.createWriteStream(destPath);
        
        return new Promise((resolve, reject) => {
            let downloadedBytes = 0;
            
            response.data.on('data', (chunk) => {
                downloadedBytes += chunk.length;
            });
            
            response.data.pipe(writer);
            
            writer.on('finish', () => {
                console.log(`Download complete: ${downloadedBytes} bytes written to ${destPath}`);
                
                // Verify file was created and has content
                if (fs.existsSync(destPath)) {
                    const stats = fs.statSync(destPath);
                    if (stats.size > 0) {
                        resolve();
                    } else {
                        fs.unlinkSync(destPath); // Remove empty file
                        reject(new Error('Downloaded file is empty'));
                    }
                } else {
                    reject(new Error('File was not created'));
                }
            });
            
            writer.on('error', (err) => {
                console.error('Writer error:', err);
                // Clean up partial file
                if (fs.existsSync(destPath)) {
                    fs.unlinkSync(destPath);
                }
                reject(err);
            });
            
            response.data.on('error', (err) => {
                console.error('Stream error:', err);
                writer.close();
                // Clean up partial file
                if (fs.existsSync(destPath)) {
                    fs.unlinkSync(destPath);
                }
                reject(err);
            });
        });
    } catch (err) {
        console.error('Download error:', err.message);
        console.error('URL:', downloadUrl);
        
        // Clean up any partial file
        if (fs.existsSync(destPath)) {
            try {
                fs.unlinkSync(destPath);
            } catch (cleanupErr) {
                console.error('Cleanup error:', cleanupErr);
            }
        }
        
        throw new Error(`Failed to download plugin: ${err.message}`);
    }
}
function getInstalledPlugins(serverId) {
    try {
        const pluginsDir = resolveServerPath(serverId, 'plugins');
        if (!fs.existsSync(pluginsDir)) fs.mkdirSync(pluginsDir, { recursive: true });
        return fs.readdirSync(pluginsDir).filter(f => f.endsWith('.jar'));
    } catch (err) {
        console.warn(`ℹ️ [Remote-Only] Plugin listing for server ${serverId} must use remote node agent`);
        return [];
    }
}
// Player and world helpers
function readPlayerFile(serverId, fileName) {
    try {
        const filePath = resolveServerPath(serverId, fileName);
        if (fs.existsSync(filePath)) {
            try {
                return JSON.parse(fs.readFileSync(filePath, 'utf8')) || [];
            } catch (err) {
                console.error(`Error reading ${fileName} for server ${serverId}`, err);
                return [];
            }
        }
        return [];
    } catch (err) {
        console.warn(`ℹ️ [Remote-Only] Player file reading for server ${serverId} must use remote node agent`);
        return [];
    }
}
function writePlayerFile(serverId, fileName, data) {
    try {
        const filePath = resolveServerPath(serverId, fileName);
        try {
            fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
        } catch (err) {
            console.error(`Error writing ${fileName} for server ${serverId}`, err);
        }
    } catch (err) {
        console.warn(`ℹ️ [Remote-Only] Player file writing for server ${serverId} must use remote node agent`);
    }
}
async function getUUID(name) {
    try {
        const { data } = await axios.get(`https://api.mojang.com/users/profiles/minecraft/${name}`);
        const id = data.id;
        return `${id.substr(0,8)}-${id.substr(8,4)}-${id.substr(12,4)}-${id.substr(16,4)}-${id.substr(20)}`;
    } catch {
        return null;
    }
}
// FIXED: executeCommand now uses screen (consistent with start/stop) - no more broken spawn
function executeCommand(serverId, cmd) {
  sendCommand(serverId, cmd).catch(err => console.error('Execute command failed:', err));
  return true; // backward compatible
}
function getOnlinePlayers(serverId) {
    // For remote servers: fetch from remote stats cache
    if (global.remoteServerStats && global.remoteServerStats[serverId]) {
        return global.remoteServerStats[serverId].playerList || [];
    }
    // Fallback: local players (legacy)
    return onlinePlayers[serverId] || [];
}
function getDirSize(dir) {
    try {
        let size = 0;
        const walk = (p) => {
            const stats = fs.statSync(p);
            if (stats.isDirectory()) {
                fs.readdirSync(p).forEach(f => walk(path.join(p, f)));
            } else {
                size += stats.size;
            }
        };
        walk(dir);
        return size;
    } catch (err) {
        return 0;
    }
}
async function getWorldInfo(worldDir, serverDir = null) {
    try {
        const levelPath = path.join(worldDir, 'level.dat');
        
        // If level.dat doesn't exist, try to get info from server.properties
        if (!fs.existsSync(levelPath)) {
            // Try to find server.properties in parent directory or provided serverDir
            const parentDir = serverDir || path.dirname(worldDir);
            const propertiesPath = path.join(parentDir, 'server.properties');
            
            if (fs.existsSync(propertiesPath)) {
                try {
                    const propertiesContent = fs.readFileSync(propertiesPath, 'utf8');
                    const properties = parseProperties(propertiesContent);
                    
                    // Get seed (handle empty string)
                    const seed = properties['level-seed'] && properties['level-seed'].trim() !== '' 
                        ? properties['level-seed'] 
                        : 'Random';
                    
                    // Capitalize difficulty and gamemode for display
                    const difficulty = (properties['difficulty'] || 'easy').toString().charAt(0).toUpperCase() + (properties['difficulty'] || 'easy').toString().slice(1);
                    const gameType = (properties['gamemode'] || 'survival').toString().charAt(0).toUpperCase() + (properties['gamemode'] || 'survival').toString().slice(1);
                    
                    return {
                        seed: seed,
                        difficulty: difficulty,
                        gameType: gameType,
                        lastPlayed: 'Not yet started',
                        version: 'Pending first start'
                    };
                } catch (err) {
                    console.error(`Error reading server.properties for ${worldDir}:`, err);
                }
            }
            
            // Return default info for worlds without level.dat (not yet generated)
            return { 
                seed: 'Random', 
                difficulty: 'Easy', 
                gameType: 'Survival', 
                lastPlayed: 'Not yet started', 
                version: 'Pending first start' 
            };
        }
        
        const buf = fs.readFileSync(levelPath);
        const uncompressed = zlib.gunzipSync(buf);
        const parsed = await nbtParse(uncompressed);
        const simplified = prismarineNbt.simplify(parsed);
        const data = simplified.Data || {};
        let seed = 'Unknown';
        if (data.RandomSeed !== undefined) {
            seed = data.RandomSeed.value || data.RandomSeed;
        } else if (data.WorldGenSettings && data.WorldGenSettings.Seed !== undefined) {
            seed = data.WorldGenSettings.Seed.value || data.WorldGenSettings.Seed;
        }
        if (typeof seed === 'bigint') seed = seed.toString();
        const difficulty = data.Difficulty?.value ?? 1;
        const gameType = data.GameType?.value ?? 0;
        const lastPlayed = data.LastPlayed ? new Date(Number(data.LastPlayed)).toLocaleString() : 'Unknown';
        const mcVersion = data.DataVersion ? `MC ${data.DataVersion}` : 'Unknown';
        return {
            seed: seed.toString(),
            difficulty: ['Peaceful', 'Easy', 'Normal', 'Hard'][difficulty] || 'Unknown',
            gameType: ['Survival', 'Creative', 'Adventure', 'Spectator'][gameType] || 'Unknown',
            lastPlayed,
            version: mcVersion
        };
    } catch (err) {
        console.error(`Error parsing level.dat for ${worldDir}:`, err.message);
        return { seed: 'Unknown', difficulty: 'Unknown', gameType: 'Unknown', lastPlayed: 'Unknown', version: 'Unknown' };
    }
}
async function setWorldSeed(worldDir, newSeed) {
    try {
        const levelPath = path.join(worldDir, 'level.dat');
        const buf = fs.readFileSync(levelPath);
        const uncompressed = zlib.gunzipSync(buf);
        const parsed = await nbtParse(uncompressed);
        if (!parsed.value.Data) parsed.value.Data = { type: 'compound', value: {} };
        parsed.value.Data.value.Seed = { type: 'long', value: BigInt(newSeed) };
        const written = prismarineNbt.writeUncompressed(parsed);
        const compressed = zlib.gzipSync(written);
        fs.writeFileSync(levelPath, compressed);
    } catch (err) {
        throw err;
    }
}
// ================================================
// HELPER FUNCTIONS FOR PROFILE AND NOTIFICATIONS
// ================================================

// Helper function to get user statistics
async function getUserStats(userId) {
    try {
        // Get server count
        const serverCount = await dbGet('SELECT COUNT(*) as count FROM servers WHERE owner_id = ?', [userId]);
        
        // Get notification count
        const notificationCount = await dbGet('SELECT COUNT(*) as count FROM notifications WHERE user_id = ?', [userId]);
        const unreadNotificationCount = await dbGet('SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0', [userId]);
        
        // Get recent activity count (last 30 days)
        const recentActivityCount = await dbGet(`
            SELECT COUNT(*) as count FROM user_activity 
            WHERE user_id = ? AND created_at >= datetime('now', '-30 days')
        `, [userId]);

        // Get account age
        const user = await dbGet('SELECT created_at FROM users WHERE id = ?', [userId]);
        const accountAge = user ? Math.floor((Date.now() - new Date(user.created_at).getTime()) / (1000 * 60 * 60 * 24)) : 0;

        return {
            servers: serverCount ? serverCount.count : 0,
            notifications: notificationCount ? notificationCount.count : 0,
            unreadNotifications: unreadNotificationCount ? unreadNotificationCount.count : 0,
            recentActivity: recentActivityCount ? recentActivityCount.count : 0,
            accountAge
        };
    } catch (error) {
        console.error('Error getting user stats:', error);
        return {
            servers: 0,
            notifications: 0,
            unreadNotifications: 0,
            recentActivity: 0,
            accountAge: 0
        };
    }
}

// Notification helper functions
async function getUserNotifications(userId, limit = 50, unreadOnly = false) {
    try {
        let sql = 'SELECT * FROM notifications WHERE user_id = ?';
        const params = [userId];
        
        if (unreadOnly) {
            sql += ' AND is_read = 0';
        }
        
        sql += ' ORDER BY created_at DESC LIMIT ?';
        params.push(limit);
        
        return await dbAll(sql, params);
    } catch (error) {
        console.error('Get user notifications error:', error);
        return [];
    }
}

async function getUnreadNotificationCount(userId) {
    try {
        const result = await dbGet('SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0', [userId]);
        return result ? result.count : 0;
    } catch (error) {
        console.error('Get unread notification count error:', error);
        return 0;
    }
}

async function markNotificationAsRead(notificationId, userId) {
    try {
        const result = await dbRun('UPDATE notifications SET is_read = 1, updated_at = datetime(\'now\') WHERE id = ? AND user_id = ?', [notificationId, userId]);
        return result.changes > 0;
    } catch (error) {
        console.error('Mark notification as read error:', error);
        return false;
    }
}

async function markAllNotificationsAsRead(userId, category = null) {
    try {
        let sql = 'UPDATE notifications SET is_read = 1, updated_at = datetime(\'now\') WHERE user_id = ?';
        const params = [userId];
        
        if (category) {
            sql += ' AND category = ?';
            params.push(category);
        }
        
        await dbRun(sql, params);
        return true;
    } catch (error) {
        console.error('Mark all notifications as read error:', error);
        return false;
    }
}

async function clearAllNotifications(userId, category = null) {
    try {
        let sql = 'DELETE FROM notifications WHERE user_id = ?';
        const params = [userId];
        
        if (category) {
            sql += ' AND category = ?';
            params.push(category);
        }
        
        await dbRun(sql, params);
        return true;
    } catch (error) {
        console.error('Clear all notifications error:', error);
        return false;
    }
}

async function createNotification(userId, title, message, type = 'info', options = {}) {
    try {
        const icon = options.icon || getIconForType(type);
        const category = options.category || 'general';
        
        await dbRun(`
            INSERT INTO notifications (user_id, title, message, type, category, icon, action_url, action_text, metadata, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
        `, [userId, title, message, type, category, icon, options.action_url || null, options.action_text || null, JSON.stringify(options) || null]);
        
        return true;
    } catch (error) {
        console.error('Create notification error:', error);
        return false;
    }
}

function getIconForType(type) {
    const icons = {
        success: 'check-circle',
        info: 'info-circle',
        warning: 'exclamation-triangle',
        error: 'exclamation-circle',
        system: 'cog'
    };
    return icons[type] || 'bell';
}

// Helper function to get notifications with pagination and filtering
async function getNotificationsPaginated(userId, page = 1, limit = 20, filter = 'all', category = 'all') {
    try {
        const offset = (page - 1) * limit;

        let whereClause = 'WHERE user_id = ?';
        let params = [userId];

        // Add filter conditions
        if (filter === 'unread') {
            whereClause += ' AND is_read = 0';
        } else if (filter === 'read') {
            whereClause += ' AND is_read = 1';
        }

        if (category !== 'all') {
            whereClause += ' AND category = ?';
            params.push(category);
        }

        // Get notifications
        const notifications = await dbAll(`
            SELECT * FROM notifications 
            ${whereClause}
            ORDER BY created_at DESC 
            LIMIT ? OFFSET ?
        `, [...params, limit, offset]);

        // Get total count
        const totalResult = await dbGet(`
            SELECT COUNT(*) as count FROM notifications ${whereClause}
        `, params);

        const total = totalResult ? totalResult.count : 0;
        const pages = Math.ceil(total / limit);

        return {
            data: notifications,
            pagination: {
                page,
                limit,
                total,
                pages,
                hasNext: page < pages,
                hasPrev: page > 1
            }
        };

    } catch (error) {
        console.error('Get notifications paginated error:', error);
        throw error;
    }
}

// Helper function to get notification statistics
async function getNotificationStats(userId) {
    try {
        // Get total counts
        const total = await dbGet('SELECT COUNT(*) as count FROM notifications WHERE user_id = ?', [userId]);
        const unread = await dbGet('SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0', [userId]);
        const today = await dbGet(`
            SELECT COUNT(*) as count FROM notifications 
            WHERE user_id = ? AND date(created_at) = date('now')
        `, [userId]);
        const thisWeek = await dbGet(`
            SELECT COUNT(*) as count FROM notifications 
            WHERE user_id = ? AND created_at >= datetime('now', '-7 days')
        `, [userId]);

        // Get category breakdown
        const categories = await dbAll(`
            SELECT category, COUNT(*) as count 
            FROM notifications 
            WHERE user_id = ? 
            GROUP BY category 
            ORDER BY count DESC
        `, [userId]);

        // Get type breakdown
        const types = await dbAll(`
            SELECT type, COUNT(*) as count 
            FROM notifications 
            WHERE user_id = ? 
            GROUP BY type 
            ORDER BY count DESC
        `, [userId]);

        return {
            total: total ? total.count : 0,
            unread: unread ? unread.count : 0,
            read: total ? total.count - (unread ? unread.count : 0) : 0,
            today: today ? today.count : 0,
            thisWeek: thisWeek ? thisWeek.count : 0,
            categories: categories || [],
            types: types || []
        };

    } catch (error) {
        console.error('Get notification stats error:', error);
        return {
            total: 0,
            unread: 0,
            read: 0,
            today: 0,
            thisWeek: 0,
            categories: [],
            types: []
        };
    }
}

// ================================================
// AUTHENTICATION ROUTES
// ================================================
app.get('/auth/login', async (req, res) => {
    if (req.session.user) return res.redirect('/dashboard');
    res.render('auth/login', await getTemplateVars(req, null, { error: null, title: 'Login' }));
});
app.post('/auth/login', async (req, res) => {
    const { username, password } = req.body;
  
    try {
        const user = await dbGet('SELECT * FROM users WHERE username = ? OR email = ?', [username, username]);
      
        if (!user) {
            return res.render('auth/login', await getTemplateVars(req, null, { error: 'Invalid username/email or password', title: 'Login' }));
        }
     
        if (user.status === 'suspended') {
            return res.render('auth/login', await getTemplateVars(req, null, { error: 'Account suspended', title: 'Login' }));
        }
     
        const validPassword = await bcrypt.compare(password, user.password);
        if (!validPassword) {
            return res.render('auth/login', await getTemplateVars(req, null, { error: 'Invalid username or password', title: 'Login' }));
        }
     
        req.session.user = {
            id: user.id,
            username: user.username,
            email: user.email,
            role: user.role
        };
     
        // Create login notification
        await createNotification(user.id, 'Login Successful', `You logged in to your account`, 'success', {
            icon: 'sign-in-alt',
            type: 'account'
        });
     
        res.redirect('/dashboard');
    } catch (err) {
        console.error('Login error:', err);
        res.render('auth/login', await getTemplateVars(req, null, { error: 'Server error', title: 'Login' }));
    }
});
app.get('/auth/register', (req, res) => {
    if (!globalSettings.registrationEnabled) {
        return res.redirect('/auth/login');
    }
    if (req.session.user) return res.redirect('/dashboard');
    res.render('auth/register', { error: null });
});
app.post('/auth/register', async (req, res) => {
    if (!globalSettings.registrationEnabled) {
        return res.redirect('/auth/login');
    }
 
    const { username, email, password, confirmPassword } = req.body;
 
    if (password !== confirmPassword) {
        return res.render('auth/register', { error: 'Passwords do not match' });
    }
 
    try {
        const existing = await dbGet(
            'SELECT * FROM users WHERE username = ? OR email = ?',
            [username, email]
        );
     
        if (existing) {
            return res.render('auth/register', { error: 'Username or email already exists' });
        }
     
        const hashedPassword = await bcrypt.hash(password, 10);
        await dbRun(
            'INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
            [username, email, hashedPassword]
        );
     
        res.redirect('/auth/login?success=Registration successful');
    } catch (err) {
        console.error('Registration error:', err);
        res.render('auth/register', { error: 'Registration failed' });
    }
});
app.get('/auth/logout', async (req, res) => {
    const userId = req.session.user?.id;
    
    // Create logout notification before destroying session
    if (userId) {
        await createNotification(userId, 'Logout', `You logged out of your account`, 'info', {
            icon: 'sign-out-alt',
            type: 'account'
        });
    }
    
    req.session.destroy();
    res.redirect('/auth/login');
});
// ================================================
// MAIN ROUTES
// ================================================
app.get('/', (req, res) => {
    if (req.session.user) {
        res.redirect('/dashboard');
    } else {
        res.redirect('/auth/login');
    }
});
app.get('/dashboard', requireAuth, async (req, res) => {
    try {
      let servers = [];
 
      if (req.session.user.role === 'admin') {
        servers = await dbAll(`
          SELECT s.*, u.username AS owner_name, n.ip_address AS node_ip, n.ip_alias AS node_ip_alias
          FROM servers s
          LEFT JOIN users u ON s.owner_id = u.id
          LEFT JOIN nodes n ON s.node_id = n.id
          ORDER BY s.created_at DESC
        `);
      } else {
        // Get servers owned by user OR where user is a subuser
        servers = await dbAll(`
          SELECT DISTINCT s.*, u.username AS owner_name, n.ip_address AS node_ip, n.ip_alias AS node_ip_alias,
                 CASE WHEN s.owner_id = ? THEN 1 ELSE 0 END as is_owner
          FROM servers s
          LEFT JOIN users u ON s.owner_id = u.id
          LEFT JOIN nodes n ON s.node_id = n.id
          LEFT JOIN subusers su ON s.id = su.server_id
          WHERE s.owner_id = ? OR su.user_id = ?
          ORDER BY is_owner DESC, s.created_at DESC
        `, [req.session.user.id, req.session.user.id, req.session.user.id]);
      }
      
      // ✅ Correct server statuses in real-time (fix stale status issue)
      for (const server of servers) {
        const { status: actualStatus } = await getServerStatus(server.id);
        server.status = actualStatus; // Update in-memory object for display
      }
 
      // ✅ ALWAYS define these so EJS never throws ReferenceError
      const onlinePlayersLocal = {};
      const messages = [];
 
      res.render('dashboard', await getTemplateVars(req, null, {
        servers,
        onlinePlayers: onlinePlayersLocal,
        messages,
        currentPage: 'dashboard',
        totalServers: servers.length,
        title: 'Dashboard'
      }));
 
    } catch (err) {
      console.error('Dashboard error:', err);
      res.status(500).render('error', await getTemplateVars(req, null, {
        message: 'Failed to load dashboard',
        status: 500,
        title: 'Error'
      }));
    }
  });

// ================================================
// ROUTES
// ================================================

// ================================================
// PROFILE ROUTES
// ================================================

// Configure multer for profile picture uploads
const profileStorage = multer.diskStorage({
    destination: function (req, file, cb) {
        const uploadDir = path.join(__dirname, 'public/uploads/profiles');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, 'profile-' + req.session.user.id + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const profileUpload = multer({
    storage: profileStorage,
    limits: {
        fileSize: 10 * 1024 * 1024 // 10MB limit for profile pictures
    },
    fileFilter: function (req, file, cb) {
        const allowedTypes = /jpeg|jpg|png|gif|webp/;
        const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = allowedTypes.test(file.mimetype);

        if (mimetype && extname) {
            return cb(null, true);
        } else {
            cb(new Error('Only image files are allowed!'));
        }
    }
});

// Profile page
app.get('/profile', requireAuth, async (req, res) => {
    try {
        // Get user with all profile data
        const user = await dbGet(`
            SELECT u.*, up.* 
            FROM users u 
            LEFT JOIN user_profiles up ON u.id = up.user_id 
            WHERE u.id = ?
        `, [req.session.user.id]);

        if (!user) {
            return res.redirect('/auth/login');
        }

        // Get user statistics
        const stats = await getUserStats(req.session.user.id);
        
        res.render('profile/index', await getTemplateVars(req, null, {
            user: {
                ...user,
                theme_preference: user.theme_preference || 'dark',
                theme_primary_color: user.theme_primary_color || '#2d6a4f',
                theme_accent_color: user.theme_accent_color || '#40916c',
                language: user.language || 'en',
                timezone: user.timezone || 'UTC',
                email_notifications: user.email_notifications !== 0,
                push_notifications: user.push_notifications !== 0,
                security_notifications: user.security_notifications !== 0
            },
            stats,
            currentPage: 'profile',
            title: 'Profile Settings'
        }));
    } catch (error) {
        console.error('Profile page error:', error);
        res.status(500).render('error', await getTemplateVars(req, null, { 
            error: 'Failed to load profile',
            message: 'Failed to load profile',
            status: 500,
            title: 'Error'
        }));
    }
});

// Update profile
app.post('/profile/update', requireAuth, async (req, res) => {
    try {
        const userId = req.session.user.id;
        
        // Get current user data first
        const currentUser = await dbGet('SELECT * FROM users WHERE id = ?', [userId]);
        if (!currentUser) {
            return res.json({ success: false, error: 'User not found' });
        }
        
        const {
            display_name,
            email,
            bio,
            location,
            website,
            current_password,
            new_password,
            theme_preference,
            theme_primary_color,
            theme_accent_color,
            language,
            timezone,
            email_notifications,
            push_notifications,
            security_notifications,
            two_factor_enabled
        } = req.body;

        // Use current email if not provided
        const newEmail = email || currentUser.email;

        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(newEmail)) {
            return res.json({ success: false, error: 'Invalid email format' });
        }

        // Check if email is already taken by another user
        if (newEmail !== currentUser.email) {
            const existingUser = await dbGet('SELECT id FROM users WHERE email = ? AND id != ?', [newEmail, userId]);
            if (existingUser) {
                return res.json({ success: false, error: 'Email is already taken' });
            }
        }

        // Handle password change
        let passwordUpdate = '';
        let updateParams = [];

        if (new_password && current_password) {
            // Verify current password
            if (!bcrypt.compareSync(current_password, currentUser.password)) {
                return res.json({ success: false, error: 'Current password is incorrect' });
            }

            // Validate new password strength
            if (new_password.length < 6) {
                return res.json({ success: false, error: 'New password must be at least 6 characters long' });
            }

            const hashedPassword = bcrypt.hashSync(new_password, 12);
            passwordUpdate = ', password = ?';
            updateParams.push(hashedPassword);
        }

        // Update users table only if email or password changed
        if (newEmail !== currentUser.email || passwordUpdate) {
            const userUpdateQuery = `
                UPDATE users 
                SET email = ?${passwordUpdate}
                WHERE id = ?
            `;
            updateParams.unshift(newEmail);
            updateParams.push(userId);

            await dbRun(userUpdateQuery, updateParams);
        }

        // Update or insert user profile
        const profileData = {
            display_name: display_name || null,
            bio: bio || null,
            location: location || null,
            website: website || null,
            theme_preference: theme_preference || 'dark',
            theme_primary_color: theme_primary_color || '#2d6a4f',
            theme_accent_color: theme_accent_color || '#40916c',
            language: language || 'en',
            timezone: timezone || 'UTC',
            email_notifications: email_notifications ? 1 : 0,
            push_notifications: push_notifications ? 1 : 0,
            security_notifications: security_notifications ? 1 : 0,
            two_factor_enabled: two_factor_enabled ? 1 : 0
        };

        // Check if profile exists
        const existingProfile = await dbGet('SELECT user_id FROM user_profiles WHERE user_id = ?', [userId]);

        if (existingProfile) {
            // Update existing profile
            await dbRun(`
                UPDATE user_profiles 
                SET display_name = ?, bio = ?, location = ?, website = ?,
                    theme_preference = ?, theme_primary_color = ?, theme_accent_color = ?,
                    language = ?, timezone = ?, email_notifications = ?, 
                    push_notifications = ?, security_notifications = ?, two_factor_enabled = ?,
                    updated_at = datetime('now')
                WHERE user_id = ?
            `, [
                profileData.display_name, profileData.bio, profileData.location, profileData.website,
                profileData.theme_preference, profileData.theme_primary_color, profileData.theme_accent_color,
                profileData.language, profileData.timezone, profileData.email_notifications,
                profileData.push_notifications, profileData.security_notifications, profileData.two_factor_enabled,
                userId
            ]);
        } else {
            // Insert new profile
            await dbRun(`
                INSERT INTO user_profiles (
                    user_id, display_name, bio, location, website,
                    theme_preference, theme_primary_color, theme_accent_color,
                    language, timezone, email_notifications, push_notifications, 
                    security_notifications, two_factor_enabled, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
            `, [
                userId, profileData.display_name, profileData.bio, profileData.location, profileData.website,
                profileData.theme_preference, profileData.theme_primary_color, profileData.theme_accent_color,
                profileData.language, profileData.timezone, profileData.email_notifications,
                profileData.push_notifications, profileData.security_notifications, profileData.two_factor_enabled
            ]);
        }

        // Update session data
        req.session.user.email = email;
        req.session.user.display_name = display_name;

        // Create notification for profile update
        await createNotification(
            userId,
            'Profile Updated',
            'Your profile settings have been successfully updated.',
            'success',
            { category: 'account' }
        );

        res.json({ success: true, message: 'Profile updated successfully' });

    } catch (error) {
        console.error('Profile update error:', error);
        res.json({ success: false, error: 'Failed to update profile' });
    }
});

// Upload profile picture
app.post('/profile/upload-picture', requireAuth, profileUpload.single('profile_picture'), async (req, res) => {
    try {
        if (!req.file) {
            return res.json({ success: false, error: 'No file uploaded' });
        }

        const userId = req.session.user.id;
        const profilePicturePath = `/uploads/profiles/${req.file.filename}`;

        // Get old profile picture to delete it
        const oldProfile = await dbGet('SELECT profile_picture FROM user_profiles WHERE user_id = ?', [userId]);
        
        // Update profile picture in database
        const existingProfile = await dbGet('SELECT user_id FROM user_profiles WHERE user_id = ?', [userId]);
        
        if (existingProfile) {
            await dbRun('UPDATE user_profiles SET profile_picture = ?, updated_at = datetime(\'now\') WHERE user_id = ?', 
                [profilePicturePath, userId]);
        } else {
            await dbRun(`
                INSERT INTO user_profiles (user_id, profile_picture, created_at, updated_at) 
                VALUES (?, ?, datetime('now'), datetime('now'))
            `, [userId, profilePicturePath]);
        }

        // Delete old profile picture file
        if (oldProfile && oldProfile.profile_picture && oldProfile.profile_picture !== profilePicturePath) {
            const oldFilePath = path.join(__dirname, 'public', oldProfile.profile_picture);
            if (fs.existsSync(oldFilePath)) {
                fs.unlinkSync(oldFilePath);
            }
        }

        // Create notification
        await createNotification(
            userId,
            'Profile Picture Updated',
            'Your profile picture has been successfully updated.',
            'success',
            { category: 'account' }
        );

        res.json({ 
            success: true, 
            message: 'Profile picture updated successfully',
            profile_picture: profilePicturePath
        });

    } catch (error) {
        console.error('Profile picture upload error:', error);
        res.json({ success: false, error: 'Failed to upload profile picture' });
    }
});

// Delete profile picture
app.delete('/profile/delete-picture', requireAuth, async (req, res) => {
    try {
        const userId = req.session.user.id;

        // Get current profile picture
        const profile = await dbGet('SELECT profile_picture FROM user_profiles WHERE user_id = ?', [userId]);
        
        if (profile && profile.profile_picture) {
            // Delete file
            const filePath = path.join(__dirname, 'public', profile.profile_picture);
            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
            }

            // Update database
            await dbRun('UPDATE user_profiles SET profile_picture = NULL, updated_at = datetime(\'now\') WHERE user_id = ?', [userId]);

            // Create notification
            await createNotification(
                userId,
                'Profile Picture Removed',
                'Your profile picture has been removed.',
                'info',
                { category: 'account' }
            );
        }

        res.json({ success: true, message: 'Profile picture deleted successfully' });

    } catch (error) {
        console.error('Profile picture delete error:', error);
        res.json({ success: false, error: 'Failed to delete profile picture' });
    }
});

// Get user activity log
app.get('/profile/activity', requireAuth, async (req, res) => {
    try {
        const userId = req.session.user.id;
        const page = parseInt(req.query.page) || 1;
        const limit = 20;
        const offset = (page - 1) * limit;

        const activities = await dbAll(`
            SELECT * FROM user_activity 
            WHERE user_id = ? 
            ORDER BY created_at DESC 
            LIMIT ? OFFSET ?
        `, [userId, limit, offset]);

        const totalCount = await dbGet('SELECT COUNT(*) as count FROM user_activity WHERE user_id = ?', [userId]);

        res.json({
            success: true,
            activities,
            pagination: {
                page,
                limit,
                total: totalCount.count,
                pages: Math.ceil(totalCount.count / limit)
            }
        });

    } catch (error) {
        console.error('Activity log error:', error);
        res.json({ success: false, error: 'Failed to load activity log' });
    }
});

// ================================================
// NOTIFICATIONS ROUTES
// ================================================

// Notifications page
app.get('/notifications', requireAuth, async (req, res) => {
    try {
        const userId = req.session.user.id;
        const page = parseInt(req.query.page) || 1;
        const limit = 20;
        const filter = req.query.filter || 'all'; // all, unread, read
        const category = req.query.category || 'all'; // all, system, account, server, security

        // Get notifications with pagination
        const notifications = await getNotificationsPaginated(userId, page, limit, filter, category);
        const unreadCount = await getUnreadNotificationCount(userId);
        const stats = await getNotificationStats(userId);

        res.render('notifications/index', await getTemplateVars(req, null, {
            notifications: notifications.data,
            pagination: notifications.pagination,
            unreadCount,
            stats,
            currentFilter: filter,
            currentCategory: category,
            currentPage: 'notifications',
            title: 'Notifications'
        }));

    } catch (error) {
        console.error('Notifications page error:', error);
        res.status(500).render('error', await getTemplateVars(req, null, { 
            error: 'Failed to load notifications',
            message: 'Failed to load notifications',
            status: 500,
            title: 'Error'
        }));
    }
});

// Get notifications API (for AJAX)
app.get('/notifications/api', requireAuth, async (req, res) => {
    try {
        const userId = req.session.user.id;
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 20;
        const filter = req.query.filter || 'all';
        const category = req.query.category || 'all';

        const notifications = await getNotificationsPaginated(userId, page, limit, filter, category);
        const unreadCount = await getUnreadNotificationCount(userId);

        res.json({
            success: true,
            notifications: notifications.data,
            pagination: notifications.pagination,
            unreadCount
        });

    } catch (error) {
        console.error('Notifications API error:', error);
        res.json({ success: false, error: 'Failed to load notifications' });
    }
});

// Mark notification as read
app.post('/notifications/:id/read', requireAuth, async (req, res) => {
    try {
        const notificationId = req.params.id;
        const userId = req.session.user.id;

        const result = await markNotificationAsRead(notificationId, userId);
        
        if (result) {
            res.json({ success: true, message: 'Notification marked as read' });
        } else {
            res.json({ success: false, error: 'Notification not found or access denied' });
        }

    } catch (error) {
        console.error('Mark notification read error:', error);
        res.json({ success: false, error: 'Failed to mark notification as read' });
    }
});

// Mark all notifications as read
app.post('/notifications/mark-all-read', requireAuth, async (req, res) => {
    try {
        const userId = req.session.user.id;
        const category = req.body.category || null;

        await markAllNotificationsAsRead(userId, category);

        res.json({ success: true, message: 'All notifications marked as read' });

    } catch (error) {
        console.error('Mark all notifications read error:', error);
        res.json({ success: false, error: 'Failed to mark all notifications as read' });
    }
});

// Clear all notifications
app.delete('/notifications/clear-all', requireAuth, async (req, res) => {
    try {
        const userId = req.session.user.id;
        const category = req.body.category || null;

        await clearAllNotifications(userId, category);

        res.json({ success: true, message: 'All notifications cleared' });

    } catch (error) {
        console.error('Clear all notifications error:', error);
        res.json({ success: false, error: 'Failed to clear all notifications' });
    }
});

// Delete specific notification
app.delete('/notifications/:id', requireAuth, async (req, res) => {
    try {
        const notificationId = req.params.id;
        const userId = req.session.user.id;

        // Verify notification belongs to user
        const notification = await dbGet('SELECT id FROM notifications WHERE id = ? AND user_id = ?', [notificationId, userId]);
        
        if (!notification) {
            return res.json({ success: false, error: 'Notification not found or access denied' });
        }

        await dbRun('DELETE FROM notifications WHERE id = ? AND user_id = ?', [notificationId, userId]);

        res.json({ success: true, message: 'Notification deleted' });

    } catch (error) {
        console.error('Delete notification error:', error);
        res.json({ success: false, error: 'Failed to delete notification' });
    }
});

// Get notification settings
app.get('/notifications/settings', requireAuth, async (req, res) => {
    try {
        const userId = req.session.user.id;

        const settings = await dbGet(`
            SELECT email_notifications, push_notifications, security_notifications,
                   notification_frequency, quiet_hours_start, quiet_hours_end
            FROM user_profiles 
            WHERE user_id = ?
        `, [userId]);

        res.render('notifications/settings', await getTemplateVars(req, null, {
            settings: settings || {
                email_notifications: 1,
                push_notifications: 1,
                security_notifications: 1,
                notification_frequency: 'immediate',
                quiet_hours_start: null,
                quiet_hours_end: null
            },
            currentPage: 'notification-settings',
            title: 'Notification Settings'
        }));

    } catch (error) {
        console.error('Notification settings error:', error);
        res.status(500).render('error', await getTemplateVars(req, null, { 
            error: 'Failed to load notification settings',
            message: 'Failed to load notification settings',
            status: 500,
            title: 'Error'
        }));
    }
});

// Update notification settings
app.post('/notifications/settings', requireAuth, async (req, res) => {
    try {
        const userId = req.session.user.id;
        const {
            email_notifications,
            push_notifications,
            security_notifications,
            notification_frequency,
            quiet_hours_start,
            quiet_hours_end,
            categories
        } = req.body;

        // Check if profile exists
        const existingProfile = await dbGet('SELECT user_id FROM user_profiles WHERE user_id = ?', [userId]);

        const settingsData = {
            email_notifications: email_notifications ? 1 : 0,
            push_notifications: push_notifications ? 1 : 0,
            security_notifications: security_notifications ? 1 : 0,
            notification_frequency: notification_frequency || 'immediate',
            quiet_hours_start: quiet_hours_start || null,
            quiet_hours_end: quiet_hours_end || null
        };

        if (existingProfile) {
            await dbRun(`
                UPDATE user_profiles 
                SET email_notifications = ?, push_notifications = ?, security_notifications = ?,
                    notification_frequency = ?, quiet_hours_start = ?, quiet_hours_end = ?,
                    updated_at = datetime('now')
                WHERE user_id = ?
            `, [
                settingsData.email_notifications, settingsData.push_notifications, settingsData.security_notifications,
                settingsData.notification_frequency, settingsData.quiet_hours_start, settingsData.quiet_hours_end,
                userId
            ]);
        } else {
            await dbRun(`
                INSERT INTO user_profiles (
                    user_id, email_notifications, push_notifications, security_notifications,
                    notification_frequency, quiet_hours_start, quiet_hours_end, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
            `, [
                userId, settingsData.email_notifications, settingsData.push_notifications, settingsData.security_notifications,
                settingsData.notification_frequency, settingsData.quiet_hours_start, settingsData.quiet_hours_end
            ]);
        }

        // Update category preferences if provided
        if (categories && typeof categories === 'object') {
            for (const [category, enabled] of Object.entries(categories)) {
                await dbRun(`
                    INSERT OR REPLACE INTO notification_preferences (user_id, category, enabled, updated_at)
                    VALUES (?, ?, ?, datetime('now'))
                `, [userId, category, enabled ? 1 : 0]);
            }
        }

        // Create notification for settings update
        await createNotification(
            userId,
            'Notification Settings Updated',
            'Your notification preferences have been successfully updated.',
            'success',
            { category: 'account' }
        );

        res.json({ success: true, message: 'Notification settings updated successfully' });

    } catch (error) {
        console.error('Update notification settings error:', error);
        res.json({ success: false, error: 'Failed to update notification settings' });
    }
});

// Test notification (for testing purposes)
app.post('/notifications/test', requireAuth, async (req, res) => {
    try {
        const userId = req.session.user.id;
        const { type, title, message } = req.body;

        await createNotification(
            userId,
            title || 'Test Notification',
            message || 'This is a test notification to verify your notification system is working correctly.',
            type || 'info',
            { category: 'system', test: true }
        );

        res.json({ success: true, message: 'Test notification sent' });

    } catch (error) {
        console.error('Test notification error:', error);
        res.json({ success: false, error: 'Failed to send test notification' });
    }
});

// ================================================
// ADMIN ROUTES
// ================================================
app.get('/admin', requireAdmin, async (req, res) => {
    try {
        const users = await dbAll('SELECT * FROM users ORDER BY created_at DESC');
        const servers = await dbAll('SELECT * FROM servers ORDER BY created_at DESC');

        // Disk usage for the drive the panel data lives on
        let diskUsedPercent = null, diskFreeGb = null;
        try {
            const st = fs.statfsSync(__dirname);
            const total = st.blocks * st.bsize;
            const free = st.bavail * st.bsize;
            if (total > 0) {
                diskUsedPercent = Math.round(((total - free) / total) * 100);
                diskFreeGb = Math.round((free / 1024 / 1024 / 1024) * 10) / 10;
            }
        } catch (err) {
            console.warn('[admin] disk space check failed:', err.message);
        }
     
        res.render('admin/index', await getTemplateVars(req, null, {
            users,
            servers,
            currentPage: 'admin-dashboard',
            stats: {
                totalUsers: users.length,
                totalServers: servers.length,
                activeServers: servers.filter(s => s.status === 'running').length
            },
            systemInfo: {
                cpuCores: os.cpus().length,
                totalMemory: Math.round(os.totalmem() / 1024 / 1024 / 1024) + ' GB',
                freeMemory: Math.round(os.freemem() / 1024 / 1024 / 1024) + ' GB',
                platform: os.platform(),
                nodeVersion: process.version,
                panelVersion: NODE_PANEL_VERSION,
                uptime: process.uptime(),
                arch: os.arch(),
                osRelease: os.release(),
                diskUsedPercent,
                diskFreeGb
            },
            title: 'Admin Dashboard'
        }));
    } catch (err) {
        console.error('Admin dashboard error:', err);
        res.status(500).render('error', await getTemplateVars(req, null, { message: 'Failed to load admin panel', status: 500, title: 'Error' }));
    }
});
// User management
app.get('/admin/users', requireAdmin, async (req, res) => {
  try {
      const search = req.query.search || '';
      const role = req.query.role || '';
      const status = req.query.status || '';
      
      let query = 'SELECT * FROM users WHERE 1=1';
      const params = [];
      
      if (search) {
          query += ' AND (username LIKE ? OR email LIKE ?)';
          const term = `%${search}%`;
          params.push(term, term);
      }
      
      if (role) {
          query += ' AND role = ?';
          params.push(role);
      }
      
      if (status) {
          query += ' AND status = ?';
          params.push(status);
      }
      
      query += ' ORDER BY created_at DESC';
      const users = await dbAll(query, params);
      
      res.render('admin/users', await getTemplateVars(req, null, {
          users,
          search,
          role,
          status,
          currentPage: 'admin-users',
          title: 'User Management'
      }));
  } catch (err) {
      console.error('Admin users error:', err);
      res.status(500).render('error', await getTemplateVars(req, null, {
          message: 'Failed to load users',
          status: 500,
          title: 'Error'
      }));
  }
});

// User create page
app.get('/admin/users/create', requireAdmin, async (req, res) => {
  try {
      res.render('admin/user-create', await getTemplateVars(req, null, {
          currentPage: 'admin-user-create',
          title: 'Create User'
      }));
  } catch (err) {
      console.error('User create page error:', err);
      res.status(500).render('error', await getTemplateVars(req, null, {
          message: 'Failed to load create page',
          status: 500,
          title: 'Error'
      }));
  }
});

// User edit page
app.get('/admin/users/:id/edit', requireAdmin, async (req, res) => {
  try {
      const userId = req.params.id;
      console.log('=== USER EDIT ROUTE HIT ===');
      console.log('User edit page requested for user ID:', userId);
      console.log('Full URL:', req.url);
      console.log('Path:', req.path);
      console.log('Params:', req.params);
      
      const editUser = await dbGet('SELECT * FROM users WHERE id = ?', [userId]);
      
      if (!editUser) {
          console.log('User not found:', userId);
          return res.status(404).render('error', await getTemplateVars(req, null, {
              message: `User with ID ${userId} not found`,
              status: 404,
              title: 'User Not Found'
          }));
      }
      
      console.log('User found:', editUser.username);
      res.render('admin/user-edit', await getTemplateVars(req, null, {
          editUser,
          currentPage: 'admin-user-edit',
          title: `Edit User - ${editUser.username}`
      }));
  } catch (err) {
      console.error('User edit page error:', err);
      res.status(500).render('error', await getTemplateVars(req, null, {
          message: 'Failed to load edit page',
          status: 500,
          title: 'Error'
      }));
  }
});

app.post('/admin/users/create', requireAdmin, async (req, res) => {
    try {
        console.log('Create user request received:', {
            body: req.body,
            hasUsername: !!req.body.username,
            hasEmail: !!req.body.email,
            hasPassword: !!req.body.password,
            hasRole: !!req.body.role
        });
        
        const { username, email, password, role, status } = req.body;
     
        if (!username || !email || !password || !role) {
            console.log('Validation failed: Missing required fields');
            return res.status(400).json({ error: 'All fields are required' });
        }
        
        // Validate username format
        if (!/^[a-zA-Z0-9_-]+$/.test(username)) {
            console.log('Validation failed: Invalid username format');
            return res.status(400).json({ error: 'Username can only contain letters, numbers, underscores, and hyphens' });
        }
        
        // Validate username length
        if (username.length < 3 || username.length > 32) {
            console.log('Validation failed: Invalid username length');
            return res.status(400).json({ error: 'Username must be between 3 and 32 characters' });
        }
        
        // Validate password length
        if (password.length < 6) {
            console.log('Validation failed: Password too short');
            return res.status(400).json({ error: 'Password must be at least 6 characters' });
        }
     
        const existing = await dbGet(
            'SELECT * FROM users WHERE username = ? OR email = ?',
            [username, email]
        );
     
        if (existing) {
            console.log('Validation failed: Username or email already exists');
            return res.status(400).json({ error: 'Username or email already exists' });
        }
     
        console.log('Creating user:', username);
        const hashedPassword = await bcrypt.hash(password, 10);
        const result = await dbRun(
            'INSERT INTO users (username, email, password, role, status) VALUES (?, ?, ?, ?, ?)',
            [username, email, hashedPassword, role, status || 'active']
        );
     
        console.log('User created successfully:', username);
        
        // Return JSON success response
        res.status(201).json({ 
            success: true, 
            message: 'User created successfully',
            userId: result.lastID
        });
    } catch (err) {
        console.error('Create user error:', err);
        res.status(500).json({ error: 'Failed to create user: ' + err.message });
    }
});

app.post('/admin/users/:id/update', requireAdmin, async (req, res) => {
    try {
        console.log('Update user request received:', {
            userId: req.params.id,
            body: req.body,
            hasUsername: !!req.body.username,
            hasEmail: !!req.body.email,
            hasRole: !!req.body.role,
            hasStatus: !!req.body.status,
            hasPassword: !!req.body.password
        });
        
        const { username, email, role, status, password } = req.body;
        const userId = req.params.id;
     
        if (!username || !email || !role || !status) {
            console.log('Validation failed: Missing required fields');
            return res.status(400).json({ error: 'All fields are required' });
        }
        
        // Validate username format
        if (!/^[a-zA-Z0-9_-]+$/.test(username)) {
            console.log('Validation failed: Invalid username format');
            return res.status(400).json({ error: 'Username can only contain letters, numbers, underscores, and hyphens' });
        }
        
        // Validate username length
        if (username.length < 3 || username.length > 32) {
            console.log('Validation failed: Invalid username length');
            return res.status(400).json({ error: 'Username must be between 3 and 32 characters' });
        }
     
        const existing = await dbGet(
            'SELECT * FROM users WHERE (username = ? OR email = ?) AND id != ?',
            [username, email, userId]
        );
     
        if (existing) {
            console.log('Validation failed: Username or email already in use');
            return res.status(400).json({ error: 'Username or email already in use' });
        }
        
        // Update user with or without password
        if (password && password.length > 0) {
            // Validate password length
            if (password.length < 6) {
                console.log('Validation failed: Password too short');
                return res.status(400).json({ error: 'Password must be at least 6 characters' });
            }
            
            console.log('Updating user with new password:', username);
            const hashedPassword = await bcrypt.hash(password, 10);
            await dbRun(
                'UPDATE users SET username = ?, email = ?, role = ?, status = ?, password = ? WHERE id = ?',
                [username, email, role, status, hashedPassword, userId]
            );
        } else {
            console.log('Updating user without password change:', username);
            await dbRun(
                'UPDATE users SET username = ?, email = ?, role = ?, status = ? WHERE id = ?',
                [username, email, role, status, userId]
            );
        }
     
        console.log('User updated successfully:', username);
        
        // Return JSON success response
        res.status(200).json({ 
            success: true, 
            message: 'User updated successfully',
            userId: userId
        });
    } catch (err) {
        console.error('Update user error:', err);
        res.status(500).json({ error: 'Failed to update user: ' + err.message });
    }
});
app.post('/admin/users/:id/delete', requireAdmin, async (req, res) => {
    try {
        const userId = req.params.id;
        
        console.log('Delete user request received:', { userId });
     
        // Check if user has servers
        const userServers = await dbAll('SELECT * FROM servers WHERE owner_id = ?', [userId]);
        if (userServers.length > 0) {
            console.log('Validation failed: User has active servers');
            return res.status(400).json({
                error: 'Cannot delete user with active servers'
            });
        }
     
        console.log('Deleting user:', userId);
        await dbRun('DELETE FROM users WHERE id = ?', [userId]);
        console.log('User deleted successfully:', userId);
        
        // Return JSON success response
        res.status(200).json({ 
            success: true, 
            message: 'User deleted successfully',
            userId: userId
        });
    } catch (err) {
        console.error('Delete user error:', err);
        res.status(500).json({ error: 'Failed to delete user: ' + err.message });
    }
});
// Server management
app.get('/admin/servers', requireAdmin, async (req, res) => {
  try {
      const search = req.query.search ? req.query.search.trim() : '';
      const type = req.query.type ? req.query.type.trim() : '';
      const status = req.query.status ? req.query.status.trim() : '';
      
      let query = `
          SELECT s.*, u.username AS owner_name, n.name AS node_name, n.ip_address AS node_ip, n.daemon_port AS node_daemon_port
          FROM servers s
          LEFT JOIN users u ON s.owner_id = u.id
          LEFT JOIN nodes n ON s.node_id = n.id
      `;
      const params = [];
      const conditions = [];
      
      if (search) {
          conditions.push('(s.name LIKE ? OR u.username LIKE ?)');
          const term = `%${search}%`;
          params.push(term, term);
      }
      
      if (type) {
          conditions.push('s.server_type = ?');
          params.push(type);
      }
      
      if (status) {
          conditions.push('s.status = ?');
          params.push(status);
      }
      
      if (conditions.length > 0) {
          query += ' WHERE ' + conditions.join(' AND ');
      }
      
      query += ' ORDER BY s.created_at DESC';
      const servers = await dbAll(query, params);
      
      res.render('admin/servers', await getTemplateVars(req, null, {
          servers,
          search,
          type,
          status,
          currentPage: 'admin-servers',
          title: 'Server Management'
      }));
  } catch (err) {
      console.error('Admin servers error:', err);
      res.status(500).render('error', await getTemplateVars(req, null, {
          message: 'Failed to load servers',
          status: 500,
          title: 'Error'
      }));
  }
});
// New GET route for server create form
app.get('/admin/servers/create', requireAdmin, async (req, res) => {
    try {
        const users = await dbAll('SELECT id, username, email FROM users ORDER BY username ASC');
        const nodes = await dbAll('SELECT id, name, ip_address, daemon_port, status FROM nodes WHERE enabled = 1 ORDER BY name ASC');
        res.render('admin/server-create', await getTemplateVars(req, null, {
            users,
            nodes,
            currentPage: 'admin-server-create',
            title: 'Create Server'
        }));
    } catch (err) {
        console.error('Server create form error:', err);
        res.status(500).render('error', await getTemplateVars(req, null, {
            message: 'Failed to load create form',
            status: 500,
            title: 'Error'
        }));
    }
});

// GET route for server edit form
app.get('/admin/servers/:id/edit', requireAdmin, async (req, res) => {
    try {
        const serverId = req.params.id;
        const editServer = await dbGet(
            'SELECT s.*, u.username AS owner_name, n.name AS node_name, n.ip_address AS node_ip, n.daemon_port AS node_daemon_port FROM servers s LEFT JOIN users u ON s.owner_id = u.id LEFT JOIN nodes n ON s.node_id = n.id WHERE s.id = ?',
            [serverId]
        );
        
        if (!editServer) {
            return res.status(404).render('error', await getTemplateVars(req, null, {
                message: 'Server not found',
                status: 404,
                title: 'Error'
            }));
        }
        
        const users = await dbAll('SELECT id, username, email FROM users ORDER BY username ASC');
        
        res.render('admin/server-edit', await getTemplateVars(req, null, {
            editServer,
            users,
            currentPage: 'admin-server-edit',
            title: `Edit Server - ${editServer.name}`
        }));
    } catch (err) {
        console.error('Server edit page error:', err);
        res.status(500).render('error', await getTemplateVars(req, null, {
            message: 'Failed to load edit page',
            status: 500,
            title: 'Error'
        }));
    }
});


// POST route for server update
// API endpoint to fetch versions for a server type (public - no auth required)
app.get('/api/versions/:serverType', async (req, res) => {
    try {
        const serverType = req.params.serverType;
        const limit = req.query.limit ? parseInt(req.query.limit) : 50;
        
        const versions = await fetchMinecraftVersions(serverType, limit);
        res.json({ success: true, versions });
    } catch (err) {
        console.error('Fetch versions error:', err);
        res.status(500).json({ error: 'Failed to fetch versions' });
    }
});

// API endpoint to fetch builds for a specific server type and version
app.get('/api/versions/:serverType/:version/builds', async (req, res) => {
    try {
        const { serverType, version } = req.params;
        
        const builds = await fetchVersionBuilds(serverType, version);
        res.json({ success: true, version, builds });
    } catch (err) {
        console.error('Fetch builds error:', err);
        res.status(500).json({ error: 'Failed to fetch builds' });
    }
});

// API endpoint to get port information for a specific server
app.get('/api/servers/:id/port-info', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }
        
        const portInfo = getPortInformation(serverId, server.server_type, server.port);
        res.json({ success: true, portInfo });
        
    } catch (err) {
        console.error('Error getting port information:', err);
        res.status(500).json({ error: 'Failed to get port information' });
    }
});

// API endpoint to get available port ranges and server type information
app.get('/api/port-ranges', requireAuth, (req, res) => {
    try {
        const ranges = {
            'Java Edition': PORT_CONFIG.JAVA_EDITION,
            'Proxy Servers': PORT_CONFIG.PROXY_SERVERS
        };
        
        res.json({
            success: true,
            ranges: ranges,
            reservedPorts: PORT_CONFIG.RESERVED_PORTS,
            serverTypes: {
                java: ['vanilla', 'paper', 'purpur', 'spigot', 'bukkit', 'fabric', 'forge', 'quilt', 'mohist', 'catserver'],
                proxy: ['velocity', 'bungeecord', 'waterfall']
            },
            protectionLevels: {
                'Java Edition': 'Standard Protection - Automatic port management in range 25565-25665',
                'Proxy Servers': 'High Protection - Network isolation in dedicated range 25700-25799'
            }
        });
        
    } catch (err) {
        console.error('Error getting port ranges:', err);
        res.status(500).json({ error: 'Failed to get port ranges' });
    }
});
app.post('/admin/servers/create', requireAdmin, async (req, res) => {
    try {
        let { name, description, owner_id, node_id, ram, cpu, disk, port, version, server_type, server_ip = '', ip_alias = '', port_alias = '', startup_command = '', backup_limit = 10 } = req.body;
        
        // Trim and validate required fields
        if (!name || (name = name.trim()) === '') {
            return res.status(400).json({ error: 'Server name is required' });
        }
        description = (description || '').trim().slice(0, 500); // Max 500 chars
        if (!owner_id || isNaN(owner_id) || (owner_id = parseInt(owner_id)) <= 0) {
            return res.status(400).json({ error: 'Valid owner user ID is required' });
        }
        if (!node_id || isNaN(node_id) || (node_id = parseInt(node_id)) <= 0) {
            return res.status(400).json({ error: 'Valid node ID is required' });
        }
        if (!ram || isNaN(ram) || (ram = parseInt(ram)) < 512) {
            return res.status(400).json({ error: 'RAM must be at least 512 MB' });
        }
        
        // Validate CPU
        cpu = parseInt(cpu) || 2;
        if (isNaN(cpu) || cpu < 1) {
            return res.status(400).json({ error: 'CPU must be at least 1 core' });
        }
        
        // Validate Disk
        disk = parseInt(disk) || 10240;
        if (isNaN(disk) || disk < 1024) {
            return res.status(400).json({ error: 'Disk must be at least 1024 MB (1 GB)' });
        }
        
        version = version?.trim() || 'latest';
        server_type = server_type?.trim() || 'vanilla';
        ip_alias = ip_alias?.trim() || '';
        port_alias = port_alias?.trim() || '';
        
        // Check if owner exists
        const owner = await dbGet('SELECT * FROM users WHERE id = ?', [owner_id]);
        if (!owner) {
            return res.status(404).json({ error: 'Owner user not found' });
        }
        
        // Check if node exists
        const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [node_id]);
        if (!node) {
            return res.status(404).json({ error: 'Node not found' });
        }
        
        // Get available port from node
        let assignedPort = port;
        if (!assignedPort || assignedPort === '') {
            // Auto-assign first available port from node
            const availablePorts = await getNodeAvailablePorts(node_id);
            if (!availablePorts || availablePorts.length === 0) {
                return res.status(409).json({ error: 'No available ports on selected node' });
            }
            assignedPort = availablePorts[0];
        } else {
            // Validate provided port is available on this node
            assignedPort = parseInt(assignedPort);
            const availablePorts = await getNodeAvailablePorts(node_id);
            if (!availablePorts.includes(assignedPort)) {
                return res.status(409).json({ error: 'Selected port is not available on this node' });
            }
        }
        
        console.log(`Creating ${server_type} server on node ${node_id} with port ${assignedPort}`);
        
        // Insert into database with node_id
        const result = await dbRun(
            `INSERT INTO servers (name, description, owner_id, node_id, ram, cpu, disk, port, server_ip, ip_alias, port_alias, version, server_type, settings, startup_command, backup_limit)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                name,
                description,
                owner_id,
                node_id,
                ram,
                cpu,
                disk,
                assignedPort,
                server_ip,
                ip_alias,
                port_alias,
                version,
                server_type,
                JSON.stringify({ autoRestart: true, remote: true }),
                startup_command || `java -Xms${Math.max(64, Math.floor(ram / 2))}M -Xmx${ram}M -jar server.jar nogui`,
                parseInt(backup_limit) || 10
            ]
        );
        
        // Allocate port in node_port_allocations (UPDATE if exists, INSERT if not)
        await dbRun(
            `INSERT INTO node_port_allocations(node_id, port, server_id, protocol) 
             VALUES(?, ?, ?, ?) 
             ON CONFLICT(node_id, port) DO UPDATE SET server_id = ?, protocol = ?`,
            [node_id, assignedPort, result.lastID, 'tcp', result.lastID, 'tcp']
        );
        
        // Queue a 'create' command to the remote node daemon
        console.log(`📤 Queuing create command for remote node ${node_id}...`);
        try {
            await queueNodeAction(node_id, result.lastID, 'create', {
                name: name,
                serverType: server_type,
                version: version,
                ram: ram,
                cpu: cpu,
                disk: disk,
                port: assignedPort
            });
        } catch (err) {
            console.error(`Failed to queue create command for node ${node_id}:`, err.message);
            // Return error to user
            return res.status(500).json({ error: 'Failed to queue server creation on remote node: ' + err.message });
        }
        
        // Create notification for admin and owner
        await createNotification(req.session.user.id, 'Server Created', `New server "${name}" has been created`, 'success', {
            icon: 'plus-circle',
            type: 'server',
            server_id: result.lastID,
            action_url: `/admin/servers/${result.lastID}`,
            action_text: 'View Server'
        });
        
        if (owner_id !== req.session.user.id) {
            await createNotification(owner_id, 'Server Created', `New server "${name}" has been created for you`, 'success', {
                icon: 'plus-circle',
                type: 'server',
                server_id: result.lastID,
                action_url: `/servers/${result.lastID}/dashboard`,
                action_text: 'View Server'
            });
        }
        
        // Return JSON success response
        res.status(201).json({ 
            success: true, 
            message: 'Server created successfully',
            serverId: result.lastID
        });
    } catch (err) {
        console.error('Create server error:', err);
        res.status(500).json({ error: 'Failed to create server. Check server logs.' });
    }
});
app.post('/admin/servers/:id/update', requireAdmin, async (req, res) => {
    try {
        const serverId = req.params.id;
        let { name, description, ram, cpu, disk, server_ip = '', ip_alias = '', port_alias = '', port, owner_id, startup_command = '', backup_limit = 10 } = req.body;
        
        if (!name || (name = name.trim()) === '') {
            return res.status(400).json({ error: 'Server name is required' });
        }
        if (!ram || isNaN(ram) || (ram = parseInt(ram)) < 512) {
            return res.status(400).json({ error: 'RAM must be at least 512 MB' });
        }
        if (!port || isNaN(port) || (port = parseInt(port)) < 1024 || port > 65535) {
            return res.status(400).json({ error: 'Port must be between 1024 and 65535' });
        }
        if (server_ip && net.isIP(server_ip) === 0) {
            return res.status(400).json({ error: 'Invalid IP address' });
        }
        
        // Get current server info
        const currentServer = await dbGet('SELECT port, node_id, server_type FROM servers WHERE id = ?', [serverId]);
        if (!currentServer) {
            return res.status(404).json({ error: 'Server not found' });
        }
        
        // Check if new port is different and if it's already in use
        if (port !== currentServer.port) {
            const existingPort = await dbGet('SELECT id FROM servers WHERE port = ? AND id != ?', [port, serverId]);
            if (existingPort) {
                return res.status(400).json({ error: `Port ${port} is already in use by another server` });
            }
        }
        
        cpu = parseInt(cpu) || 1;
        disk = parseInt(disk) || 1024;
        description = (description || '').trim().slice(0, 500); // Max 500 chars
        ip_alias = ip_alias?.trim() || '';
        port_alias = port_alias?.trim() || '';
        
        // Update server including the port if changed
        await dbRun(
            'UPDATE servers SET name = ?, description = ?, ram = ?, cpu = ?, disk = ?, server_ip = ?, ip_alias = ?, port_alias = ?, port = ?, owner_id = ?, startup_command = ?, backup_limit = ? WHERE id = ?',
            [name, description, ram, cpu, disk, server_ip, ip_alias, port_alias, port, owner_id || currentServer.owner_id, startup_command || `java -Xms${Math.max(64, Math.floor(ram / 2))}M -Xmx${ram}M -jar server.jar nogui`, parseInt(backup_limit) || 10, serverId]
        );
        
        // Update server configuration with new port
        if (port !== currentServer.port) {
            try {
                await updateServerConfigurationPort(serverId, currentServer.server_type, port);
                console.log(`✅ Updated port for server ${serverId} from ${currentServer.port} to ${port}`);
                
                // Queue properties update to remote node with new port
                const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
                if (server && server.node_id) {
                    try {
                        await queueNodeAction(server.node_id, serverId, 'properties-save', {
                            properties: {
                                'server-port': port
                            },
                            action: 'update_port'
                        });
                        console.log(`📤 Queued port change to ${port} for remote node ${server.node_id}`);
                    } catch (queueErr) {
                        console.warn(`⚠️ Failed to queue port update to remote node: ${queueErr.message}`);
                    }
                }
            } catch (configErr) {
                console.error(`Warning: Could not update configuration files: ${configErr.message}`);
                // Continue anyway - database is updated
            }
        }
        
        // Create notification
        await createNotification(req.session.user.id, 'Server Updated', `Server "${name}" has been updated`, 'info', {
            icon: 'edit',
            type: 'server',
            server_id: serverId,
            action_url: `/admin/servers/${serverId}`,
            action_text: 'View Server'
        });
        
        res.json({ 
            success: true, 
            message: 'Server updated successfully!',
            port: port
        });
    } catch (err) {
        console.error('Update server error:', err);
        res.status(500).json({ error: 'Failed to update server' });
    }
});
app.post('/admin/servers/:id/delete', requireAdmin, async (req, res) => {
    try {
        const serverId = req.params.id;
        console.log('Deleting server:', serverId);
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }
        
        // Remote-only architecture: all servers must have node_id
        if (!server.node_id) {
            return res.status(400).json({ error: 'Server has no node assigned - cannot delete server without remote node' });
        }
        
        // Queue delete command to remote node
        try {
            await queueNodeAction(server.node_id, serverId, 'delete', {});
        } catch (err) {
            console.error(`Failed to queue delete command for node ${server.node_id}:`, err.message);
            return res.status(500).json({ error: 'Failed to queue server deletion on remote node: ' + err.message });
        }
        
        // Delete from database
        await dbRun('DELETE FROM servers WHERE id = ?', [serverId]);
        
        // Delete port allocations
        await dbRun('DELETE FROM node_port_allocations WHERE server_id = ?', [serverId]);
        
        // Create notifications
        await createNotification(req.session.user.id, 'Server Deleted', `Server "${server.name}" has been deleted`, 'danger', {
            icon: 'trash',
            type: 'server'
        });
        
        if (server.owner_id !== req.session.user.id) {
            await createNotification(server.owner_id, 'Server Deleted', `Server "${server.name}" has been deleted`, 'danger', {
                icon: 'trash',
                type: 'server'
            });
        }
        
        console.log('Server deleted successfully:', serverId);
        res.json({ success: true, message: 'Server deleted successfully' });
    } catch (err) {
        console.error('Delete server error:', err);
        res.status(500).json({ success: false, error: 'Failed to delete server: ' + err.message });
    }
});

// Reinstall server (change version/type with advanced options)
app.post('/admin/servers/:id/reinstall', requireAdmin, async (req, res) => {
    try {
        const serverId = req.params.id;
        const { server_type, version, cleanOptions = {} } = req.body;
        
        if (!server_type || !version) {
            return res.status(400).json({ error: 'Server type and version are required' });
        }
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }
        
        // Queue a 'reinstall' command to the remote node daemon
        console.log(`📤 Queuing reinstall command for remote node ${server.node_id}...`);
        try {
            await queueNodeAction(server.node_id, serverId, 'reinstall', {
                serverType: server_type,
                version: version,
                cleanOptions: cleanOptions
            });
            
            res.json({
                success: true,
                message: `✅ Server reinstall queued on remote node. Changes will be applied shortly.`,
                version: version
            });
        } catch (err) {
            console.error(`Failed to queue reinstall command for node ${server.node_id}:`, err.message);
            return res.status(500).json({ error: 'Failed to queue reinstall on remote node: ' + err.message });
        }
    } catch (err) {
        console.error('Reinstall server error:', err);
        res.status(500).json({ error: 'Failed to reinstall server: ' + err.message });
    }
});

// ================================================
// ADMIN NODE MANAGEMENT VIEW ROUTES
// ================================================

// List nodes
app.get('/admin/nodes', requireAdmin, async (req, res) => {
    try {
        res.render('admin/nodes/index', await getTemplateVars(req, null, {
            currentPage: 'admin-nodes',
            title: 'Node Management'
        }));
    } catch (err) {
        console.error('Nodes page error:', err);
        res.status(500).render('error', await getTemplateVars(req, null, {
            message: 'Failed to load nodes',
            status: 500,
            title: 'Error'
        }));
    }
});

// Create node form
app.get('/admin/nodes/create', requireAdmin, async (req, res) => {
    try {
        res.render('admin/nodes/create', await getTemplateVars(req, null, {
            currentPage: 'admin-nodes',
            title: 'Create Node'
        }));
    } catch (err) {
        console.error('Create node page error:', err);
        res.status(500).render('error', await getTemplateVars(req, null, {
            message: 'Failed to load create form',
            status: 500,
            title: 'Error'
        }));
    }
});

// View node
app.get('/admin/nodes/:id', requireAdmin, async (req, res) => {
    try {
        const nodeId = parseInt(req.params.id);
        if (isNaN(nodeId)) {
            return res.status(400).render('error', await getTemplateVars(req, null, {
                message: 'Invalid node ID',
                status: 400,
                title: 'Error'
            }));
        }
        res.render('admin/nodes/view', await getTemplateVars(req, null, {
            currentPage: 'admin-nodes',
            title: 'Node Details'
        }));
    } catch (err) {
        console.error('View node page error:', err);
        res.status(500).render('error', await getTemplateVars(req, null, {
            message: 'Failed to load node',
            status: 500,
            title: 'Error'
        }));
    }
});

// Edit node form
app.get('/admin/nodes/:id/edit', requireAdmin, async (req, res) => {
    try {
        const nodeId = parseInt(req.params.id);
        if (isNaN(nodeId)) {
            return res.status(400).render('error', await getTemplateVars(req, null, {
                message: 'Invalid node ID',
                status: 400,
                title: 'Error'
            }));
        }
        res.render('admin/nodes/edit', await getTemplateVars(req, null, {
            currentPage: 'admin-nodes',
            title: 'Edit Node'
        }));
    } catch (err) {
        console.error('Edit node page error:', err);
        res.status(500).render('error', await getTemplateVars(req, null, {
            message: 'Failed to load edit form',
            status: 500,
            title: 'Error'
        }));
    }
});

// ================================================
// ADMIN SETTINGS ROUTES
// ================================================
app.get('/admin/settings', requireAdmin, async (req, res) => {
    res.render('admin/settings', await getTemplateVars(req, null, {
        settings: globalSettings,
        currentPage: 'admin-settings',
        title: 'Panel Settings',
        DB_PATH,
        LOGS_DIR
    }));
});

// API endpoint to get current settings
app.get('/api/admin/settings', requireAdmin, async (req, res) => {
    try {
        res.json({ success: true, settings: globalSettings });
    } catch (err) {
        console.error('Get settings error:', err);
        res.status(500).json({ error: 'Failed to fetch settings' });
    }
});

app.post('/admin/settings/general', requireAdmin, async (req, res) => {
    try {
        const { panelName, panelDescription, footerText, registrationEnabled } = req.body;
     
        globalSettings.panelName = panelName || globalSettings.panelName;
        globalSettings.panelDescription = panelDescription || globalSettings.panelDescription;
        globalSettings.footerText = footerText || globalSettings.footerText;
        globalSettings.registrationEnabled = registrationEnabled === 'true' || registrationEnabled === true;
     
        saveGlobalSettings();
     
        res.json({ success: true, message: 'General settings updated', settings: globalSettings });
    } catch (err) {
        console.error('Update general settings error:', err);
        res.status(500).json({ error: 'Failed to update settings: ' + err.message });
    }
});
app.post('/admin/settings/icons', requireAdmin, upload.fields([
    { name: 'siteIcon', maxCount: 1 },
    { name: 'headerIcon', maxCount: 1 }
]), async (req, res) => {
    try {
        const publicDir = path.join(__dirname, 'public');
     
        if (req.files && req.files.siteIcon && req.files.siteIcon.length > 0) {
            const file = req.files.siteIcon[0];
            const ext = path.extname(file.originalname);
            const destPath = path.join(publicDir, 'site-icon' + ext);
         
            fs.renameSync(file.path, destPath);
            globalSettings.siteIcon = '/site-icon' + ext;
        }
     
        if (req.files && req.files.headerIcon && req.files.headerIcon.length > 0) {
            const file = req.files.headerIcon[0];
            const ext = path.extname(file.originalname);
            const destPath = path.join(publicDir, 'header-icon' + ext);
         
            fs.renameSync(file.path, destPath);
            globalSettings.headerIcon = '/header-icon' + ext;
        }
     
        saveGlobalSettings();
     
        res.json({ success: true, message: 'Icons updated successfully', settings: globalSettings });
    } catch (err) {
        console.error('Update icons error:', err);
        res.status(500).json({ error: 'Failed to update icons: ' + err.message });
    }
});
app.post('/admin/settings/theme', requireAdmin, async (req, res) => {
    try {
        const { theme, customCss } = req.body;
     
        globalSettings.theme = theme || 'default';
     
        if (customCss) {
            const cssPath = path.join(__dirname, 'public', 'custom-theme.css');
            fs.writeFileSync(cssPath, customCss, 'utf8');
        }
     
        saveGlobalSettings();
     
        res.json({ success: true, message: 'Theme updated successfully', settings: globalSettings });
    } catch (err) {
        console.error('Update theme error:', err);
        res.status(500).json({ error: 'Failed to update theme: ' + err.message });
    }
});

// Video Background Settings
app.post('/admin/settings/video-background', requireAdmin, async (req, res) => {
    try {
        const { videoBackgroundUrl } = req.body;
        
        // Validate URL format if provided
        if (videoBackgroundUrl && videoBackgroundUrl.trim() !== '') {
            const urlPattern = /^https?:\/\/.+\.(mp4|webm|ogg)$/i;
            if (!urlPattern.test(videoBackgroundUrl)) {
                return res.status(400).json({ 
                    error: 'Invalid video URL. Must be a direct link to .mp4, .webm, or .ogg file' 
                });
            }
        }
        
        // Update global settings
        globalSettings.videoBackgroundUrl = videoBackgroundUrl && videoBackgroundUrl.trim() !== '' 
            ? videoBackgroundUrl.trim() 
            : null;
        
        saveGlobalSettings();
        
        res.json({ 
            success: true, 
            message: videoBackgroundUrl ? 'Video background updated successfully' : 'Video background removed successfully'
        });
    } catch (err) {
        console.error('Update video background error:', err);
        res.status(500).json({ error: 'Failed to update video background' });
    }
});

// API endpoint to validate and fix all server ports (admin only)
app.post('/admin/validate-ports', requireAdmin, async (req, res) => {
    try {
        const result = await validateAndFixAllServerPorts();
        res.json({
            success: true,
            message: 'Port validation completed successfully',
            ...result
        });
    } catch (err) {
        console.error('Error validating ports:', err);
        res.status(500).json({ error: 'Failed to validate ports: ' + err.message });
    }
});

// ================================================
// SERVER MANAGEMENT ROUTES
// ================================================
// Server dashboard
app.get('/servers/:id/dashboard', requireAuth, async (req, res) => {
  try {
      const serverId = req.params.id;
      // Check authorization
      if (!await isAuthorized(req, serverId)) {
          return res.status(403).send('Access denied'); // simple fallback
      }
      // Fetch server with node info
      let server = await dbGet('SELECT s.*, n.name AS node_name, n.ip_address AS node_ip, n.ip_alias AS node_ip_alias FROM servers s LEFT JOIN nodes n ON s.node_id = n.id WHERE s.id = ?', [serverId]);
      if (!server) {
          return res.status(404).send('Server not found'); // simple fallback
      }
      
      // ✅ Correct server status if node is offline
      const { status: actualStatus } = await getServerStatus(serverId);
      server.status = actualStatus;
      
      // Get stats using the proper method (handles remote nodes)
      const stats = await getServerStats(serverId);
      
      // Format uptime for display
      let uptime = 'Offline';
      let uptimeSeconds = 0;
      let cpu = 'N/A';
      let memory = 'N/A';
      let onlineCount = 0;
      const running = server.status === 'running';
      
      if (running && stats && stats.uptime > 0) {
          uptimeSeconds = Math.floor(stats.uptime / 1000);
          const days = Math.floor(uptimeSeconds / 86400);
          const hrs = Math.floor((uptimeSeconds % 86400) / 3600);
          const mins = Math.floor((uptimeSeconds % 3600) / 60);
          const secs = uptimeSeconds % 60;
          
          if (days > 0) {
              uptime = `${days}d ${hrs}h ${mins}m`;
          } else if (hrs > 0) {
              uptime = `${hrs}h ${mins}m ${secs}s`;
          } else if (mins > 0) {
              uptime = `${mins}m ${secs}s`;
          } else {
              uptime = `${secs}s`;
          }
          
          // Set CPU and memory from stats
          cpu = (stats.cpu || 0).toFixed(1);
          memory = (stats.ram * 1024 || 0).toFixed(1); // Convert GB to MB
      } else {
          uptime = 'Offline';
      }
      
      onlineCount = onlinePlayers[serverId]?.length || 0;
      
      // Read max-players from server.properties - Remote-only architecture
      let maxPlayers = 20;
      
      // Remote-only: all servers must have node_id
      if (!server.node_id) {
          console.warn(`⚠️ Server ${serverId} has no node_id assigned - using default max-players of 20`);
      } else {
          // Fetch max-players from remote node stats (more reliable, already reads from server.properties)
          try {
              const statsRemote = await remoteNodeRequest(server.node_id, 'GET', `/servers/${serverId}/stats`, { timeoutMs: 5000 });
              if (statsRemote?.maxPlayers) {
                  maxPlayers = Number(statsRemote.maxPlayers) || 20;
                  console.log(`✅ Dashboard: Fetched maxPlayers=${maxPlayers} from stats endpoint`);
              }
          } catch (err) {
              console.warn(`Failed to fetch max-players from remote node ${server.node_id}:`, err.message);
          }
      }
      
      // Load existing latest.log history immediately; Socket.IO appends new lines live.
      let logContent = '';
      try {
          logContent = (await readServerLogLines(serverId, 10000)).join('\n');
      } catch (logErr) {
          console.warn(`Dashboard: could not load latest.log for server ${serverId}:`, logErr.message);
      }
      // Get total servers for footer
      const allServers = await dbAll('SELECT * FROM servers'); // or filter by owner if needed
      const totalServers = allServers.length;
      // Render dashboard
      res.render('servers/dashboard', await getTemplateVars(req, server, {
          uptime,
          cpu,
          memory,
          logContent,
          onlineCount,
          maxPlayers,
          totalServers,
          onlinePlayers: onlinePlayers[serverId] || [],
          currentPage: 'server-dashboard',
          activePage: 'dashboard',
          query: req.query,
          liveStats: liveStats[serverId] || {},
          title: `${server.name} - Dashboard`
      }));
  } catch (err) {
      console.error('Server dashboard error:', err);
      res.status(500).send('Failed to load dashboard'); // fallback to avoid missing error view
  }
});

// Server stats API endpoint
app.get('/servers/:id/stats', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        
        // Check authorization
        if (!await isAuthorized(req, serverId)) {
            return res.status(403).json({ success: false, error: 'Access denied' });
        }
        
        // Fetch server info
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ success: false, error: 'Server not found' });
        }
        
        // Get stats from getServerStats (which handles remote nodes properly with uptime tracking)
        const stats = await getServerStats(serverId);
        
        // Format response for dashboard
        const response = {
            cpu: Math.round(stats.cpu * 10) / 10 || 0,
            memory: (stats.ram * 1024) || 0, // Convert GB back to MB for display
            memoryPercent: ((stats.ram * 1024) / (server.ram || 8192)) * 100 || 0,
            disk: stats.disk || 0, // Already in percentage
            diskMB: 0, // Not used in current dashboard
            uptime: stats.uptime || 0, // Milliseconds from our tracking system
            players: stats.players || 0,
            maxPlayers: stats.maxPlayers || 20,
            status: server.status || 'stopped'
        };
        
        res.json({ success: true, stats: response });
        
    } catch (err) {
        console.error('Server stats error:', err);
        res.status(500).json({ success: false, error: 'Failed to fetch stats' });
    }
});

// Get initial logs for console page - use query param to avoid routing issues
app.post('/api/console/logs', requireAuth, async (req, res) => {
  try {
    const serverId = req.body.serverId;
    console.log(`📋 Loading initial logs for server ${serverId}`);
    
    if (!await isAuthorized(req, serverId)) {
      return res.status(403).json({ success: false, error: 'Access denied' });
    }
    
    // Remote-only architecture: fetch logs from remote node API
    const logs = await readServerLogLines(serverId, 10000);
    res.json({ success: true, logs });
  } catch (err) {
    console.error('Error getting logs:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Server console
app.get('/servers/:id/console', requireAuth, requirePermission('console'), async (req, res) => {
  try {
      const serverId = req.params.id;
      if (!await isAuthorized(req, serverId)) {
          return res.status(403).render('error', await getTemplateVars(req, null, {
              message: 'Access denied', status: 403, title: 'Error'
          }));
      }

      const server = await dbGet('SELECT s.*, n.name AS node_name, n.ip_address AS node_ip, n.ip_alias AS node_ip_alias FROM servers s LEFT JOIN nodes n ON s.node_id = n.id WHERE s.id = ?', [serverId]);
      let logContent = '';
      try {
          logContent = (await readServerLogLines(serverId, 300)).join('\n');
      } catch (logErr) {
          console.error(`Failed to load initial console log for server ${serverId}:`, logErr.message);
          logContent = '[Waiting for server logs...]\n';
      }

      const totalServersRow = await dbGet('SELECT COUNT(*) AS count FROM servers');
      const totalServers = totalServersRow ? totalServersRow.count : 0;

      return res.render('servers/console', await getTemplateVars(req, server, {
          logContent,
          activePage: 'console',
          currentPage: 'console',
          totalServers,
          liveStats: liveStats[serverId] || {},
          remoteNode: !!(server.node_id),
          title: `${server.name} - Console`
      }));
  } catch (err) {
      console.error('Console page error:', err);
      res.status(500).render('error', await getTemplateVars(req, null, {
          message: 'Failed to load console',
          status: 500,
          title: 'Error'
      }));
  }
});

app.get('/api/servers/:id/console-logs', requireAuth, requirePermission('console'), async (req, res) => {
  try {
      const serverId = req.params.id;
      if (!await isAuthorized(req, serverId)) {
          return res.status(403).json({ error: 'Access denied' });
      }

      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      if (!server) return res.status(404).json({ error: 'Server not found' });

      const requestedLines = Math.min(Math.max(parseInt(req.query.lines || 200, 10), 1), 5000);
      const rawLogs = await readServerLogLines(serverId, requestedLines);
      
      // Logs already have ANSI colors from daemon - pass through as-is
      res.json({
          serverId,
          logs: rawLogs,
          totalLines: rawLogs.length,
          source: server.node_id
              ? `remote-node:${server.node_id}/servers/${serverId}/logs/latest.log`
              : `local-node:/servers/${serverId}/logs/latest.log`
      });
  } catch (err) {
      console.error('Console logs API error:', err);
      res.status(500).json({ error: 'Failed to fetch console logs', details: err.message });
  }
});

// Alias for console page history loading (load full log by default)
app.get('/servers/:id/console-history', requireAuth, requirePermission('console'), async (req, res) => {
  try {
      const serverId = req.params.id;
      if (!await isAuthorized(req, serverId)) {
          return res.status(403).json({ error: 'Access denied' });
      }

      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      if (!server) return res.status(404).json({ error: 'Server not found' });

      // Return the actual current logs/latest.log snapshot without synthetic output or time-based filtering.
      const rawLogs = await readServerLogLines(serverId, Math.min(Math.max(Number.parseInt(req.query.lines, 10) || 10000, 1), 50000));
      
      // Logs already have ANSI colors from daemon - pass through as-is
      res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
      // Send as JSON with proper handling of binary escape sequences
      res.json({ 
        serverId: Number(serverId), 
        logs: rawLogs,
        totalLines: rawLogs.length, 
        source: 'logs/latest.log',
        // Include metadata about color encoding
        encoding: 'ANSI-UTF8'
      });
  } catch (err) {
      console.error('Console history API error:', err);
      res.status(500).json({ error: 'Failed to fetch console history', details: err.message });
  }
});

// ================================================
// LIVE SERVER STATUS CHECK (for console page)
// ================================================
app.get('/servers/:id/status', requireAuth, requirePermission('console'), async (req, res) => {
  try {
      const serverId = req.params.id;
      if (!await isAuthorized(req, serverId)) {
          return res.status(403).json({ error: 'Access denied' });
      }

      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      if (!server) return res.status(404).json({ error: 'Server not found' });

      // Get ACTUAL current status (checks node freshness for remote servers)
      const { status: actualStatus, online } = await getServerStatus(serverId);
      
      res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
      res.json({ 
          serverId: Number(serverId),
          status: actualStatus,
          online: online,
          timestamp: new Date().toISOString()
      });
  } catch (err) {
      console.error('Server status API error:', err);
      res.status(500).json({ error: 'Failed to fetch status', details: err.message });
  }
});

// Server control commands
app.post('/servers/:id/start', requireAuth, requirePermission('start'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) {
            return res.status(403).json({ error: 'Access denied' });
        }
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }
        if (await isServerRunning(serverId)) {
            return res.status(400).json({ error: 'Server already running' });
        }
        
        // Reset uptime tracker when starting server
        if (!global.localUptimeTracker) global.localUptimeTracker = {};
        global.localUptimeTracker[serverId] = {
            startTime: null,
            lastRemoteUptime: 0,
            lastStatus: 'offline',
            receivedTime: Date.now()
        };
        console.log(`🔄 Reset uptime tracker for server ${serverId} before start`);
        
        await startServer(serverId);
        
        // Create notification
        await createNotification(req.session.user.id, 'Server Started', `Server "${server.name}" has been started`, 'success', {
            icon: 'play-circle',
            type: 'server',
            server_id: serverId,
            action_url: `/servers/${serverId}/dashboard`,
            action_text: 'View Server'
        });
        
        res.json({ success: true, message: 'Server started' });
    } catch (err) {
        console.error('Start server error:', err);
        res.status(err.status || 500).json({ error: err.message || 'Failed to start server' });
    }
});
app.post('/servers/:id/stop', requireAuth, requirePermission('stop'), async (req, res) => {
    try {
        const serverId = req.params.id;
     
        if (!await isAuthorized(req, serverId)) {
            return res.status(403).json({ error: 'Access denied' });
        }
        
        // Reset uptime tracker when stopping server
        if (!global.localUptimeTracker) global.localUptimeTracker = {};
        global.localUptimeTracker[serverId] = {
            startTime: null,
            lastRemoteUptime: 0,
            lastStatus: 'offline',
            receivedTime: Date.now()
        };
        console.log(`🔄 Reset uptime tracker for server ${serverId} (stopped)`);
     
        await stopServer(serverId, false);
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        
        // Create notification
        await createNotification(req.session.user.id, 'Server Stopped', `Server "${server?.name || 'Unknown'}" has been stopped`, 'warning', {
            icon: 'stop-circle',
            type: 'server',
            server_id: serverId,
            action_url: `/servers/${serverId}/dashboard`,
            action_text: 'View Server'
        });
     
        res.json({ success: true, message: 'Server stopped' });
    } catch (err) {
        console.error('Stop server error:', err);
        res.status(err.status || 500).json({ error: err.message || 'Failed to stop server' });
    }
});
app.post('/servers/:id/kill', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
     
        if (!await isAuthorized(req, serverId)) {
            return res.status(403).json({ error: 'Access denied' });
        }
     
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }
     
        const success = await stopServer(serverId, true);
        if (success) {
            res.json({ success: true, message: 'Server killed' });
        } else {
            res.status(500).json({ error: 'Failed to kill server' });
        }
    } catch (err) {
        console.error('Kill server error:', err);
        res.status(500).json({ error: 'Failed to kill server' });
    }
});
app.post('/servers/:id/restart', requireAuth, requirePermission('restart'), async (req, res) => {
    try {
        const serverId = req.params.id;
     
        if (!await isAuthorized(req, serverId)) {
            return res.status(403).json({ error: 'Access denied' });
        }
     
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }
     
        if (server.node_id) {
            if (server.status !== 'running') return res.status(400).json({ error: 'Server not running' });
        }
     
        // Stop the server first
        const stopped = await stopServer(serverId);
        if (!stopped) {
            return res.status(500).json({ error: 'Failed to stop server' });
        }
        
        // Wait a bit before starting
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Start the server again
        const started = await startServer(serverId);
        if (started) {
            res.json({ success: true, message: 'Server restarted successfully' });
        } else {
            res.status(500).json({ error: 'Failed to start server after stopping' });
        }
    } catch (err) {
        console.error('Restart server error:', err);
        res.status(500).json({ error: 'Failed to restart server' });
    }
});
app.post('/servers/:id/command', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        const { command } = req.body;
     
        if (!await isAuthorized(req, serverId)) {
            return res.status(403).json({ error: 'Access denied' });
        }
     
        if (!command) {
            return res.status(400).json({ error: 'Command required' });
        }
     
        if (!await isServerRunning(serverId)) {
            return res.status(400).json({ error: 'Server not running' });
        }
        
        // Use sendCommand which has RCON fallback for reconnected servers
        const result = await sendCommand(serverId, command);
        
        // If command failed and we don't have stdin, try to auto-enable RCON
        if (!result.success) {
            const serverProcess = global.serverProcesses && global.serverProcesses[serverId];
            const hasStdin = serverProcess && !serverProcess.killed && serverProcess.stdin && serverProcess.stdin.writable;
            
            if (!hasStdin) {
                console.log(`Attempting to auto-enable RCON for server ${serverId}...`);
                const rconEnabled = await autoEnableRcon(serverId);
                
                if (rconEnabled) {
                    return res.status(400).json({ 
                        error: 'RCON has been automatically enabled. Please restart the server for changes to take effect.',
                        autoFixed: true,
                        action: 'restart'
                    });
                } else {
                    return res.status(400).json({ 
                        error: 'Could not enable RCON automatically. Please enable RCON manually in server.properties.',
                        hint: 'Add: enable-rcon=true, rcon.port=25575, rcon.password=admin123'
                    });
                }
            } else {
                return res.status(500).json({ error: 'Failed to send command. Please try again.' });
            }
        }
        
        res.json({ success: true, message: 'Command sent successfully', response: result.response });
    } catch (err) {
        console.error('Send command error:', err);
        res.status(500).json({ error: 'Failed to send command' });
    }
});

// ================================================
// PLAYER MANAGEMENT ROUTES  
// ================================================
app.post('/servers/:id/players/action', requireAuth, requirePermission('players'), async (req, res) => {
    try {
        const serverId = req.params.id;
        const { action, player, reason, hours } = req.body;
        
        if (!await isAuthorized(req, serverId)) {
            return res.status(403).json({ success: false, error: 'Access denied' });
        }
        
        if (!action || !player) {
            return res.status(400).json({ success: false, error: 'Action and player name required' });
        }
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ success: false, error: 'Server not found' });
        
        // Send command via RCON or stdin
        let command = '';
        
        switch(action) {
            case 'op':
                command = `op ${player}`;
                break;
            case 'deop':
                command = `deop ${player}`;
                break;
            case 'kick':
                command = reason ? `kick ${player} ${reason}` : `kick ${player}`;
                break;
            case 'ban':
                command = reason ? `ban ${player} ${reason}` : `ban ${player}`;
                break;
            case 'unban':
                command = `pardon ${player}`;
                break;
            default:
                return res.status(400).json({ success: false, error: 'Unknown action' });
        }
        
        if (!await isServerRunning(serverId)) {
            return res.status(400).json({ success: false, error: 'Server is not running' });
        }
        
        const result = await sendCommand(serverId, command);
        
        if (result.success) {
            res.json({ success: true, message: `Action '${action}' executed for player '${player}'` });
        } else {
            res.status(500).json({ success: false, error: 'Failed to execute command on server' });
        }
    } catch (err) {
        console.error('Player action error:', err);
        res.status(500).json({ success: false, error: err.message || 'Failed to perform player action' });
    }
});

// ================================================
// FILE MANAGER ROUTES
// ================================================
app.get('/servers/:id/files', requireAuth, requirePermission('files'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).send('Access denied');
        const currentPath = req.query.path || '/';
        const server = await dbGet('SELECT s.*, n.name AS node_name, n.ip_address AS node_ip, n.ip_alias AS node_ip_alias FROM servers s LEFT JOIN nodes n ON s.node_id = n.id WHERE s.id = ?', [serverId]);
        if (!server) return res.status(404).send('Server not found');
        
        let files = [];
        
        try {
            try {
                const remote = await remoteNodeRequest(
                    server.node_id,
                    'GET',
                    `/servers/${serverId}/files?path=${encodeURIComponent(currentPath)}`,
                    { timeoutMs: 15000 }
                );
                files = normalizeRemoteFiles(remote, currentPath);
            } catch (directErr) {
                console.warn(`Direct remote file-list failed for server ${serverId}; using command queue:`, directErr.message);
                const command = await remoteCommand(
                    server.node_id,
                    serverId,
                    'file-list',
                    { path: currentPath },
                    30000
                );
                files = normalizeRemoteFiles(command.result, currentPath);
            }
        } catch (remoteErr) {
            console.error(`Remote file list failed for node ${server.node_id}:`, remoteErr.message);
            return res.status(502).render('error', await getTemplateVars(req, server, {
                message: 'Remote node file manager is unavailable',
                error: remoteErr.message,
                status: 502,
                title: 'Remote Node Error'
            }));
        }
        
        res.render('servers/filemanager', await getTemplateVars(req, server, {
            files, currentPath, path, serverId: server.id, currentPage: 'files', activePage: 'files',
            remoteNode: true,
            title: `${server.name} - File Manager`
        }));
    } catch (err) {
        console.error('files list error', err);
        res.status(500).send('Error listing files');
    }
});
app.get('/servers/:id/files/view', requireAuth, requirePermission('files'), async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).send('Access denied');
        const filePath = req.query.path;
        
        if (!filePath) {
            const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
            return res.status(400).render('error', await getTemplateVars(req, server, {
                message: 'File path is required',
                error: 'Please specify a file to view',
                status: 400,
                title: 'Error'
            }));
        }

        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).send('Server not found');
        
        try {
            const command = await remoteCommand(server.node_id, serverId, 'file-read', { path: filePath }, 20000);
            const content = extractRemoteFileContent(command.result);
            if (content === '' && !command.result?.content && !command.result?.text) throw new Error('Remote agent returned no file content');
            return res.render('servers/fileview', await getTemplateVars(req, server, { content, filePath, path: require('path'), serverId: server.id, activePage: 'files', remoteNode: true, title: `${server.name} - ${path.basename(filePath)}` }));
        } catch (remoteErr) {
            return res.status(502).render('error', await getTemplateVars(req, server, { message: 'Remote file could not be read', error: remoteErr.message, status: 502, title: 'Error' }));
        }
    } catch (err) {
        console.error('file view error', err);
        res.status(500).send('Error viewing file: ' + err.message);
    }
});
app.get('/servers/:id/files/download', requireAuth, requirePermission('files_download'), async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).send('Access denied');
        const { path: filePath } = req.query;
        if (!filePath) return res.status(400).send('File path is required');
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).send('Server not found');
        
        try {
            const command = await remoteCommand(server.node_id, serverId, 'file-download', { path: filePath }, 60000);
            const buffer = extractRemoteDownload(command.result);
            if (!buffer) return res.status(502).send('Remote agent did not return downloadable file data');
            res.setHeader('Content-Disposition', `attachment; filename="${path.basename(filePath).replace(/"/g, '')}"`);
            res.setHeader('Content-Type', 'application/octet-stream');
            return res.send(buffer);
        } catch (remoteErr) {
            return res.status(502).send(`Remote download failed: ${remoteErr.message}`);
        }
    } catch (err) {
        console.error('download error', err);
        res.status(500).send('Error downloading file');
    }
});
app.post('/servers/:id/files/rename', requireAuth, requirePermission('files'), async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { oldPath, newName } = req.body;
        if (!oldPath || !newName) return res.status(400).json({ error: 'Old path and new name are required' });
        const sanitizedNewName = sanitize(newName);
        if (!sanitizedNewName) return res.status(400).json({ error: 'Invalid new name' });
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        
        try {
            await remoteCommand(server.node_id, serverId, 'file-rename', { oldPath, newName: sanitizedNewName }, 30000);
            return res.json({ success: true, message: 'File renamed on remote node' });
        } catch (remoteErr) { return res.status(502).json({ error: remoteErr.message }); }
    } catch (err) {
        console.error('rename error', err);
        res.status(500).json({ error: 'Failed to rename' });
    }
});
app.post('/servers/:id/files/delete', requireAuth, requirePermission('files_delete'), async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        
        const { path: targetPath } = req.body;
        if (!targetPath) return res.status(400).json({ error: 'Path is required' });
        
        const opId = typeof req.body?.opId === 'string' ? req.body.opId.slice(0, 64) : null;
        try {
            const commandId = await queueNodeAction(server.node_id, serverId, 'file-delete', {
                path: targetPath
            });
            if (opId) commandOpMap.set(commandId, { opId });
            try {
                const cmd = await waitForNodeCommand(server.node_id, commandId, 120000);
                return res.json({ success: true, remote: true, result: cmd.result });
            } finally {
                if (opId) commandOpMap.delete(commandId);
            }
        } catch (remoteErr) {
            return res.status(502).json({ error: remoteErr.message });
        }
        
    } catch (err) {
        console.error('delete error', err);
        return res.status(500).json({ 
            error: err.code === 'EBUSY' || err.code === 'EPERM' 
                ? 'File is locked. Stop the server and try again.' 
                : 'Failed to delete' 
        });
    }
});

app.post('/servers/:id/files/delete-bulk', requireAuth, requirePermission('files_delete'), async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { paths } = req.body;
        if (!paths || !Array.isArray(paths) || paths.length === 0) {
            return res.status(400).json({ error: 'Paths array is required' });
        }
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        
        const opId = typeof req.body?.opId === 'string' ? req.body.opId.slice(0, 64) : null;
        try {
            const results = [];
            for (let i = 0; i < paths.length; i++) {
                const commandId = await queueNodeAction(server.node_id, serverId, 'file-delete', { path: paths[i] });
                if (opId) commandOpMap.set(commandId, { opId, bulk: true, index: i, total: paths.length, path: paths[i] });
                try {
                    const cmd = await waitForNodeCommand(server.node_id, commandId, 120000);
                    results.push({ path: paths[i], result: cmd.result });
                } finally {
                    if (opId) commandOpMap.delete(commandId);
                }
            }
            return res.json({ success: true, deletedCount: results.length, remote: true, results });
        } catch (remoteErr) { return res.status(502).json({ error: remoteErr.message }); }
        
    } catch (err) {
        console.error('delete-bulk error', err);
        return res.status(500).json({ error: 'Failed to delete files' });
    }
});

app.post('/servers/:id/files/zip', requireAuth, requirePermission('files'), async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { path: targetPath } = req.body;
        if (!targetPath) return res.status(400).json({ error: 'Path is required' });
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        
        try {
            const cmd = await remoteCommand(server.node_id, serverId, 'file-zip', { path: targetPath }, 120000);
            return res.json({ success: true, remote: true, result: cmd.result });
        } catch (remoteErr) { return res.status(502).json({ error: remoteErr.message }); }
    } catch (err) {
        console.error('zip error', err);
        res.status(500).json({ error: 'Failed to create zip' });
    }
});
app.post('/servers/:id/files/unzip', requireAuth, requirePermission('files'), async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { path: targetPath } = req.body;
        if (!targetPath) return res.status(400).json({ error: 'Path is required' });
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        
        try {
            const cmd = await remoteCommand(server.node_id, serverId, 'file-unzip', { path: targetPath }, 120000);
            return res.json({ success: true, remote: true, result: cmd.result });
        } catch (remoteErr) { return res.status(502).json({ error: remoteErr.message }); }
    } catch (err) {
        console.error('unzip error', err);
        res.status(500).json({ error: 'Failed to unzip' });
    }
});
app.post('/servers/:id/files/upload', requireAuth, upload.single('file'), requirePermission('files_upload'), async (req, res) => {
    try {
        const { id: serverId } = req.params;
        console.log(`📤 Upload request - Server: ${serverId}, File: ${req.file?.originalname}`);
        
        if (!await isAuthorized(req, serverId)) {
            console.log(`❌ Upload unauthorized - Server: ${serverId}`);
            return res.status(403).json({ error: 'Access denied' });
        }
        
        if (!req.file) {
            console.log(`❌ Upload no file - Server: ${serverId}`);
            return res.status(400).json({ error: 'No file uploaded' });
        }
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
            return res.status(404).json({ error: 'Server not found' });
        }
        

        if (server.node_id) {
            const node = await getNodeRecord(server.node_id);
            if (!nodeIsFresh(node) || node.status !== 'online') {
                throw new Error(`Node "${node.name}" is offline or heartbeat is stale`);
            }
            console.log(`📤 Streaming file upload to node ${node.name} (${node.ip_address}:${node.daemon_port}) for server ${serverId}`);

            const targetDir = req.body.path || '/';
            const filename = sanitize(req.file.originalname);
            const fileSize = req.file.size;

            await new Promise((resolve, reject) => {
                const stream = fs.createReadStream(req.file.path);
                axios.post(`http://${node.ip_address}:${node.daemon_port}/servers/${serverId}/files/upload`, stream, {
                    headers: {
                        'x-daemon-token': node.token,
                        'x-target-dir': targetDir,
                        'x-filename': filename,
                        'Content-Type': 'application/octet-stream',
                        'Content-Length': fileSize
                    },
                    timeout: 0,
                    maxContentLength: Infinity,
                    maxBodyLength: Infinity
                }).then(r => {
                    if (r.data && r.data.ok) resolve();
                    else reject(new Error((r.data && r.data.error) || 'Node rejected upload'));
                }).catch(err => {
                    reject(new Error((err.response && err.response.data && err.response.data.error) || err.message));
                });
            });

            return res.json({
                success: true,
                message: 'File uploaded to node!'
            });
        }
    } catch (err) {
        console.error('❌ upload error:', err);
        res.status(500).json({ error: 'Failed to upload: ' + err.message });
    } finally {
        if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
    }
});

// ================================================
// PULL FILE FROM URL ENDPOINT
// ================================================
app.post('/servers/:id/files/pull', requireAuth, requirePermission('files'), async (req, res) => {
    try {
        const { id: serverId } = req.params;
        const { url, path: targetDir, filename } = req.body;
        
        if (!await isAuthorized(req, serverId)) {
            return res.status(403).json({ error: 'Access denied' });
        }
        
        if (!url) {
            return res.status(400).json({ error: 'URL is required' });
        }
        
        // Validate URL
        try {
            new URL(url);
        } catch (e) {
            return res.status(400).json({ error: 'Invalid URL format' });
        }
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }
        
        try {
            const opId = typeof req.body?.opId === 'string' ? req.body.opId.slice(0, 64) : null;
            const commandId = await queueNodeAction(server.node_id, serverId, 'file-pull', { 
                url, 
                path: targetDir || '/',
                filename: filename || ''
            });
            if (opId) commandOpMap.set(commandId, { opId });
            try {
                const cmd = await waitForNodeCommand(server.node_id, commandId, 300000); // 5 minute timeout for large downloads
                return res.json({ success: true, remote: true, result: cmd.result });
            } finally {
                if (opId) commandOpMap.delete(commandId);
            }
        } catch (remoteErr) {
            return res.status(502).json({ error: remoteErr.message });
        }
    } catch (err) {
        console.error('Pull file error:', err);
        res.status(500).json({ error: 'Failed to pull file: ' + err.message });
    }
});

app.post('/servers/:id/files/create', requireAuth, requirePermission('files'), async (req, res) => {
    try {
        const { id: serverId } = req.params;
        const { path: targetPath, filename } = req.body;
        console.log(`📝 Create file request - Server: ${serverId}, File: ${filename}, Path: ${targetPath}`);
        
        if (!await isAuthorized(req, serverId)) {
            console.log(`❌ Create file unauthorized - Server: ${serverId}`);
            return res.status(403).json({ error: 'Access denied' });
        }
        
        if (!filename) {
            console.log(`❌ Create file no filename - Server: ${serverId}`);
            return res.status(400).json({ error: 'Filename is required' });
        }
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        
        const sanitizedFilename = sanitize(filename);
        if (!sanitizedFilename) {
            console.log(`❌ Create file invalid filename - Server: ${serverId}, Input: ${filename}`);
            return res.status(400).json({ error: 'Invalid filename' });
        }
        

        if (server.node_id) {
            console.log(`📤 Queuing file create command for remote node ${server.node_id}, server ${serverId}`);
            await queueNodeAction(server.node_id, serverId, 'file-create', {
                path: targetPath || '/',
                filename: sanitizedFilename
            });
            return res.json({ 
                success: true,
                message: 'File creation queued on remote node!',
                queued: true
            });
        }
    } catch (err) {
        console.error('❌ create file error:', err);
        res.status(500).json({ error: 'Failed to create file: ' + err.message });
    }
});

app.post('/servers/:id/files/create-folder', requireAuth, requirePermission('files'), async (req, res) => {
    try {
        const { id: serverId } = req.params;
        const { path: targetPath, foldername } = req.body;
        console.log(`📁 Create folder request - Server: ${serverId}, Folder: ${foldername}, Path: ${targetPath}`);
        
        if (!await isAuthorized(req, serverId)) {
            console.log(`❌ Create folder unauthorized - Server: ${serverId}`);
            return res.status(403).json({ error: 'Access denied' });
        }
        
        if (!foldername) {
            console.log(`❌ Create folder no name - Server: ${serverId}`);
            return res.status(400).json({ error: 'Folder name is required' });
        }
        
        const sanitizedFoldername = sanitize(foldername);
        if (!sanitizedFoldername) {
            console.log(`❌ Create folder invalid name - Server: ${serverId}, Input: ${foldername}`);
            return res.status(400).json({ error: 'Invalid folder name' });
        }
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        
        try {
            await remoteCommand(server.node_id, serverId, 'file-create', { path: targetPath || '/', filename: sanitizedFoldername, directory: true }, 30000);
            return res.json({ success: true, message: 'Folder created on remote node' });
        } catch (remoteErr) { return res.status(502).json({ error: remoteErr.message }); }
    } catch (err) {
        console.error('❌ create folder error:', err);
        res.status(500).json({ error: 'Failed to create folder: ' + err.message });
    }
});

app.post('/servers/:id/files/bulk-zip', requireAuth, requirePermission('files'), async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { paths, zipName, currentDir } = req.body;
        if (!paths || !Array.isArray(paths) || paths.length === 0) {
            return res.status(400).json({ error: 'Paths array is required' });
        }
        if (!zipName) return res.status(400).json({ error: 'Zip name is required' });
        
        const sanitizedZipName = sanitize(zipName);
        if (!sanitizedZipName) return res.status(400).json({ error: 'Invalid zip name' });
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        
        try {
            const cmd = await remoteCommand(server.node_id, serverId, 'file-bulk-zip', { paths, zipName: sanitizedZipName, currentDir: currentDir || '/' }, 120000);
            return res.json({ success: true, remote: true, result: cmd.result });
        } catch (remoteErr) { return res.status(502).json({ error: remoteErr.message }); }
    } catch (err) {
        console.error('bulk zip error', err);
        res.status(500).json({ error: 'Failed to create bulk zip' });
    }
});

// ================================================
// EXTRACT ARCHIVE ENDPOINT
// ================================================
app.post('/servers/:id/files/extract', requireAuth, requirePermission('files'), async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const { archivePath } = req.body;
        if (!archivePath) return res.status(400).json({ error: 'Archive path is required' });
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        
        const opId = typeof req.body?.opId === 'string' ? req.body.opId.slice(0, 64) : null;
        try {
            const commandId = await queueNodeAction(server.node_id, serverId, 'file-extract', { archivePath });
            if (opId) commandOpMap.set(commandId, { opId });
            try {
                const cmd = await waitForNodeCommand(server.node_id, commandId, 120000);
                return res.json({ success: true, remote: true, result: cmd.result });
            } finally {
                if (opId) commandOpMap.delete(commandId);
            }
        } catch (remoteErr) { return res.status(502).json({ error: remoteErr.message }); }
    } catch (err) {
        console.error('Extract archive error:', err);
        res.status(500).json({ error: 'Failed to extract archive' });
    }
});

// Alias for /files/edit - used by file viewer - Remote-only
app.post('/servers/:id/files/save', requireAuth, requirePermission('files'), async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { path: filePath, content } = req.body;
        if (!filePath || content === undefined) return res.status(400).json({ error: 'File path and content are required' });
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        
        // Remote-only architecture: all servers must have node_id
        if (!server.node_id) {
            return res.status(400).json({ error: 'Server has no node assigned - remote-only architecture requires all servers to be on a remote node' });
        }
        
        try {
            await remoteCommand(server.node_id, serverId, 'file-write', { path: filePath, content: String(content) }, 30000);
            return res.json({ success: true, message: 'File saved on remote node' });
        } catch (remoteErr) { return res.status(502).json({ error: remoteErr.message }); }
    } catch (err) {
        console.error('File save error:', err);
        res.status(500).json({ error: err.message });
    }
});
app.post('/servers/:id/files/mkdir', requireAuth, requirePermission('files'), async (req, res) => {
    try {
        const { id: serverId } = req.params;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { path: parentPath, name } = req.body;
        if (!name) return res.status(400).json({ error: 'Name is required' });
        const sanitizedName = sanitize(name);
        if (!sanitizedName) return res.status(400).json({ error: 'Invalid folder name' });
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        
        // Remote-only architecture: all servers must have node_id
        if (!server.node_id) {
            return res.status(400).json({ error: 'Server has no node assigned - remote-only architecture requires all servers to be on a remote node' });
        }
        
        try {
            await remoteCommand(server.node_id, serverId, 'file-create', { path: parentPath || '/', filename: sanitizedName, directory: true }, 30000);
            return res.json({ success: true, message: 'Folder created on remote node' });
        } catch (remoteErr) { return res.status(502).json({ error: remoteErr.message }); }
    } catch (err) {
        console.error('create folder error', err);
        res.status(500).json({ error: 'Failed to create folder' });
    }
});

// Permission definitions (shared with frontend)
const SUBUSER_PERMISSIONS = {
    console: { label: 'Console Access', desc: 'View and use server console', icon: 'fas fa-terminal', category: 'core' },
    start: { label: 'Start Server', desc: 'Start the server', icon: 'fas fa-play', category: 'core' },
    stop: { label: 'Stop Server', desc: 'Stop the server', icon: 'fas fa-stop', category: 'core' },
    restart: { label: 'Restart Server', desc: 'Restart the server', icon: 'fas fa-redo', category: 'core' },
    files: { label: 'File Manager', desc: 'View, edit, upload, delete files', icon: 'fas fa-folder-open', category: 'files' },
    files_upload: { label: 'Upload Files', desc: 'Upload files to server', icon: 'fas fa-upload', category: 'files' },
    files_delete: { label: 'Delete Files', desc: 'Delete files from server', icon: 'fas fa-trash', category: 'files' },
    plugins: { label: 'Plugin Manager', desc: 'View and manage plugins', icon: 'fas fa-plug', category: 'plugins' },
    plugins_install: { label: 'Install Plugins', desc: 'Install new plugins', icon: 'fas fa-plus', category: 'plugins' },
    plugins_delete: { label: 'Delete Plugins', desc: 'Delete plugins', icon: 'fas fa-trash', category: 'plugins' },
    worlds: { label: 'World Manager', desc: 'View and manage worlds', icon: 'fas fa-globe', category: 'worlds' },
    worlds_upload: { label: 'Upload Worlds', desc: 'Upload world files', icon: 'fas fa-upload', category: 'worlds' },
    worlds_delete: { label: 'Delete Worlds', desc: 'Delete worlds', icon: 'fas fa-trash', category: 'worlds' },
    backups: { label: 'Backup Manager', desc: 'View and manage backups', icon: 'fas fa-archive', category: 'backups' },
    backups_create: { label: 'Create Backups', desc: 'Create new backups', icon: 'fas fa-plus', category: 'backups' },
    backups_delete: { label: 'Delete Backups', desc: 'Delete backups', icon: 'fas fa-trash', category: 'backups' },
    backups_download: { label: 'Download Backups', desc: 'Download backup files', icon: 'fas fa-download', category: 'backups' },
    players: { label: 'Player Manager', desc: 'View and manage players', icon: 'fas fa-users', category: 'players' },
    players_kick: { label: 'Kick Players', desc: 'Kick players from server', icon: 'fas fa-user-minus', category: 'players' },
    players_ban: { label: 'Ban Players', desc: 'Ban players from server', icon: 'fas fa-ban', category: 'players' },
    settings: { label: 'Server Settings', desc: 'View and edit server settings', icon: 'fas fa-cog', category: 'settings' },
    startup: { label: 'Startup Config', desc: 'Edit startup parameters', icon: 'fas fa-rocket', category: 'settings' },
    schedules: { label: 'Schedule Manager', desc: 'Manage scheduled tasks', icon: 'fas fa-clock', category: 'settings' },
};

const SUBUSER_PERMISSION_CATEGORIES = {
    core: { label: 'Core Actions', icon: 'fas fa-bolt', color: 'var(--danger)' },
    files: { label: 'File Management', icon: 'fas fa-folder', color: 'var(--info)' },
    plugins: { label: 'Plugin Management', icon: 'fas fa-puzzle-piece', color: 'var(--purple)' },
    worlds: { label: 'World Management', icon: 'fas fa-globe', color: 'var(--success)' },
    backups: { label: 'Backup Management', icon: 'fas fa-database', color: 'var(--warning)' },
    players: { label: 'Player Management', icon: 'fas fa-users', color: 'var(--pink)' },
    settings: { label: 'Server Settings', icon: 'fas fa-cogs', color: 'var(--amber)' },
};

// ================================================
// SUBUSERS ROUTES
// ================================================
app.get('/servers/:id/subusers', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).send('Server not found');
        // Only owner or admin can manage subusers
        if (server.owner_id !== req.session.user.id && req.session.user.role !== 'admin')
            return res.status(403).send('Access denied');
        const subusers = await dbAll(
            `SELECT subusers.id, subusers.permissions, users.username, users.id as user_id
             FROM subusers
             JOIN users ON subusers.user_id = users.id
             WHERE subusers.server_id = ?`,
            [serverId]
        );
        res.render('servers/subusers', await getTemplateVars(req, server, {
            subusers,
            serverId: server.id,
            activePage: 'subusers',
            currentPage: 'subusers',
            title: `${server.name} - Sub Users`,
            permissions: SUBUSER_PERMISSIONS,
            permissionCategories: SUBUSER_PERMISSION_CATEGORIES
        }));
    } catch (err) {
        console.error('Subusers page error:', err);
        res.status(500).send('Internal server error');
    }
});
app.post('/servers/:id/subusers/add', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        const { username, permissions } = req.body;
        if (!username?.trim())
            return res.status(400).json({ error: 'Username is required' });
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        if (server.owner_id !== req.session.user.id && req.session.user.role !== 'admin')
            return res.status(403).json({ error: 'Access denied' });
        const user = await dbGet('SELECT * FROM users WHERE username = ?', [username.trim()]);
        if (!user) return res.status(404).json({ error: 'User not found' });
        if (user.id === server.owner_id) return res.status(400).json({ error: 'Owner cannot be added as subuser' });
        const existingSub = await dbGet(
            'SELECT * FROM subusers WHERE server_id = ? AND user_id = ?',
            [serverId, user.id]
        );
        if (existingSub) return res.status(400).json({ error: 'User is already a subuser' });
        const permsJson = JSON.stringify(Array.isArray(permissions) ? permissions : []);
        await dbRun('INSERT INTO subusers (server_id, user_id, permissions) VALUES (?, ?, ?)', [serverId, user.id, permsJson]);
        
        // Return JSON for modal, redirect for form submit
        if (req.headers.accept?.includes('application/json') || req.body.permissions) {
            return res.json({ success: true, message: 'Subuser added successfully' });
        }
        res.redirect(`/servers/${serverId}/subusers`);
    } catch (err) {
        console.error('Add subuser error:', err);
        res.status(500).json({ error: 'Failed to add subuser' });
    }
});
app.put('/servers/:id/subusers/:subuserId/permissions', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        const subuserId = req.params.subuserId;
        const { permissions } = req.body;
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        if (server.owner_id !== req.session.user.id && req.session.user.role !== 'admin')
            return res.status(403).json({ error: 'Access denied' });
        
        const subuser = await dbGet('SELECT * FROM subusers WHERE id = ? AND server_id = ?', [subuserId, serverId]);
        if (!subuser) return res.status(404).json({ error: 'Subuser not found' });
        
        const permsJson = JSON.stringify(Array.isArray(permissions) ? permissions : []);
        await dbRun('UPDATE subusers SET permissions = ? WHERE id = ?', [permsJson, subuserId]);
        
        res.json({ success: true, message: 'Permissions updated successfully' });
    } catch (err) {
        console.error('Update subuser permissions error:', err);
        res.status(500).json({ error: 'Failed to update permissions' });
    }
});
app.post('/servers/:id/subusers/remove', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        const { subuserId } = req.body;
        if (!subuserId) return res.status(400).json({ error: 'Subuser ID is required' });
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        if (server.owner_id !== req.session.user.id && req.session.user.role !== 'admin')
            return res.status(403).json({ error: 'Access denied' });
        const deleted = await dbRun(
            'DELETE FROM subusers WHERE id = ? AND server_id = ?',
            [subuserId, serverId]
        );
        if (deleted.changes === 0) return res.status(404).json({ error: 'Subuser not found' });
        
        // Return JSON for modal
        if (req.headers.accept?.includes('application/json')) {
            return res.json({ success: true, message: 'Subuser removed successfully' });
        }
        res.redirect(`/servers/${serverId}/subusers`);
    } catch (err) {
        console.error('Remove subuser error:', err);
        res.status(500).json({ error: 'Failed to remove subuser' });
    }
});
// ================================================
// SERVER SETTINGS ROUTES
// ================================================
app.get('/servers/:id/settings', requireAuth, requirePermission('settings'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).render('error', await getTemplateVars(req, null, { message: 'Access denied', status: 403, title: 'Error' }));
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).render('error', await getTemplateVars(req, null, { message: 'Server not found', status: 404, title: 'Error' }));
        
        const serverSettings = JSON.parse(server.settings || '{}');
        const versions = await fetchMinecraftVersions(server.server_type);
        const serverSoftware = getAvailableServerSoftware();
        
        // Disk usage: fetch from remote node stats
        let diskUsage = 0;
        let diskUsagePercent = 0;
        try {
            if (server.node_id) {
                // Fetch disk usage from remote node
                console.log(`📊 Fetching disk stats for server ${serverId} from remote node ${server.node_id}`);
                const stats = await remoteNodeRequest(server.node_id, 'GET', `/servers/${serverId}/stats`, { timeoutMs: 10000 });
                console.log(`📊 Stats from remote node (keys):`, Object.keys(stats));
                
                // Stats can be in different formats
                let diskData = stats;
                if (stats && stats.result) {
                    diskData = stats.result;
                }
                
                if (diskData) {
                    // Get diskUsedMB and convert to bytes
                    const diskUsedMB = diskData.diskUsedMB || 0;
                    diskUsage = diskUsedMB * 1024 * 1024;
                    diskUsagePercent = diskData.disk || diskData.diskPercent || 0;
                    console.log(`✅ Disk: ${diskUsagePercent}% (${diskUsedMB} MB = ${diskUsage} bytes)`);
                }
            }
        } catch (statsErr) {
            console.warn(`⚠️ Failed to fetch disk stats from remote node: ${statsErr.message}`);
        }
        
        // Get template vars with server context
        const templateVars = await getTemplateVars(req, server, {
            serverSettings,
            versions,
            serverSoftware,
            diskUsage: formatFileSize(diskUsage),
            diskUsagePercent,
            serverId,
            query: req.query,
            currentPage: 'settings',
            activePage: 'settings',
            title: `${server.name} - Settings`
        });
        
        // Ensure server is explicitly available at top level for sidebar
        templateVars.server = server;
        
        res.render('servers/settings', templateVars);
    } catch (err) {
        console.error('Settings error:', err);
        res.status(500).render('error', await getTemplateVars(req, null, { message: 'Failed to load settings', status: 500, title: 'Error' }));
    }
});
// Get versions for specific server software
app.get('/servers/:id/settings/versions/:serverType', requireAuth, requirePermission('settings'), async (req, res) => {
    try {
        const serverId = req.params.id;
        const serverType = req.params.serverType;
        
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const versions = await fetchMinecraftVersions(serverType);
        res.json({ success: true, versions });
    } catch (err) {
        console.error('Fetch versions error:', err);
        res.status(500).json({ error: 'Failed to fetch versions' });
    }
});

// Validate custom version
app.post('/servers/:id/settings/validate-version', requireAuth, requirePermission('settings'), async (req, res) => {
    try {
        const serverId = req.params.id;
        const { version, serverType } = req.body;
        
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        if (!version) {
            return res.status(400).json({ error: 'Version is required' });
        }
        
        const isValid = isValidMinecraftVersion(version);
        
        if (isValid) {
            res.json({ 
                success: true, 
                valid: true, 
                message: `Version "${version}" is valid for ${serverType}`,
                version: version.trim()
            });
        } else {
            res.json({ 
                success: true, 
                valid: false, 
                message: 'Invalid version format. Use formats like: 1.20.1, 1.19.4, 20w14a, latest, etc.'
            });
        }
    } catch (err) {
        console.error('Validate version error:', err);
        res.status(500).json({ error: 'Failed to validate version' });
    }
});

app.post('/servers/:id/settings/update', requireAuth, requirePermission('settings'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const { name, description, version, serverType } = req.body;
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }
        
        if (server.owner_id !== req.session.user.id && req.session.user.role !== 'admin') {
            return res.status(403).json({ error: 'Access denied' });
        }
        
        if (!name) {
            return res.status(400).json({ error: 'Server name is required' });
        }
        
        // Update server information
        const updateFields = [name, description || null];
        let updateQuery = 'UPDATE servers SET name = ?, description = ?';
        
        let message = 'Settings updated successfully';
        
        // If version and serverType are provided, update them too
        if (version && serverType) {
            updateQuery += ', version = ?, server_type = ?';
            updateFields.push(version, serverType);
            
            // DO NOT change port when server type changes - keep existing port
            // Only update configuration files to match the new server type
            if (serverType !== server.server_type) {
                console.log(`Server ${serverId} type changed from ${server.server_type} to ${serverType}, keeping existing port ${server.port}`);
                message += ` Server type updated. Port ${server.port} preserved.`;
            }
            
            message += '. Server software and version updated - restart server to apply changes.';
        }
        
        updateQuery += ' WHERE id = ?';
        updateFields.push(serverId);
        
        await dbRun(updateQuery, updateFields);
        
        // If server type changed, update configuration files with existing port
        if (version && serverType && serverType !== server.server_type) {
            try {
                // Use the existing port (don't change it)
                await updateServerConfigurationPort(serverId, serverType, server.port);
                console.log(`Updated configuration files for server ${serverId} (${serverType}) with existing port ${server.port}`);
            } catch (configErr) {
                console.error(`Failed to update configuration files for server ${serverId}:`, configErr);
                // Don't fail the entire request for config file issues
            }
        }
        
        res.json({ success: true, message });
    } catch (err) {
        console.error('Update settings error:', err);
        res.status(500).json({ error: 'Failed to update settings' });
    }
});

// ================================================
// VELOCITY CONFIGURATION MANAGEMENT SYSTEM
// ================================================

// Velocity configuration page
app.get('/servers/:id/velocity', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!(await isAuthorized(req, serverId))) {
            return res.status(403).send('Access denied');
        }

        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).send('Server not found');
        }

        // Only allow for Velocity servers
        if (server.server_type !== 'velocity') {
            return res.status(400).send('This server is not a Velocity proxy server');
        }

        res.render('servers/velocity', await getTemplateVars(req, server, {
            activePage: 'velocity',
            currentPage: 'velocity-config'
        }));
    } catch (err) {
        console.error('Velocity config page error:', err);
        res.status(500).send('Internal server error');
    }
});

// Get current Velocity configuration as JSON
app.get('/servers/:id/velocity/get', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!(await isAuthorized(req, serverId))) {
            return res.status(403).json({ error: 'Access denied' });
        }

        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }

        if (server.server_type !== 'velocity') {
            return res.status(400).json({ error: 'This server is not a Velocity proxy server' });
        }

        const configPath = resolveServerPath(serverId, 'velocity.toml');
        let config = {};

        if (fs.existsSync(configPath)) {
            try {
                const content = fs.readFileSync(configPath, 'utf8');
                config = parseVelocityToml(content);
            } catch (err) {
                console.error('Error reading velocity.toml:', err);
                config = getDefaultVelocityConfig(server);
            }
        } else {
            config = getDefaultVelocityConfig(server);
            await updateVelocityConfig(serverId, config);
        }

        res.json({ success: true, config });
    } catch (err) {
        console.error('Get Velocity config error:', err);
        res.status(500).json({ error: 'Failed to load Velocity configuration' });
    }
});

// Save Velocity configuration
app.post('/servers/:id/velocity/save', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!(await isAuthorized(req, serverId))) {
            return res.status(403).json({ error: 'Access denied' });
        }

        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }

        if (server.server_type !== 'velocity') {
            return res.status(400).json({ error: 'This server is not a Velocity proxy server' });
        }

        const { config } = req.body;
        if (!config || typeof config !== 'object') {
            return res.status(400).json({ error: 'Invalid configuration data' });
        }

        // Ensure bind port is protected
        config.bind = `0.0.0.0:${server.port}`;

        const configPath = resolveServerPath(serverId, 'velocity.toml');
        
        // Write configuration to file
        writeVelocityToml(config, configPath);

        console.log(`Velocity configuration saved for server ${serverId}`);
        
        res.json({ 
            success: true, 
            message: 'Velocity configuration saved successfully!',
            warning: 'Bind port is protected and managed automatically'
        });
    } catch (err) {
        console.error('Save Velocity config error:', err);
        res.status(500).json({ error: 'Failed to save Velocity configuration' });
    }
});

// Reset Velocity configuration to defaults
app.post('/servers/:id/velocity/reset', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!(await isAuthorized(req, serverId))) {
            return res.status(403).json({ error: 'Access denied' });
        }

        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }

        if (server.server_type !== 'velocity') {
            return res.status(400).json({ error: 'This server is not a Velocity proxy server' });
        }

        const defaultConfig = getDefaultVelocityConfig(server);
        await updateVelocityConfig(serverId, defaultConfig);

        console.log(`Velocity configuration reset to defaults for server ${serverId}`);
        
        res.json({ 
            success: true, 
            message: 'Velocity configuration reset to defaults!',
            config: defaultConfig
        });
    } catch (err) {
        console.error('Reset Velocity config error:', err);
        res.status(500).json({ error: 'Failed to reset Velocity configuration' });
    }
});

// ================================================
// VELOCITY CONFIGURATION HELPER FUNCTIONS
// ================================================

// Parse Velocity TOML configuration
function parseVelocityToml(content) {
    const config = {};
    const lines = content.split('\n');
    let currentSection = null;
    
    for (const line of lines) {
        const trimmed = line.trim();
        
        // Skip comments and empty lines
        if (!trimmed || trimmed.startsWith('#')) continue;
        
        // Handle sections
        if (trimmed.startsWith('[') && trimmed.endsWith(']')) {
            currentSection = trimmed.slice(1, -1);
            if (!config[currentSection]) config[currentSection] = {};
            continue;
        }
        
        // Handle key-value pairs
        const equalIndex = trimmed.indexOf('=');
        if (equalIndex === -1) continue;
        
        const key = trimmed.substring(0, equalIndex).trim();
        let value = trimmed.substring(equalIndex + 1).trim();
        
        // Parse value types
        if (value.startsWith('"') && value.endsWith('"')) {
            value = value.slice(1, -1); // String
        } else if (value === 'true' || value === 'false') {
            value = value === 'true'; // Boolean
        } else if (!isNaN(value)) {
            value = parseInt(value); // Number
        } else if (value.startsWith('[') && value.endsWith(']')) {
            // Array
            value = value.slice(1, -1).split(',').map(v => v.trim().replace(/"/g, ''));
        }
        
        if (currentSection) {
            config[currentSection][key] = value;
        } else {
            config[key] = value;
        }
    }
    
    return config;
}

// Generate default Velocity configuration
function getDefaultVelocityConfig(server) {
    return {
        // Main configuration
        'config-version': '2.6',
        'bind': `0.0.0.0:${server.port}`,
        'motd': server.name || 'A Velocity Server',
        'show-max-players': 500,
        'online-mode': true,
        'prevent-client-proxy-connections': false,
        'player-info-forwarding-mode': 'MODERN',
        'forwarding-secret-file': 'forwarding.secret',
        'announce-forge': false,
        'kick-existing-players': false,
        'ping-passthrough': 'DISABLED',
        'enable-player-address-logging': true,
        'bungee-plugin-message-channel': true,
        'show-ping-requests': false,
        'failover-on-unexpected-server-disconnect': true,
        'announce-proxy-commands': true,
        'log-command-executions': false,
        'log-player-connections': true,
        
        // Servers section
        'servers': {
            'lobby': 'localhost:25565',
            'survival': 'localhost:25566'
        },
        
        // Try section
        'try': ['lobby'],
        
        // Forced hosts
        'forced-hosts': {},
        
        // Advanced section
        'advanced': {
            'compression-threshold': 256,
            'compression-level': -1,
            'login-ratelimit': 3000,
            'connection-timeout': 5000,
            'read-timeout': 30000,
            'haproxy-protocol': false,
            'tcp-fast-open': false,
            'bungee-plugin-message-channel': true,
            'show-ping-requests': false,
            'failover-on-unexpected-server-disconnect': true,
            'announce-proxy-commands': true,
            'log-command-executions': false,
            'log-player-connections': true
        },
        
        // Query section
        'query': {
            'enabled': false,
            'port': server.port + 1,
            'map': 'Velocity',
            'show-plugins': false
        }
    };
}

// Write Velocity TOML configuration
function writeVelocityToml(config, filePath) {
    let content = '# Velocity Configuration\n';
    content += '# Generated by Minecraft Server Panel\n\n';
    
    // Write main configuration values
    const mainKeys = ['config-version', 'bind', 'motd', 'show-max-players', 'online-mode', 
                     'prevent-client-proxy-connections', 'player-info-forwarding-mode', 
                     'forwarding-secret-file', 'announce-forge', 'kick-existing-players',
                     'ping-passthrough', 'enable-player-address-logging', 'bungee-plugin-message-channel',
                     'show-ping-requests', 'failover-on-unexpected-server-disconnect',
                     'announce-proxy-commands', 'log-command-executions', 'log-player-connections'];
    
    for (const key of mainKeys) {
        if (config[key] !== undefined) {
            content += `${key} = ${formatTomlValue(config[key])}\n`;
        }
    }
    
    content += '\n';
    
    // Write servers section
    if (config.servers) {
        content += '[servers]\n';
        for (const [name, address] of Object.entries(config.servers)) {
            content += `${name} = "${address}"\n`;
        }
        content += '\n';
    }
    
    // Write try section
    if (config.try && Array.isArray(config.try)) {
        content += `try = [${config.try.map(s => `"${s}"`).join(', ')}]\n\n`;
    }
    
    // Write forced-hosts section
    if (config['forced-hosts']) {
        content += '[forced-hosts]\n';
        for (const [host, server] of Object.entries(config['forced-hosts'])) {
            content += `"${host}" = "${server}"\n`;
        }
        content += '\n';
    }
    
    // Write advanced section
    if (config.advanced) {
        content += '[advanced]\n';
        for (const [key, value] of Object.entries(config.advanced)) {
            content += `${key} = ${formatTomlValue(value)}\n`;
        }
        content += '\n';
    }
    
    // Write query section
    if (config.query) {
        content += '[query]\n';
        for (const [key, value] of Object.entries(config.query)) {
            content += `${key} = ${formatTomlValue(value)}\n`;
        }
        content += '\n';
    }
    
    fs.writeFileSync(filePath, content, 'utf8');
}

// Format value for TOML
function formatTomlValue(value) {
    if (typeof value === 'string') {
        return `"${value}"`;
    } else if (typeof value === 'boolean') {
        return value.toString();
    } else if (typeof value === 'number') {
        return value.toString();
    } else if (Array.isArray(value)) {
        return `[${value.map(v => `"${v}"`).join(', ')}]`;
    }
    return `"${value}"`;
}

// Update Velocity configuration file
async function updateVelocityConfig(serverId, config) {
    const configPath = resolveServerPath(serverId, 'velocity.toml');
    writeVelocityToml(config, configPath);
}

// Server delete route
app.post('/servers/:id/delete', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        // ONLY ADMIN can delete servers
        if (req.session.user.role !== 'admin') {
            return res.status(403).json({ error: 'Only administrators can delete servers' });
        }
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }
        
        // Stop server if running
        await stopServer(serverId, true);
        
        // If remote server, queue action to daemon
        if (server.node_id) {
            console.log(`📤 Queuing delete command for remote node ${server.node_id}, server ${serverId}`);
            await queueNodeAction(server.node_id, serverId, 'delete', {});
            // Delete from database
            await dbRun('DELETE FROM servers WHERE id = ?', [serverId]);
            return res.json({ success: true, message: 'Server deletion queued on remote node' });
        }
        
        // Delete from database
        await dbRun('DELETE FROM servers WHERE id = ?', [serverId]);
        
        // Remote-only architecture: server files are deleted on remote node via agent
        // No local files to clean up
        
        // Clean up any remaining references
        delete global.serverProcesses[serverId];
        delete serverStartTimes[serverId];
        delete onlinePlayers[serverId];
        delete liveStats[serverId];
        
        res.json({ success: true, message: 'Server deleted successfully' });
    } catch (err) {
        console.error('Delete server error:', err);
        res.status(500).json({ error: 'Failed to delete server' });
    }
});
app.post('/servers/:id/settings/reinstall', requireAuth, requirePermission('settings'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }
        
        if (server.owner_id !== req.session.user.id && req.session.user.role !== 'admin') {
            return res.status(403).json({ error: 'Access denied' });
        }
        
        // Stop server if running
        if (await isServerRunning(serverId)) {
            await stopServer(serverId, true);
        }
        

        if (server.node_id) {
            console.log(`📤 Queuing reinstall command for remote node ${server.node_id}, server ${serverId}`);
            await queueNodeAction(server.node_id, serverId, 'reinstall', {
                version: req.body.version || server.version,
                serverType: req.body.server_type || server.server_type
            });
            return res.json({ 
                success: true, 
                message: '✅ Server reinstall queued on remote node!' 
            });
        }
        
        // Local Node: do file operations locally
        const serverDir = resolveServerPath(serverId);
        
        // DISABLED: Don't delete and recreate directory, just update configuration
        // if (fs.existsSync(serverDir)) {
        //     fs.rmSync(serverDir, { recursive: true, force: true });
        // }
        // fs.mkdirSync(serverDir, { recursive: true });
        
        // Ensure server directory exists
        if (!fs.existsSync(serverDir)) {
            fs.mkdirSync(serverDir, { recursive: true });
        }
        
        // Download server jar
        console.log(`🔄 Reinstalling server ${serverId} with ${server.server_type} ${server.version}...`);
        await downloadServerJar(server.server_type, server.version, serverDir);
        
        // Create EULA if it doesn't exist
        const eulaPath = path.join(serverDir, 'eula.txt');
        if (!fs.existsSync(eulaPath)) {
            fs.writeFileSync(eulaPath, 'eula=true\n', 'utf8');
        }
        
        // Update server.properties with existing port (don't change it)
        const propertiesPath = path.join(serverDir, 'server.properties');
        const properties = {
            'server-port': server.port, // Keep existing port
            'server-ip': server.server_ip || '',
            'max-players': 20,
            'online-mode': true,
            'view-distance': 10,
            'simulation-distance': 10,
            'motd': server.name
        };
        writeProperties(properties, propertiesPath);
        
        // Update configuration files for the server type
        try {
            await updateServerConfigurationPort(serverId, server.server_type, server.port);
            console.log(`Updated configuration files for server ${serverId} (${server.server_type}) with existing port ${server.port}`);
        } catch (configErr) {
            console.error(`Failed to update configuration files for server ${serverId}:`, configErr);
        }
        
        res.json({ 
            success: true, 
            message: '✅ Server reinstalled successfully! Configuration updated, no files downloaded.' 
        });
    } catch (err) {
        console.error('Server reinstall error:', err);
        res.status(500).json({ error: 'Failed to reinstall server: ' + err.message });
    }
});
// ================================================
// STARTUP ROUTES
// ================================================
app.get('/servers/:id/startup', requireAuth, requirePermission('startup'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).send('Access denied');
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).send('Server not found');
        
        const startup = server.startup_command || `java -Xms${Math.max(64, Math.floor(server.ram / 2))}M -Xmx${server.ram}M -jar server.jar nogui`;
        
        // Minimal defaults only for keys a real server.properties always has
        const defaults = {
            'server-port': server.port,
            'server-ip': server.server_ip || '0.0.0.0',
            'max-players': 20,
            'online-mode': true,
            'motd': server.name
        };
        
        let storedSettings = JSON.parse(server.settings || '{}');
        let storedProperties = storedSettings.properties || {};
        
        // Primary source: LIVE server.properties on the node — the page renders
        // exactly what the file contains, nothing hardcoded.
        let properties = null;
        if (server.node_id) {
            try {
                const remoteProps = await remoteNodeRequest(server.node_id, 'GET', `/servers/${serverId}/properties`, { timeoutMs: 5000 });
                if (remoteProps && typeof remoteProps === 'object' && Object.keys(remoteProps).length > 0) {
                    properties = remoteProps;
                    for (const key of Object.keys(defaults)) {
                        if (!(key in properties)) properties[key] = defaults[key];
                    }
                    console.log(`📥 Live server.properties fetched for server ${serverId}: ${Object.keys(remoteProps).length} keys`);
                }
            } catch (err) {
                console.warn(`⚠️ Remote server.properties not available: ${err.message}, falling back to stored/defaults`);
            }
        }
        
        // Fallback: stored database snapshot, then defaults
        if (!properties) {
            properties = { ...defaults, ...storedProperties };
            console.log(`📋 Using ${Object.keys(storedProperties).length} stored properties from database for server ${serverId}`);
        }
        
        // Dynamic split: booleans become Gameplay Toggles (true=tick, false=untick),
        // everything else becomes Server Properties inputs. No hardcoded key lists.
        const booleanProps = [];
        const otherProps = [];
        for (const key of Object.keys(properties)) {
            if (typeof properties[key] === 'boolean') booleanProps.push({ key, value: properties[key] });
            else otherProps.push({ key, value: properties[key] });
        }
        
        res.render('servers/startup', await getTemplateVars(req, server, {
            startup, 
            properties,
            booleanProps,
            otherProps,
            booleanKeysJson: JSON.stringify(booleanProps.map(p => p.key)),
            success: req.query.success, 
            error: req.query.error, 
            serverId: server.id, 
            activePage: 'startup',
            currentPage: 'startup',
            title: `${server.name} - Startup`
        }));
    } catch (err) {
        console.error('Startup page error', err);
        res.status(500).send('Internal error');
    }
});
app.post('/servers/:id/startup/update', requireAuth, requirePermission('startup'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        
        const { startup, properties, toggle_fields, boolean_keys } = req.body;
        const isOwnerOrAdmin = server.owner_id === req.session.user.id || req.session.user.role === 'admin';
        // Subusers may save properties, but only owner/admin can change the startup command
        const startupCommand = (isOwnerOrAdmin ? startup : null) || server.startup_command || `java -Xms${Math.max(64, Math.floor(server.ram / 2))}M -Xmx${server.ram}M -jar server.jar nogui`;
        
        let settings = JSON.parse(server.settings || '{}');
        let storedProperties = settings.properties || {};
        
        // Which keys are boolean toggles is decided by the live server.properties
        // rendering — the form tells us, nothing hardcoded here.
        let booleanKeys = [];
        try {
            const parsed = JSON.parse(typeof boolean_keys === 'string' ? boolean_keys : '[]');
            if (Array.isArray(parsed)) booleanKeys = parsed.map(String);
        } catch (e) { booleanKeys = []; }
        
        // Parse ONLY the properties that came from the form
        let formChanges = {};
        if (properties && typeof properties === 'object') {
            for (let key in properties) {
                let value = properties[key];
                
                if (booleanKeys.includes(key)) {
                    // Checkbox toggles: present means checked (true)
                    formChanges[key] = value === 'true';
                } else if (value === 'true') {
                    formChanges[key] = true;
                } else if (value === 'false') {
                    formChanges[key] = false;
                } else if (/^-?\d+(\.\d+)?$/.test(String(value))) {
                    formChanges[key] = Number(value);
                } else {
                    formChanges[key] = value;
                }
            }
        }
        
        // Unchecked toggles submit nothing. Only wipe them to false when the
        // submission is the real current form (sentinel present); a stale or
        // broken form that carries no toggle fields must not blank stored values.
        if (toggle_fields) {
            for (let toggleKey of booleanKeys) {
                if (!(toggleKey in formChanges)) {
                    formChanges[toggleKey] = false;
                }
            }
        }
        
        // MERGE over the LIVE server.properties when available — stale database
        // snapshots must never reintroduce keys the file no longer has.
        let baseProperties = storedProperties;
        if (server.node_id) {
            try {
                const liveProps = await remoteNodeRequest(server.node_id, 'GET', `/servers/${serverId}/properties`, { timeoutMs: 5000 });
                if (liveProps && typeof liveProps === 'object' && Object.keys(liveProps).length > 0) {
                    baseProperties = liveProps;
                }
            } catch (err) { /* fall back to DB snapshot */ }
        }
        let propsToSave = { ...baseProperties, ...formChanges };
        
        settings.properties = propsToSave;
        
        // Update database
        await dbRun('UPDATE servers SET settings = ?, startup_command = ? WHERE id = ?', 
            [JSON.stringify(settings), startupCommand, serverId]);
        
        console.log(`💾 Saved properties for server ${serverId}`);
        console.log(`📋 Form changes: ${Object.keys(formChanges).length} fields, Merged total: ${Object.keys(propsToSave).length} properties`);
        
        // Queue properties update - send ALL merged properties so remote node can merge too
        if (server.node_id) {
            try {
                await queueNodeAction(server.node_id, serverId, 'properties-save', { 
                    properties: propsToSave,
                    action: 'update_properties'
                });
                console.log(`📤 Queued ${Object.keys(propsToSave).length} properties to remote node ${server.node_id}`);
            } catch (err) {
                console.warn(`⚠️ Failed to queue properties update: ${err.message}`);
            }
        }
        
        res.redirect(`/servers/${serverId}/startup?success=Startup and server properties updated`);
    } catch (err) {
        console.error('Update startup error', err);
        res.redirect(`/servers/${serverId}/startup?error=Failed to update startup or server properties`);
    }
});
// ================================================
// BACKUPS ROUTES
// ================================================
app.post('/servers/:id/backups/create', requireAuth, requirePermission('backups_create'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const { name, description } = req.body;
        const backupName = name || `Backup ${new Date().toLocaleString()}`;
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        
        // Check backup limit
        const backupLimit = server.backup_limit || 10;
        if (backupLimit > 0) {
            const backupDir = path.join(__dirname, 'daemon', 'backups', serverId.toString());
            let backupCount = 0;
            if (fs.existsSync(backupDir)) {
                try {
                    const files = fs.readdirSync(backupDir);
                    backupCount = files.filter(f => f.endsWith('.zip')).length;
                } catch (err) {
                    console.warn('Error counting backups:', err.message);
                }
            }
            
            if (backupCount >= backupLimit) {
                return res.status(409).json({ 
                    error: `Backup limit reached! You have ${backupCount} backup(s) but your limit is ${backupLimit}. Delete old backups to create new ones.` 
                });
            }
        }
        

        if (server.node_id) {
            console.log(`📤 Queuing backup create command for remote node ${server.node_id}, server ${serverId}`);
            
            // Store pending backup in database with placeholder so it shows up in the UI
            const fileName = `backup-${Date.now()}.zip`;
            try {
                await dbRun('INSERT INTO backups (server_id, file, name, description, size, created_at) VALUES (?, ?, ?, ?, ?, ?)', [
                    serverId, fileName, backupName, description || null, 'Creating...', new Date().toISOString()
                ]);
                console.log(`💾 Stored backup record in database for tracking: ${fileName}`);
            } catch (dbErr) {
                console.warn(`Failed to store backup in database: ${dbErr.message}`);
            }
            
            // Queue to remote node
            await queueNodeAction(server.node_id, serverId, 'backup-create', {
                name: backupName,
                description: description || null,
                backup_limit: server.backup_limit || 10
            });
            return res.json({ 
                success: true, 
                message: 'Backup creation queued on remote node!',
                queued: true
            });
        }
        
        // Local Node: create backup locally
        // Store backups in /daemon/backups/:id/ for consistency
        const backupDir = path.join(__dirname, 'daemon', 'backups', serverId.toString());
        fs.mkdirSync(backupDir, { recursive: true });
        const fileName = `backup-${Date.now()}.zip`;
        const filePath = path.join(backupDir, fileName);
        
        let wasRunning = false;
        let responseSent = false;
        
        // Check if server is running
        if (server.status === 'running') {
            wasRunning = true;
            console.log(`Stopping server ${serverId} for backup...`);
            
            // Stop the server
            await stopServer(serverId);
            
            // Wait for server to fully stop
            await new Promise(resolve => setTimeout(resolve, 3000));
        }
        
        // Create backup
        const output = fs.createWriteStream(filePath);
        const archive = archiver('zip', { zlib: { level: 9 } });
        
        output.on('close', async () => {
            if (responseSent) return;
            responseSent = true;
            
            try {
                // Get file size
                const stats = fs.statSync(filePath);
                const sizeInBytes = stats.size;
                const sizeInMB = (sizeInBytes / (1024 * 1024)).toFixed(2);
                const sizeInGB = (sizeInBytes / (1024 * 1024 * 1024)).toFixed(2);
                const sizeStr = sizeInGB >= 1 ? `${sizeInGB} GB` : `${sizeInMB} MB`;
                
                await dbRun('INSERT INTO backups (server_id, file, name, description, size, created_at) VALUES (?, ?, ?, ?, ?, ?)', [
                    serverId, fileName, backupName, description || null, sizeStr, new Date().toISOString()
                ]);
                
                // Cleanup old backups if limit is exceeded
                const backupLimit = server.backup_limit || 10;
                if (backupLimit > 0) {
                    try {
                        // Get all backups for this server, ordered by creation date (newest first)
                        const allBackups = await dbAll(
                            'SELECT id, file FROM backups WHERE server_id = ? ORDER BY created_at DESC',
                            [serverId]
                        );
                        
                        // Delete backups beyond the limit
                        if (allBackups.length > backupLimit) {
                            const backupsToDelete = allBackups.slice(backupLimit);
                            
                            for (const backup of backupsToDelete) {
                                try {
                                    // Delete from filesystem
                                    const backupFilePath = path.join(backupDir, backup.file);
                                    if (fs.existsSync(backupFilePath)) {
                                        fs.unlinkSync(backupFilePath);
                                        console.log(`🗑️ Deleted old backup: ${backup.file}`);
                                    }
                                    
                                    // Delete from database
                                    await dbRun('DELETE FROM backups WHERE id = ?', [backup.id]);
                                } catch (deleteErr) {
                                    console.warn(`Failed to delete backup ${backup.file}:`, deleteErr.message);
                                }
                            }
                            
                            console.log(`✅ Cleanup: Deleted ${backupsToDelete.length} backups (kept ${backupLimit})`);
                        }
                    } catch (cleanupErr) {
                        console.warn('Backup cleanup error:', cleanupErr.message);
                        // Don't fail the backup creation if cleanup fails
                    }
                }
                
                // Restart server if it was running
                if (wasRunning) {
                    console.log(`Restarting server ${serverId} after backup...`);
                    setTimeout(async () => {
                        try {
                            await startServer(serverId);
                        } catch (err) {
                            console.error(`Failed to restart server ${serverId}:`, err);
                        }
                    }, 1000);
                }
                
                res.json({ 
                    success: true, 
                    message: wasRunning ? 'Backup created (server restarted)' : 'Backup created', 
                    file: fileName,
                    size: sizeStr
                });
            } catch (err) {
                console.error('Backup DB insert error:', err);
                res.status(500).json({ error: 'Failed to save backup record' });
            }
        });
        
        archive.on('error', async (err) => {
            if (responseSent) return;
            responseSent = true;
            console.error('Archive error:', err);
            
            // Restart server if it was running
            if (wasRunning) {
                console.log(`Restarting server ${serverId} after backup error...`);
                try {
                    await startServer(serverId);
                } catch (restartErr) {
                    console.error(`Failed to restart server ${serverId}:`, restartErr);
                }
            }
            
            res.status(500).json({ error: 'Failed to create backup: ' + err.message });
        });
        
        archive.pipe(output);
        // Exclude the backups directory from being backed up
        archive.glob('**/*', { cwd: serverDir, ignore: ['*.pid', '*.lock', 'logs/latest.log'] });
        archive.finalize();
        
    } catch (err) {
        console.error('Backup create error', err);
        if (!res.headersSent) {
            res.status(500).json({ error: 'Failed to create backup' });
        }
    }
});
app.get('/servers/:id/backups', requireAuth, requirePermission('backups'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).send('Access denied');
        const server = await dbGet('SELECT s.*, n.name AS node_name, n.ip_address AS node_ip, n.ip_alias AS node_ip_alias FROM servers s LEFT JOIN nodes n ON s.node_id = n.id WHERE s.id = ?', [serverId]);
        
        let backups = [];
        
        // Remote-only architecture: fetch backups from remote node
        if (server.node_id) {
            try {
                console.log(`📥 Fetching backups for server ${serverId} from remote node ${server.node_id}`);
                
                // Try the new /servers/:id/backups endpoint first
                try {
                    const remote = await remoteNodeRequest(server.node_id, 'GET', `/servers/${serverId}/backups`, { timeoutMs: 15000 });
                    console.log(`📥 Backups response from remote node:`, JSON.stringify(remote, null, 2).substring(0, 500));
                    
                    if (Array.isArray(remote?.backups) && remote.backups.length > 0) {
                        backups = remote.backups.map(backup => ({
                            id: Math.random().toString(36).substr(2, 9),
                            server_id: serverId,
                            name: backup.name || backup.file?.replace('backup-', '').replace('.zip', '') || 'Backup',
                            file: backup.file || backup.filename || '',
                            size: backup.size || backup.sizeFormatted || '0 MB',
                            created_at: backup.created_at || backup.modified || backup.timestamp || new Date().toISOString(),
                            description: null
                        }));
                        backups.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
                        console.log(`✅ Retrieved ${backups.length} backups from /servers/:id/backups endpoint`);
                    }
                } catch (backupErr) {
                    console.log(`⚠️ New backups endpoint not available (${backupErr.message}), trying file-list endpoint...`);
                    
                    // Fallback: Use /servers/:id/files endpoint with path parameter to list backups
                    try {
                        const fileList = await remoteNodeRequest(server.node_id, 'GET', `/servers/${serverId}/files?path=%2Fbackups`, { timeoutMs: 10000 });
                        console.log(`📋 File list response:`, JSON.stringify(fileList, null, 2).substring(0, 500));
                        
                        let files = [];
                        if (Array.isArray(fileList?.result)) {
                            files = fileList.result;
                        } else if (Array.isArray(fileList)) {
                            files = fileList;
                        }
                        
                        const backupFiles = files.filter(f => {
                            const fname = String(f.name || f.filename || '');
                            const isDir = Boolean(f.isDirectory || f.directory);
                            return fname.endsWith('.zip') && !isDir;
                        });
                        
                        if (backupFiles.length > 0) {
                            backups = backupFiles.map(file => ({
                                id: Math.random().toString(36).substr(2, 9),
                                server_id: serverId,
                                name: (file.name || '').replace('backup-', '').replace('.zip', ''),
                                file: file.name || file.filename || '',
                                size: file.size || file.sizeFormatted || '0 MB',
                                created_at: file.modified || file.mtime || new Date().toISOString(),
                                description: null
                            }));
                            backups.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
                            console.log(`✅ Retrieved ${backups.length} backups from file-list endpoint`);
                        }
                    } catch (fileErr) {
                        console.log(`⚠️ File-list endpoint also failed: ${fileErr.message}`);
                    }
                }
                
                // Database fallback if remote didn't return anything
                if (backups.length === 0) {
                    try {
                        console.log(`💾 Trying database fallback for server ${serverId}`);
                        const dbBackups = await dbAll('SELECT id, file, name, description, size, created_at FROM backups WHERE server_id = ? ORDER BY created_at DESC LIMIT 50', [serverId]);
                        if (dbBackups && dbBackups.length > 0) {
                            console.log(`✅ Retrieved ${dbBackups.length} backups from database`);
                            backups = dbBackups;
                        }
                    } catch (dbErr) {
                        console.log(`Database lookup failed: ${dbErr.message}`);
                    }
                }
            } catch (err) {
                console.warn(`❌ Unexpected error fetching backups: ${err.message}`);
                backups = [];
            }
        } else {
            // Fallback: Local filesystem (for local servers only)
            console.log(`📂 Fetching backups for server ${serverId} from local filesystem`);
            const backupDirPath = path.join(__dirname, 'daemon', 'backups', serverId.toString());
            if (fs.existsSync(backupDirPath)) {
                try {
                    const files = fs.readdirSync(backupDirPath);
                    backups = files
                        .filter(f => f.endsWith('.zip'))
                        .map(file => {
                            const filePath = path.join(backupDirPath, file);
                            const stats = fs.statSync(filePath);
                            const sizeInBytes = stats.size;
                            const sizeInMB = (sizeInBytes / (1024 * 1024)).toFixed(2);
                            const sizeInGB = (sizeInBytes / (1024 * 1024 * 1024)).toFixed(2);
                            const sizeStr = sizeInGB >= 1 ? `${sizeInGB} GB` : `${sizeInMB} MB`;
                            
                            return {
                                id: Math.random().toString(36).substr(2, 9),
                                server_id: serverId,
                                name: file.replace('backup-', '').replace('.zip', ''),
                                file: file,
                                size: sizeStr,
                                created_at: new Date(stats.mtime).toISOString()
                            };
                        })
                        .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
                } catch (err) {
                    console.error(`Error reading backup directory for server ${serverId}:`, err);
                }
            }
        }
        
        res.render('servers/backups', await getTemplateVars(req, server, {
            backups: backups, 
            backupLimit: server.backup_limit || 10,
            backupCount: backups.length,
            isBackupLimitReached: backups.length >= (server.backup_limit || 10),
            serverId: server.id, 
            activePage: 'backups',
            currentPage: 'backups',
            title: `${server.name} - Backups`
        }));
    } catch (err) {
        console.error('Backups page error', err);
        res.status(500).send('Internal error');
    }
});
app.get('/servers/:id/backups/download/:filename', requireAuth, requirePermission('backups_download'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).send('Access denied');
        
        const filename = decodeURIComponent(req.params.filename);
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).send('Server not found');
        
        // Remote-only architecture: download backup from remote node
        if (server.node_id) {
            try {
                console.log(`📥 Downloading backup ${filename} from remote node ${server.node_id}`);
                
                // Try direct download endpoint first (if available)
                try {
                    const node = await getNodeRecord(server.node_id);
                    const url = `http://${node.ip_address}:${node.daemon_port}/servers/${serverId}/backups/download/${encodeURIComponent(filename)}`;
                    const headers = {
                        'Authorization': `Bearer ${node.token}`,
                        'x-daemon-token': node.token
                    };
                    
                    const response = await axios({
                        method: 'GET',
                        url,
                        headers,
                        responseType: 'stream',
                        timeout: 300000,
                        validateStatus: () => true
                    });
                    
                    if (response.status === 200) {
                        res.setHeader('Content-Type', 'application/octet-stream');
                        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
                        return response.data.pipe(res);
                    } else {
                        throw new Error(`Remote returned HTTP ${response.status}`);
                    }
                } catch (directErr) {
                    console.log(`⚠️ Direct download failed (${directErr.message}), trying file-download command...`);
                    
                    // Fallback: use file-download command
                    const result = await remoteCommand(
                        server.node_id,
                        serverId,
                        'file-download',
                        { path: `/backups/${filename}` },
                        300000
                    );
                    
                    if (result.ok && result.result) {
                        const buffer = Buffer.from(result.result.base64 || result.result, 'base64');
                        res.setHeader('Content-Type', 'application/octet-stream');
                        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
                        res.setHeader('Content-Length', buffer.length);
                        return res.send(buffer);
                    }
                    
                    throw new Error('Download failed');
                }
            } catch (err) {
                console.error(`Failed to download backup: ${err.message}`);
                return res.status(500).send(`Download failed: ${err.message}`);
            }
        } else {
            // Local fallback
            const backupDir = path.join(__dirname, 'daemon', 'backups', serverId.toString());
            const filePath = path.join(backupDir, filename);
            
            const resolved = path.resolve(filePath);
            const rel = path.relative(path.resolve(backupDir), resolved);
            if (rel === '' || rel.startsWith('..') || path.isAbsolute(rel)) {
                return res.status(403).send('Invalid backup path');
            }
            
            if (!fs.existsSync(filePath)) {
                return res.status(404).send('Backup file not found');
            }
            
            res.download(filePath, filename);
        }
    } catch (err) {
        console.error('Download backup error:', err);
        res.status(500).send('Download failed');
    }
});
app.post('/servers/:id/backups/delete', requireAuth, requirePermission('backups_delete'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        
        const { filename } = req.body;
        if (!filename) return res.status(400).json({ error: 'Filename required' });
        
        if (server.node_id) {
            console.log(`📤 Queuing backup delete command for remote node ${server.node_id}, server ${serverId}`);
            await queueNodeAction(server.node_id, serverId, 'server-backup-delete', {
                fileName: filename
            });
            return res.json({ 
                success: true,
                message: 'Backup deletion queued on remote node!',
                queued: true
            });
        }
        
        // Local Node: delete locally
        // Use /daemon/backups/:id/ directory
        const backupDir = path.join(__dirname, 'daemon', 'backups', serverId.toString());
        const filePath = path.join(backupDir, filename);
        
        // Security check - ensure path is within backup directory
        const resolved = path.resolve(filePath);
        const rel = path.relative(path.resolve(backupDir), resolved);
        if (rel === '' || rel.startsWith('..') || path.isAbsolute(rel)) {
            return res.status(403).json({ error: 'Invalid backup path' });
        }
        
        // Delete file with retry logic to handle EBUSY errors
        if (fs.existsSync(filePath)) {
            let retries = 5;
            let deleted = false;
            
            while (retries > 0 && !deleted) {
                try {
                    // Force garbage collection to release any file handles
                    if (global.gc) {
                        global.gc();
                    }
                    
                    // Try to delete the file
                    await fs.promises.unlink(filePath);
                    deleted = true;
                    console.log(`Successfully deleted backup file: ${filename}`);
                    
                } catch (unlinkErr) {
                    retries--;
                    
                    if (unlinkErr.code === 'EBUSY' || unlinkErr.code === 'EPERM') {
                        if (retries > 0) {
                            console.log(`File is busy, retrying... (${retries} attempts left)`);
                            // Wait before retrying (exponential backoff)
                            await new Promise(resolve => setTimeout(resolve, 1000 * (6 - retries)));
                        } else {
                            // If all retries failed, try using rmSync with force option
                            console.log('All retries failed, trying rmSync with force...');
                            try {
                                fs.rmSync(filePath, { force: true, maxRetries: 3, retryDelay: 1000 });
                                deleted = true;
                                console.log(`Successfully deleted backup file using rmSync: ${filename}`);
                            } catch (rmErr) {
                                console.error('rmSync also failed:', rmErr);
                                throw new Error(`File is locked and cannot be deleted. Please close any programs that might be using this file and try again. (${unlinkErr.code})`);
                            }
                        }
                    } else {
                        // Different error, throw immediately
                        throw unlinkErr;
                    }
                }
            }
        }
        
        res.json({ success: true, message: 'Backup deleted successfully' });
        
    } catch (err) {
        console.error('Delete backup error', err);
        res.status(500).json({ error: 'Failed to delete backup: ' + err.message });
    }
});

app.post('/servers/:id/backups/validate', requireAuth, requirePermission('backups'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const { backupId } = req.body;
        if (!backupId) return res.status(400).json({ error: 'Backup ID required' });
        
        const backup = await dbGet('SELECT * FROM backups WHERE id = ? AND server_id = ?', [backupId, serverId]);
        if (!backup) return res.status(404).json({ error: 'Backup not found' });
        
        const backupFile = path.join(resolveServerPath(serverId), 'backups', backup.file);
        
        // Check if file exists
        if (!fs.existsSync(backupFile)) {
            return res.json({ 
                valid: false, 
                error: 'Backup file not found on disk',
                canRestore: false
            });
        }
        
        // Check file size
        const stats = fs.statSync(backupFile);
        if (stats.size === 0) {
            return res.json({ 
                valid: false, 
                error: 'Backup file is empty',
                canRestore: false
            });
        }
        
        // Try to open and validate the zip file
        try {
            const directory = await unzipper.Open.file(backupFile);
            if (!directory || !directory.files || directory.files.length === 0) {
                return res.json({ 
                    valid: false, 
                    error: 'Backup file contains no files',
                    canRestore: false
                });
            }
            
            const fileCount = directory.files.length;
            
            // Force close the directory handle by setting to null and triggering GC
            directory.close && directory.close();
            
            // Small delay to ensure file handle is released
            await new Promise(resolve => setTimeout(resolve, 100));
            
            return res.json({ 
                valid: true, 
                fileCount: fileCount,
                size: backup.size,
                canRestore: true,
                message: `Backup is valid and contains ${fileCount} files`
            });
            
        } catch (zipErr) {
            console.error('Zip validation error:', zipErr);
            return res.json({ 
                valid: false, 
                error: `Backup file is corrupted: ${zipErr.message}`,
                canRestore: false
            });
        }
        
    } catch (err) {
        console.error('Validate backup error:', err);
        res.status(500).json({ error: 'Failed to validate backup: ' + err.message });
    }
});
app.post('/servers/:id/backups/restore', requireAuth, requirePermission('backups'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const { filename } = req.body;
        if (!filename) return res.status(400).json({ error: 'Backup filename required' });
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        
        // Get the node for this server
        const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
        if (!node) return res.status(404).json({ error: 'Remote node not found' });
        
        console.log(`Queueing backup restore for server ${serverId}: ${filename} on node ${server.node_id}...`);
        
        // Queue restore command to remote node
        try {
            const commandId = await queueNodeAction(server.node_id, serverId, 'restore-backup', {
                filename: filename
            });
            
            console.log(`✅ Queued restore-backup command (ID: ${commandId}) for server ${serverId}`);
            
            res.json({ 
                success: true, 
                message: 'Backup restore queued. The server will be stopped and restored. Please wait and then manually start the server.',
                commandId: commandId
            });
        } catch (queueErr) {
            console.error(`Failed to queue restore command:`, queueErr);
            return res.status(500).json({ 
                error: 'Failed to queue backup restore on remote node: ' + queueErr.message
            });
        }
        
    } catch (err) {
        console.error('Restore backup error:', err);
        res.status(500).json({ 
            error: 'Failed to restore backup: ' + err.message,
            details: err.code || 'Unknown error'
        });
    }
});
// ================================================
// PLUGINS ROUTES
// ================================================
app.get('/servers/:id/plugins/marketplace', requireAuth, requirePermission('plugins'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).send('Access denied');
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        const query = req.query.q || '';
        const page = parseInt(req.query.page) || 1;
        const provider = req.query.provider || 'all';
        const limit = 16;
        const { plugins, totalHits } = await searchPlugins(query, page, limit, provider);
        res.render('servers/plugins_marketplace', await getTemplateVars(req, server, {
            serverId,
            plugins,
            query,
            page,
            provider,
            hasMore: page * limit < totalHits,
            success: req.query.success,
            currentPage: 'plugins',
            activePage: 'plugins',
            error: req.query.error,
            title: `${server.name} - Plugin Marketplace`
        }));
    } catch (err) {
        console.error('Marketplace error', err);
        res.status(500).send('Error loading marketplace');
    }
});

// API endpoint to get plugin versions
app.get('/servers/:id/plugins/marketplace/versions', requireAuth, requirePermission('plugins'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const { source, projectId, resourceId } = req.query;
        let versions = [];
        
        if (source === 'modrinth' && projectId) {
            versions = await getModrinthVersions(projectId);
        } else if (source === 'spiget' && resourceId) {
            versions = await getSpigetVersions(resourceId);
        } else if (source === 'hangar' && projectId) {
            versions = await getHangarVersions(projectId);
        } else if (source === 'bukkit' && projectId) {
            versions = await getBukkitVersions(projectId);
        }
        
        res.json({ versions });
    } catch (err) {
        console.error('Versions fetch error:', err);
        res.status(500).json({ error: 'Failed to fetch versions' });
    }
});
app.post('/servers/:id/plugins/marketplace/install', requireAuth, requirePermission('plugins_install'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        
        const { pluginName, source, projectId, resourceId, versionId, fileId } = req.body;
        
        if (!pluginName || !source) {
            return res.status(400).json({ error: 'Missing plugin information' });
        }
        

        if (server.node_id) {
            let downloadInfo = null;
            if (source === 'modrinth' && projectId) downloadInfo = await getModrinthDownloadUrl(projectId, versionId);
            else if (source === 'spiget' && resourceId) downloadInfo = await getSpigetDownloadUrl(resourceId, versionId);
            else if (source === 'hangar' && projectId) downloadInfo = await getHangarDownloadUrl(projectId, versionId);
            else if (source === 'bukkit' && projectId) downloadInfo = await getBukkitDownloadUrl(projectId, fileId);
            if (!downloadInfo?.url) return res.status(400).json({ error: 'Could not resolve plugin download URL' });
            await queueNodeAction(server.node_id, serverId, 'plugin-install', {
                pluginName,
                url: downloadInfo.url,
                filename: downloadInfo.filename || `${sanitize(pluginName)}.jar`,
                version: downloadInfo.version || versionId || 'latest'
            });
            return res.json({ success: true, message: `${pluginName} installation queued on remote node!`, queued: true });
        }

        console.log(`Installing plugin: ${pluginName} from ${source}${versionId ? ` (version: ${versionId})` : ''}`);
        console.log(`Project ID: ${projectId}, Resource ID: ${resourceId}`);
        
        // Get download URL based on source
        let downloadInfo = null;
        
        try {
            if (source === 'modrinth' && projectId) {
                downloadInfo = await getModrinthDownloadUrl(projectId, versionId);
            } else if (source === 'spiget' && resourceId) {
                downloadInfo = await getSpigetDownloadUrl(resourceId, versionId);
            } else if (source === 'hangar' && projectId) {
                downloadInfo = await getHangarDownloadUrl(projectId, versionId);
            } else if (source === 'bukkit' && projectId) {
                downloadInfo = await getBukkitDownloadUrl(projectId, fileId);
            } else {
                return res.status(400).json({ error: 'Invalid source or missing identifiers' });
            }
        } catch (err) {
            console.error('Error fetching download URL:', err);
            return res.status(500).json({ error: `Failed to get download URL: ${err.message}` });
        }
        
        if (!downloadInfo) {
            return res.status(400).json({ error: 'Could not retrieve download information from provider' });
        }
        
        if (!downloadInfo.url) {
            return res.status(400).json({ error: 'Download URL not available for this plugin' });
        }
        
        console.log(`Download URL: ${downloadInfo.url}`);
        console.log(`Filename: ${downloadInfo.filename}`);
        
        // Prepare destination path
        const pluginsDir = resolveServerPath(serverId, 'plugins');
        if (!fs.existsSync(pluginsDir)) {
            fs.mkdirSync(pluginsDir, { recursive: true });
        }
        
        const sanitizedName = downloadInfo.filename || (sanitize(pluginName) + '.jar');
        const destPath = path.join(pluginsDir, sanitizedName);
        
        // Check if plugin already exists
        if (fs.existsSync(destPath)) {
            return res.status(400).json({ error: 'Plugin already installed. Delete the old version first.' });
        }
        
        // Download the plugin
        try {
            await downloadPluginJar(downloadInfo.url, destPath);
        } catch (downloadErr) {
            console.error('Download failed:', downloadErr);
            return res.status(500).json({ error: `Download failed: ${downloadErr.message}` });
        }
        
        console.log(`Plugin installed successfully: ${sanitizedName}`);
        return res.json({ 
            success: true, 
            message: `${pluginName} installed successfully!`,
            filename: sanitizedName,
            version: downloadInfo.version
        });
        
    } catch (err) {
        console.error('Plugin install error:', err);
        return res.status(500).json({ error: err.message || 'Failed to install plugin' });
    }
});
app.post('/servers/:id/plugins/delete', requireAuth, requirePermission('plugins_delete'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });
        
        const { filename } = req.body;
        if (!filename) {
            return res.status(400).json({ error: 'Invalid plugin filename' });
        }
        

        if (server.node_id) {
            console.log(`📤 Queuing plugin delete command for remote node ${server.node_id}, server ${serverId}`);
            await queueNodeAction(server.node_id, serverId, 'plugin-delete', {
                filename: sanitize(filename)
            });
            return res.json({ 
                success: true, 
                message: 'Plugin deletion queued on remote node!',
                queued: true
            });
        }

        // Check if server is running
        const running = await isServerRunning(serverId);
        if (running) {
            return res.status(400).json({ 
                error: 'Cannot delete plugins while server is running. Please stop the server first.' 
            });
        }
        
        const sanitizedName = sanitize(filename);
        const pluginsDir = resolveServerPath(serverId, 'plugins');
        const pluginPath = path.join(pluginsDir, sanitizedName);
        
        if (!fs.existsSync(pluginPath)) {
            return res.status(404).json({ error: 'Plugin not found' });
        }
        
        // Try to delete with retry logic for Windows file locking
        let attempts = 0;
        const maxAttempts = 3;
        let lastError = null;
        
        while (attempts < maxAttempts) {
            try {
                // Check if it's a directory or file
                const stats = fs.statSync(pluginPath);
                if (stats.isDirectory()) {
                    fs.rmSync(pluginPath, { recursive: true, force: true });
                } else {
                    fs.unlinkSync(pluginPath);
                }
                
                return res.json({ success: true, message: 'Plugin deleted successfully' });
            } catch (err) {
                lastError = err;
                
                // If EBUSY error (file locked), wait and retry
                if (err.code === 'EBUSY' || err.code === 'EPERM') {
                    attempts++;
                    if (attempts < maxAttempts) {
                        await new Promise(resolve => setTimeout(resolve, 500)); // Wait 500ms
                        continue;
                    }
                } else {
                    // Other errors, don't retry
                    throw err;
                }
            }
        }
        
        // If we get here, all retries failed
        if (lastError && (lastError.code === 'EBUSY' || lastError.code === 'EPERM')) {
            return res.status(400).json({ 
                error: 'Plugin files are locked. The server may still be running or shutting down. Please wait a moment and try again.' 
            });
        }
        
        throw lastError;
        
    } catch (err) {
        console.error('Plugin delete error:', err.message);
        return res.status(500).json({ 
            error: err.code === 'EBUSY' || err.code === 'EPERM' 
                ? 'Plugin files are locked. Please stop the server and try again.' 
                : 'Failed to delete plugin: ' + err.message 
        });
    }
});
app.post('/servers/:id/plugins/upload', requireAuth, upload.single('plugin'), requirePermission('plugins_install'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) {
            return res.status(403).json({ error: 'Access denied' });
        }
        
        if (!req.file) {
            return res.status(400).json({ error: 'No file uploaded' });
        }
        
        // Validate file is a JAR
        if (!req.file.originalname.endsWith('.jar')) {
            // Delete uploaded file
            fs.unlinkSync(req.file.path);
            return res.status(400).json({ error: 'Only .jar files are allowed' });
        }
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            fs.unlinkSync(req.file.path);
            return res.status(404).json({ error: 'Server not found' });
        }
        

        if (server.node_id) {
            console.log(`📤 Queuing plugin upload command for remote node ${server.node_id}, server ${serverId}`);
            
            // Read the file and pass as base64 or path
            const fileBuffer = fs.readFileSync(req.file.path);
            const fileBase64 = fileBuffer.toString('base64');
            
            // Clean up temp file
            fs.unlinkSync(req.file.path);
            
            await queueNodeAction(server.node_id, serverId, 'plugin-upload', {
                filename: sanitize(req.file.originalname),
                fileData: fileBase64
            });
            return res.json({ 
                success: true, 
                message: 'Plugin upload queued on remote node!',
                filename: sanitize(req.file.originalname),
                queued: true
            });
        }

        const pluginsDir = resolveServerPath(serverId, 'plugins');
        if (!fs.existsSync(pluginsDir)) {
            fs.mkdirSync(pluginsDir, { recursive: true });
        }
        
        const sanitizedName = sanitize(req.file.originalname);
        const destPath = path.join(pluginsDir, sanitizedName);
        
        // Check if plugin already exists
        if (fs.existsSync(destPath)) {
            fs.unlinkSync(req.file.path);
            return res.status(400).json({ error: 'Plugin already exists. Delete the old version first.' });
        }
        
        // Move file to plugins directory
        fs.renameSync(req.file.path, destPath);
        
        console.log(`Plugin uploaded: ${sanitizedName}`);
        return res.json({ 
            success: true, 
            message: 'Plugin uploaded successfully',
            filename: sanitizedName
        });
        
    } catch (err) {
        console.error('Plugin upload error:', err);
        
        // Clean up uploaded file on error
        if (req.file && fs.existsSync(req.file.path)) {
            try {
                fs.unlinkSync(req.file.path);
            } catch (cleanupErr) {
                console.error('Cleanup error:', cleanupErr);
            }
        }
        
        return res.status(500).json({ error: err.message || 'Failed to upload plugin' });
    }
});

app.get('/servers/:id/plugins', requireAuth, requirePermission('plugins'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) {
            return res.status(403).send('Access denied');
        }
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).send('Server not found');
        

        if (server.node_id) {
            try {
                const remote = await remoteNodeRequest(server.node_id, 'GET', `/servers/${serverId}/plugins`, { timeoutMs: 20000 });
                return res.render('servers/plugins', await getTemplateVars(req, server, {
                    plugins: Array.isArray(remote?.plugins) ? remote.plugins : [],
                    success: req.query.success,
                    error: req.query.error,
                    activePage: 'plugins',
                    currentPage: 'server',
                    remoteNode: true,
                    title: `${server.name} - Plugins`
                }));
            } catch (remoteErr) {
                console.error('Remote plugins page error:', remoteErr.message);
                return res.status(502).send(`Remote node plugin manager error: ${remoteErr.message}`);
            }
        }

        const pluginsDir = resolveServerPath(serverId, 'plugins');
        let plugins = [];
        
        if (fs.existsSync(pluginsDir)) {
            const files = fs.readdirSync(pluginsDir);
            
            for (const file of files) {
                const fullPath = path.join(pluginsDir, file);
                const stat = fs.statSync(fullPath);
                
                // Only include .jar files, skip directories
                if (!stat.isDirectory() && file.endsWith('.jar')) {
                    const pluginInfo = await extractPluginInfo(fullPath, file);
                    plugins.push({
                        name: pluginInfo.name || file.replace('.jar', ''),
                        filename: file,
                        version: pluginInfo.version || 'Unknown',
                        description: pluginInfo.description || null,
                        author: pluginInfo.author || null,
                        website: pluginInfo.website || null,
                        size: stat.size,
                        formattedSize: formatFileSize(stat.size),
                        enabled: !file.endsWith('.disabled.jar'),
                        isDirectory: false
                    });
                }
            }
            
            // Sort plugins alphabetically
            plugins.sort((a, b) => a.name.localeCompare(b.name));
        }
        
        res.render('servers/plugins', await getTemplateVars(req, server, {
            plugins,
            success: req.query.success,
            error: req.query.error,
            activePage: 'plugins',
            currentPage: 'server',
            title: `${server.name} - Plugins`
        }));
    } catch (err) {
        console.error('Plugins page error:', err);
        res.status(500).send('Error loading plugins');
    }
});

// Helper function to extract plugin info from JAR file
async function extractPluginInfo(jarPath, filename) {
    try {
        const AdmZip = require('adm-zip');
        const zip = new AdmZip(jarPath);
        
        // Try to find plugin.yml (Bukkit/Spigot) or paper-plugin.yml (Paper)
        let pluginYml = zip.getEntry('plugin.yml');
        if (!pluginYml) {
            pluginYml = zip.getEntry('paper-plugin.yml');
        }
        if (!pluginYml) {
            pluginYml = zip.getEntry('bungee.yml'); // BungeeCord plugins
        }
        
        if (pluginYml) {
            const content = zip.readAsText(pluginYml);
            const yaml = require('js-yaml');
            const data = yaml.load(content);
            
            return {
                name: data.name || filename.replace('.jar', ''),
                version: data.version || 'Unknown',
                description: data.description || null,
                author: data.author || (data.authors && data.authors[0]) || null,
                website: data.website || null,
                main: data.main || null
            };
        }
        
        // If no plugin.yml, try to extract from manifest
        const manifest = zip.getEntry('META-INF/MANIFEST.MF');
        if (manifest) {
            const content = zip.readAsText(manifest);
            const versionMatch = content.match(/Implementation-Version:\s*(.+)/i);
            if (versionMatch) {
                return {
                    name: filename.replace('.jar', ''),
                    version: versionMatch[1].trim(),
                    description: null,
                    author: null,
                    website: null
                };
            }
        }
        
        return {
            name: filename.replace('.jar', ''),
            version: 'Unknown',
            description: null,
            author: null,
            website: null
        };
    } catch (err) {
        console.error(`Error extracting plugin info from ${filename}:`, err.message);
        return {
            name: filename.replace('.jar', ''),
            version: 'Unknown',
            description: null,
            author: null,
            website: null
        };
    }
}
// ================================================
// PLAYERS ROUTES
// ================================================
app.get('/servers/:id/players', requireAuth, requirePermission('players'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).send('Access denied');
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).send('Server not found');
        let ops, whitelist, bannedPlayers, bannedIps, online, whitelistEnabled = false, maxPlayers = 20;

        if (server.node_id) {
            try {
                const remote = await remoteNodeRequest(server.node_id, 'GET', `/servers/${serverId}/players`, { timeoutMs: 15000 });
                ops = Array.isArray(remote?.ops) ? remote.ops : [];
                whitelist = Array.isArray(remote?.whitelist) ? remote.whitelist : [];
                bannedPlayers = Array.isArray(remote?.banned) ? remote.banned : [];
                bannedIps = Array.isArray(remote?.bannedIps) ? remote.bannedIps : [];
                online = Array.isArray(remote?.online) ? remote.online : [];
                whitelistEnabled = Boolean(remote?.whitelistEnabled);
            } catch (err) {
                console.warn(`Failed to fetch player data from remote node: ${err.message}`);
                ops = [];
                whitelist = [];
                bannedPlayers = [];
                bannedIps = [];
                online = [];
            }
            
            // Fetch maxPlayers from stats endpoint (more reliable)
            try {
                const statsRemote = await remoteNodeRequest(server.node_id, 'GET', `/servers/${serverId}/stats`, { timeoutMs: 5000 });
                if (statsRemote?.maxPlayers) {
                    maxPlayers = Number(statsRemote.maxPlayers) || 20;
                    console.log(`✅ Fetched maxPlayers=${maxPlayers} from stats endpoint`);
                }
            } catch (err) {
                console.warn(`Could not fetch maxPlayers from stats: ${err.message}, using default 20`);
            }
        } else {
            // Remote-only architecture: no local fallback for player files
            ops = [];
            whitelist = [];
            bannedPlayers = [];
            bannedIps = [];
            online = [];
        }
        
        console.log(`📄 [Players] Rendering page with maxPlayers=${maxPlayers} (type: ${typeof maxPlayers}) for serverId=${serverId}`);
        res.render('servers/players', await getTemplateVars(req, server, {
            ops: ops || [],
            whitelist: whitelist || [],
            banned: bannedPlayers || [],
            bannedPlayers: bannedPlayers || [],
            bannedIps: bannedIps || [],
            whitelistEnabled,
            maxPlayers: Number(maxPlayers) || 20,  // Ensure it's a number
            online: online || [],
            currentPage: 'players',
            success: req.query.success,
            serverId: server.id,
            activePage: 'players',
            error: req.query.error,
            query: req.query,
            title: `${server.name} - Players`
        }));
    } catch (err) {
        console.error(`Players page error for server ${req.params.id}:`, err);
        res.status(500).send('Server error');
    }
});
app.get('/servers/:id/players/online', requireAuth, requirePermission('players'), async (req, res) => {
    const serverId = req.params.id;
    if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
    res.json(getOnlinePlayers(serverId));
});
app.post('/servers/:id/players/online/refresh', requireAuth, requirePermission('players'), async (req, res) => {
    const serverId = req.params.id;
    if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
    
    const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
    let success;
    if (server?.node_id) {
        try {
            const remote = await remoteNodeRequest(server.node_id, 'GET', `/servers/${serverId}/players`, { timeoutMs: 10000 });
            const players = Array.isArray(remote?.online) ? remote.online : [];
            global.remoteServerStats = global.remoteServerStats || {};
            global.remoteServerStats[serverId] = { ...(global.remoteServerStats[serverId] || {}), playerList: players, players: players.length };
            io.to(`server:${serverId}`).emit('playersUpdated', { onlinePlayers: players, count: players.length });
            success = true;
        } catch (e) {
            success = false;
        }
    } else {
        // Local node: query online players by sending /list command.
        success = await queryOnlinePlayers(serverId);
    }
    
    if (success) {
        res.sendStatus(200);
    } else {
        res.status(400).json({ error: 'Server is offline' });
    }
});
app.post('/servers/:id/players/whitelist/toggle', requireAuth, requirePermission('players'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { enabled } = req.body;
        const isEnabled = enabled === 'true' || enabled === true;
        
        // Remote-only architecture: send command to remote node
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (server?.node_id) {
            // Queue the operation to remote node
            try {
                await queueNodeAction(server.node_id, serverId, 'player-action', { 
                    action: 'whitelist-toggle',
                    enabled: isEnabled
                });
                return res.json({ success: true, message: 'Whitelist ' + (isEnabled ? 'enabled' : 'disabled'), queued: true });
            } catch (err) {
                console.error(`Whitelist toggle error for server ${serverId}:`, err);
                return res.status(500).json({ error: 'Failed to toggle whitelist: ' + err.message });
            }
        }
        
        return res.status(400).json({ error: 'Server must be assigned to a remote node' });
    } catch (err) {
        console.error(`Toggle whitelist error for server ${req.params.id}`, err);
        return res.status(500).json({ error: 'Failed to toggle whitelist: ' + err.message });
    }
});
app.post('/servers/:id/players/op/add', requireAuth, requirePermission('players'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { name, level = 4 } = req.body;
        if (!name) return res.status(400).json({ error: 'Name required' });
        
        console.log(`Adding OP: ${name} to server ${serverId}`);
        
        // Always try to send command first (works for both local and remote)
        const commandSent = await sendCommand(serverId, `op ${name}`);
        
        if (commandSent?.success) {
            return res.json({ success: true, message: 'Operator added successfully' });
        }
        
        // If command failed, try updating file directly (for local servers only)
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (server?.node_id) {
            // Remote server - queue the operation
            try {
                await queueNodeAction(server.node_id, serverId, 'op-add', { name: name, level: parseInt(level) || 4 });
                return res.json({ success: true, message: 'Operator add queued successfully' });
            } catch (queueErr) {
                console.error('Queue OP error:', queueErr);
                return res.status(500).json({ error: 'Failed to queue operator addition on remote node' });
            }
        }
        
        // Local server - update file
        let ops = readPlayerFile(serverId, 'ops.json');
        if (ops.find(o => o.name.toLowerCase() === name.toLowerCase())) {
            return res.status(400).json({ error: 'Player already OP' });
        }
        
        // Try to get UUID
        let uuid = null;
        try {
            uuid = await getUUID(name);
        } catch (err) {
            console.log('Could not fetch UUID, using placeholder');
            uuid = '00000000-0000-0000-0000-000000000000';
        }
        
        ops.push({ 
            uuid: uuid, 
            name: name, 
            level: parseInt(level) || 4, 
            bypassesPlayerLimit: false 
        });
        writePlayerFile(serverId, 'ops.json', ops);
        
        return res.json({ success: true, message: 'Operator added successfully' });
    } catch (err) {
        console.error(`Add OP error for server ${serverId}:`, err);
        return res.status(500).json({ error: 'Failed to add OP: ' + err.message });
    }
});

app.post('/servers/:id/players/op/remove', requireAuth, requirePermission('players'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { name } = req.body;
        if (!name) return res.status(400).json({ error: 'Name required' });
        
        console.log(`Removing OP: ${name} from server ${serverId}`);
        
        // Try to send command to running server
        const commandSent = await sendCommand(serverId, `deop ${name}`);
        
        if (!commandSent?.success) {
            // Server not running or command failed, update file directly
            let ops = readPlayerFile(serverId, 'ops.json');
            ops = ops.filter(o => o.name.toLowerCase() !== name.toLowerCase());
            writePlayerFile(serverId, 'ops.json', ops);
        }
        
        return res.json({ success: true, message: 'Operator removed successfully' });
    } catch (err) {
        console.error(`Remove OP error for server ${serverId}:`, err);
        return res.status(500).json({ error: 'Failed to remove OP' });
    }
});

app.post('/servers/:id/players/whitelist/add', requireAuth, requirePermission('players'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { name } = req.body;
        if (!name) return res.status(400).json({ error: 'Name required' });
        
        console.log(`Adding to whitelist: ${name} on server ${serverId}`);
        
        // Always try to send command first
        const commandSent = await sendCommand(serverId, `whitelist add ${name}`);
        
        if (commandSent?.success) {
            return res.json({ success: true, message: 'Player added to whitelist' });
        }
        
        // If command failed, try for remote server
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (server?.node_id) {
            try {
                await queueNodeAction(server.node_id, serverId, 'whitelist-add', { name: name });
                return res.json({ success: true, message: 'Whitelist add queued successfully' });
            } catch (queueErr) {
                console.error('Queue whitelist error:', queueErr);
                return res.status(500).json({ error: 'Failed to queue whitelist addition on remote node' });
            }
        }
        
        // Local server - update file
        let whitelist = readPlayerFile(serverId, 'whitelist.json');
        if (whitelist.find(w => w.name.toLowerCase() === name.toLowerCase())) {
            return res.status(400).json({ error: 'Player already whitelisted' });
        }
        
        // Try to get UUID (optional)
        let uuid = null;
        try {
            uuid = await getUUID(name);
        } catch (err) {
            console.log('Could not fetch UUID, using placeholder');
            uuid = '00000000-0000-0000-0000-000000000000';
        }
        
        whitelist.push({ uuid: uuid, name: name });
        writePlayerFile(serverId, 'whitelist.json', whitelist);
        
        return res.json({ success: true, message: 'Player added to whitelist' });
    } catch (err) {
        console.error(`Add whitelist error for server ${serverId}:`, err);
        return res.status(500).json({ error: 'Failed to add to whitelist: ' + err.message });
    }
});

app.post('/servers/:id/players/whitelist/remove', requireAuth, requirePermission('players'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { name } = req.body;
        if (!name) return res.status(400).json({ error: 'Name required' });
        
        console.log(`Removing from whitelist: ${name} on server ${serverId}`);
        
        // Try to send command to running server
        const commandSent = await sendCommand(serverId, `whitelist remove ${name}`);
        
        if (!commandSent?.success) {
            // Server not running or command failed, update file directly
            let whitelist = readPlayerFile(serverId, 'whitelist.json');
            whitelist = whitelist.filter(w => w.name.toLowerCase() !== name.toLowerCase());
            writePlayerFile(serverId, 'whitelist.json', whitelist);
        }
        
        return res.json({ success: true, message: 'Player removed from whitelist' });
    } catch (err) {
        console.error(`Remove whitelist error for server ${serverId}:`, err);
        return res.status(500).json({ error: 'Failed to remove from whitelist' });
    }
});

app.post('/servers/:id/players/ban/add', requireAuth, requirePermission('players_ban'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { name, reason = 'Banned by an operator' } = req.body;
        if (!name) return res.status(400).json({ error: 'Name required' });
        
        console.log(`Banning player: ${name} on server ${serverId}`);
        
        // Always try to send command first
        const commandSent = await sendCommand(serverId, `ban ${name} ${reason}`);
        
        if (commandSent?.success) {
            return res.json({ success: true, message: 'Player banned successfully' });
        }
        
        // If command failed, try for remote server
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (server?.node_id) {
            try {
                await queueNodeAction(server.node_id, serverId, 'ban-add', { name: name, reason: reason });
                return res.json({ success: true, message: 'Ban queued successfully' });
            } catch (queueErr) {
                console.error('Queue ban error:', queueErr);
                return res.status(500).json({ error: 'Failed to queue ban on remote node' });
            }
        }
        
        // Local server - update file
        let banned = readPlayerFile(serverId, 'banned-players.json');
        if (banned.find(b => b.name.toLowerCase() === name.toLowerCase())) {
            return res.status(400).json({ error: 'Player already banned' });
        }
        
        // Try to get UUID (optional)
        let uuid = null;
        try {
            uuid = await getUUID(name);
        } catch (err) {
            console.log('Could not fetch UUID, using placeholder');
            uuid = '00000000-0000-0000-0000-000000000000';
        }
        
        banned.push({
            uuid: uuid,
            name: name,
            created: new Date().toISOString(),
            source: 'Panel',
            expires: 'forever',
            reason: reason
        });
        writePlayerFile(serverId, 'banned-players.json', banned);
        
        return res.json({ success: true, message: 'Player banned successfully' });
    } catch (err) {
        console.error(`Ban player error for server ${serverId}:`, err);
        return res.status(500).json({ error: 'Failed to ban player: ' + err.message });
    }
});

app.post('/servers/:id/players/ban/remove', requireAuth, requirePermission('players_ban'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { name } = req.body;
        if (!name) return res.status(400).json({ error: 'Name required' });
        
        console.log(`Unbanning player: ${name} on server ${serverId}`);
        
        // Try to send command to running server
        const commandSent = await sendCommand(serverId, `pardon ${name}`);
        
        if (!commandSent?.success) {
            // Server not running or command failed, update file directly
            let banned = readPlayerFile(serverId, 'banned-players.json');
            banned = banned.filter(b => b.name.toLowerCase() !== name.toLowerCase());
            writePlayerFile(serverId, 'banned-players.json', banned);
        }
        
        return res.json({ success: true, message: 'Player unbanned successfully' });
    } catch (err) {
        console.error(`Unban player error for server ${serverId}:`, err);
        return res.status(500).json({ error: 'Failed to unban player' });
    }
});

app.post('/servers/:id/players/ban-ip/add', requireAuth, requirePermission('players_ban'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { ip, reason = 'Banned by an operator' } = req.body;
        if (!ip) return res.status(400).json({ error: 'IP required' });
        if (!/^((\d{1,3}\.){3}\d{1,3})$/.test(ip)) {
            return res.status(400).json({ error: 'Invalid IP address' });
        }
        
        console.log(`Banning IP: ${ip} on server ${serverId}`);
        
        // Try to send command to running server
        const commandSent = await sendCommand(serverId, `ban-ip ${ip} ${reason}`);
        
        if (!commandSent?.success) {
            // Server not running or command failed, update file directly
            let bannedIps = readPlayerFile(serverId, 'banned-ips.json');
            if (bannedIps.find(b => b.ip === ip)) {
                return res.status(400).json({ error: 'IP already banned' });
            }
            
            bannedIps.push({
                ip: ip,
                created: new Date().toISOString(),
                source: 'Panel',
                expires: 'forever',
                reason: reason
            });
            writePlayerFile(serverId, 'banned-ips.json', bannedIps);
        }
        
        return res.json({ success: true, message: 'IP banned successfully' });
    } catch (err) {
        console.error(`Ban IP error for server ${serverId}:`, err);
        return res.status(500).json({ error: 'Failed to ban IP' });
    }
});

app.post('/servers/:id/players/ban-ip/remove', requireAuth, requirePermission('players_ban'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { ip } = req.body;
        if (!ip) return res.status(400).json({ error: 'IP required' });
        
        console.log(`Unbanning IP: ${ip} on server ${serverId}`);
        
        // Try to send command to running server
        const commandSent = await sendCommand(serverId, `pardon-ip ${ip}`);
        
        if (!commandSent?.success) {
            // Server not running or command failed, update file directly
            let bannedIps = readPlayerFile(serverId, 'banned-ips.json');
            bannedIps = bannedIps.filter(b => b.ip !== ip);
            writePlayerFile(serverId, 'banned-ips.json', bannedIps);
        }
        
        return res.json({ success: true, message: 'IP unbanned successfully' });
    } catch (err) {
        console.error(`Unban IP error for server ${serverId}:`, err);
        return res.status(500).json({ error: 'Failed to unban IP' });
    }
});

// Kick player
app.post('/servers/:id/players/kick', requireAuth, requirePermission('players_kick'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        const { name, reason = 'Kicked by an operator' } = req.body;
        if (!name) return res.status(400).json({ error: 'Name required' });
        
        console.log(`Kicking player: ${name} from server ${serverId}`);
        
        // Send kick command to running server
        const commandSent = await sendCommand(serverId, `kick ${name} ${reason}`);
        
        if (!commandSent?.success) {
            return res.status(400).json({ error: 'Server is not running or player is not online' });
        }
        
        return res.json({ success: true, message: 'Player kicked successfully' });
    } catch (err) {
        console.error(`Kick player error for server ${serverId}:`, err);
        return res.status(500).json({ error: 'Failed to kick player' });
    }
});

// Get all players (combined list)
app.get('/servers/:id/players/all', requireAuth, requirePermission('players'), async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (server?.node_id) {
            const remote = await remoteNodeRequest(server.node_id, 'GET', `/servers/${serverId}/players`, { timeoutMs: 15000 });
            return res.json({
                success: true,
                online: Array.isArray(remote?.online) ? remote.online : [],
                ops: Array.isArray(remote?.ops) ? remote.ops : [],
                whitelist: Array.isArray(remote?.whitelist) ? remote.whitelist : [],
                banned: Array.isArray(remote?.banned) ? remote.banned : [],
                bannedIps: Array.isArray(remote?.bannedIps) ? remote.bannedIps : []
            });
        }

        const ops = readPlayerFile(serverId, 'ops.json') || [];
        const whitelist = readPlayerFile(serverId, 'whitelist.json') || [];
        const banned = readPlayerFile(serverId, 'banned-players.json') || [];
        const online = getOnlinePlayers(serverId) || [];
        
        return res.json({
            success: true,
            online,
            ops,
            whitelist,
            banned
        });
    } catch (err) {
        console.error('Get all players error:', err);
        return res.status(500).json({ error: 'Failed to get players' });
    }
});


// Get lifetime players from usercache.json
// Get lifetime players from the remote node's playerdata directory.
app.get('/servers/:id/players/lifetime', requireAuth, requirePermission('players'), async (req, res) => {
  try {
    const serverId = req.params.id;
    if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
    const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
    if (!server) return res.status(404).json({ error: 'Server not found' });

    if (server.node_id) {
      const remote = await remoteNodeRequest(server.node_id, 'GET', `/servers/${encodeURIComponent(serverId)}/players/lifetime`, { timeoutMs: 30000 });
      return res.json({ success: true, players: Array.isArray(remote.players) ? remote.players : [], totalPlayers: Number(remote.totalPlayers) || 0 });
    }

    // Legacy local fallback.
    const playerDataDir = path.join(__dirname, '..', 'daemon', 'servers', String(serverId), 'world', 'playerdata');
    if (!fs.existsSync(playerDataDir)) return res.json({ success: true, players: [], totalPlayers: 0 });
    const cache = new Map();
    try {
      const rows = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'daemon', 'servers', String(serverId), 'usercache.json'), 'utf8'));
      if (Array.isArray(rows)) rows.forEach(row => { if (row?.uuid && row?.name) cache.set(String(row.uuid).replace(/-/g, '').toLowerCase(), String(row.name)); });
    } catch {}
    const players = fs.readdirSync(playerDataDir).filter(f => /^[a-f0-9-]{36}\.dat$/i.test(f)).map(file => {
      const uuid = file.slice(0, -4); const stat = fs.statSync(path.join(playerDataDir, file));
      return { uuid, name: cache.get(uuid.replace(/-/g, '').toLowerCase()) || uuid, lastSeen: stat.mtime.toISOString(), fileSize: stat.size, fileSizeBytes: stat.size };
    }).sort((a,b) => Date.parse(b.lastSeen) - Date.parse(a.lastSeen));
    return res.json({ success: true, players, totalPlayers: players.length });
  } catch (err) {
    console.error('Get lifetime players error:', err);
    return res.status(500).json({ success: false, error: 'Failed to get lifetime players', details: err.message });
  }
});

// Get detailed player data from .dat file
app.get('/servers/:id/players/data/:uuid', requireAuth, requirePermission('players'), async (req, res) => {
    try {
        const serverId = req.params.id;
        const uuid = req.params.uuid;
        
        // Validate UUID format
        if (!/^[a-f0-9-]{36}$/i.test(uuid)) {
            return res.status(400).json({ error: 'Invalid UUID format' });
        }
        
        if (!await isAuthorized(req, serverId)) return res.status(403).json({ error: 'Access denied' });
        
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return res.status(404).json({ error: 'Server not found' });

        if (server.node_id) {
            const remote = await remoteNodeRequest(server.node_id, 'GET', `/servers/${encodeURIComponent(serverId)}/players/data/${encodeURIComponent(uuid)}`, { timeoutMs: 30000 });
            return res.json({ success: true, playerFound: remote.playerFound !== false, playerName: remote.playerName || uuid, data: remote.data, fileSize: remote.fileSize, lastModified: remote.lastModified });
        }

        // Read player data directly from .dat file (legacy local fallback)
        const playerDataDir = path.join(__dirname, '..', 'daemon', 'servers', String(serverId), 'world', 'playerdata');
        const playerDataFile = path.join(playerDataDir, `${uuid}.dat`);

        // Security: Verify file is within playerdata directory
        if (!playerDataFile.startsWith(playerDataDir)) {
            return res.status(400).json({ error: 'Invalid player data file path' });
        }

        if (!fs.existsSync(playerDataFile)) {
            return res.status(404).json({ error: 'Player data not found', playerFound: false });
        }

        try {
            // Parse NBT data
            const fileBuffer = fs.readFileSync(playerDataFile);
            let playerData = {};
            let playerName = 'Unknown';
            
            try {
                // prismarine-nbt automatically handles gzip-compressed .dat files
                const parsed = await nbtParse(fileBuffer);
                if (parsed && parsed.value) {
                    playerData = parsed.value;
                    
                    // Extract player name
                    if (playerData.name) {
                        playerName = getValue(playerData.name) || 'Unknown';
                    }
                }
            } catch (nbtErr) {
                console.error('NBT parsing error:', nbtErr.message);
                playerData = { error: 'Failed to parse NBT data', message: nbtErr.message };
            }

            return res.json({
                success: true,
                playerFound: true,
                playerName: String(playerName),
                data: playerData
            });
        } catch (err) {
            console.error(`Error reading player data file:`, err.message);
            return res.status(500).json({ error: 'Failed to read player data file', details: err.message });
        }
    } catch (err) {
        console.error('Get player data error:', err);
        return res.status(500).json({ error: 'Failed to get player data', details: err.message });
    }
    
    // Helper function to extract value from NBT tag
    function getValue(tag) {
        if (!tag) return null;
        if (typeof tag === 'string') return tag;
        if (tag.value !== undefined) return tag.value;
        return tag;
    };
});

// ================================================
// WORLDS ROUTES (FIXED: all paths now /servers/:id/, router removed, db fixed, no extra files, live ready)
// ================================================
app.get('/servers/:id/worlds', requireAuth, requirePermission('worlds'), async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).send('Access denied');
    try {
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      

      if (server.node_id) {
        try {
          const remote = await remoteNodeRequest(server.node_id, 'GET', `/servers/${serverId}/worlds`, { timeoutMs: 20000 });
          return res.render('servers/worlds', await getTemplateVars(req, server, {
            worlds: Array.isArray(remote?.worlds) ? remote.worlds : [],
            currentWorld: remote?.currentWorld || 'world',
            backups: Array.isArray(remote?.backups) ? remote.backups : [],
            serverId: server.id,
            activePage: 'worlds',
            currentPage: 'worlds',
            remoteNode: true,
            title: `${server.name} - Worlds`
          }));
        } catch (remoteErr) {
          return res.status(502).render('error', await getTemplateVars(req, server, {
            message: 'Remote node worlds manager is unavailable',
            error: remoteErr.message,
            status: 502,
            title: 'Remote Node Error'
          }));
        }
      }
      
      const serverDir = resolveServerPath(serverId);
      const files = fs.readdirSync(serverDir, { withFileTypes: true });
      const worlds = [];
      for (const file of files) {
        if (file.isDirectory()) {
          const worldDir = path.join(serverDir, file.name);
          // Check for level.dat OR other Minecraft world indicators
          const hasLevelDat = fs.existsSync(path.join(worldDir, 'level.dat'));
          const hasUidDat = fs.existsSync(path.join(worldDir, 'uid.dat'));
          const hasSessionLock = fs.existsSync(path.join(worldDir, 'session.lock'));
          const hasDataFolder = fs.existsSync(path.join(worldDir, 'data'));
          const hasPlayerData = fs.existsSync(path.join(worldDir, 'playerdata'));
          const hasDimensions = fs.existsSync(path.join(worldDir, 'DIM-1')) || fs.existsSync(path.join(worldDir, 'DIM1'));
          
          // Consider it a world if it has level.dat OR multiple world indicators
          const isWorld = hasLevelDat || (hasUidDat && (hasSessionLock || hasDataFolder || hasPlayerData || hasDimensions));
          
          if (isWorld) {
            const sizeBytes = getDirSize(worldDir);
            const sizeGB = sizeBytes / 1024 / 1024 / 1024;
            const sizeMB = sizeBytes / 1024 / 1024;
            const sizeKB = sizeBytes / 1024;
            
            let sizeStr;
            if (sizeGB >= 1) {
              sizeStr = sizeGB.toFixed(2) + ' GB';
            } else if (sizeMB >= 1) {
              sizeStr = sizeMB.toFixed(2) + ' MB';
            } else if (sizeKB >= 1) {
              sizeStr = sizeKB.toFixed(2) + ' KB';
            } else {
              sizeStr = sizeBytes + ' B';
            }
            
            worlds.push({ 
              name: file.name, 
              size: sizeStr,
              sizeBytes: sizeBytes
            });
          }
        }
      }
      
      let currentWorld = 'world';
      const propertiesPath = path.join(serverDir, 'server.properties');
      if (fs.existsSync(propertiesPath)) {
        const content = fs.readFileSync(propertiesPath, 'utf8');
        const match = content.match(/^level-name=(.*)$/m);
        if (match) currentWorld = match[1].trim();
      }
      
      const backupsDir = path.join(serverDir, 'backups');
      if (!fs.existsSync(backupsDir)) fs.mkdirSync(backupsDir, { recursive: true });
      const backups = fs.readdirSync(backupsDir)
        .filter(f => f.endsWith('.zip'))
        .map(f => ({
          name: f,
          size: (fs.statSync(path.join(backupsDir, f)).size / 1024 / 1024).toFixed(2) + ' MB'
        }));
        
      res.render('servers/worlds', await getTemplateVars(req, server, {
        worlds,
        currentWorld,
        backups,
        success: req.query.success,
        serverId: server.id,
        activePage: 'worlds',
        error: req.query.error,
        currentPage: 'worlds',
        title: `${server.name} - Worlds`
      }));
    } catch (err) {
      console.error(`Worlds page error for server ${serverId}`, err);
      res.status(500).render('error', await getTemplateVars(req, null, {
        message: 'Failed to load worlds',
        error: err.message,
        status: 500,
        title: 'Error'
      }));
    }
  });
 
  // Set Active World
  app.post('/servers/:id/worlds/set', requireAuth, requirePermission('worlds'), async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    const { worldName } = req.body;
    if (!worldName) return res.status(400).json({ error: 'World name required' });
    try {
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      const worldDir = resolveServerPath(serverId, worldName);
      if (!fs.existsSync(path.join(worldDir, 'level.dat'))) return res.redirect(`/servers/${serverId}/worlds?error=Invalid world`);
      const propertiesPath = resolveServerPath(serverId, 'server.properties');
      let properties = {};
      if (fs.existsSync(propertiesPath)) {
        properties = parseProperties(fs.readFileSync(propertiesPath, 'utf8'));
      }
      properties['level-name'] = worldName;
      writeProperties(properties, propertiesPath);
      res.redirect(`/servers/${serverId}/worlds?success=Active world set to ${worldName}`);
    } catch (err) {
      console.error(`Set world error for server ${serverId}`, err);
      res.redirect(`/servers/${serverId}/worlds?error=Failed to set active world`);
    }
  });
 
  // Download World
  app.get('/servers/:id/worlds/download/:worldName', requireAuth, requirePermission('worlds_download'), async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).send('Access denied');
    const worldName = req.params.worldName;
    try {
      const worldDir = resolveServerPath(serverId, worldName);
      if (!fs.existsSync(worldDir)) {
        return res.status(404).send('World not found');
      }
      
      // Check if world has level.dat (is generated)
      if (!fs.existsSync(path.join(worldDir, 'level.dat'))) {
        return res.status(404).send('World not found or not yet generated');
      }
      
      const zipName = `${worldName}-${Date.now()}.zip`;
      res.setHeader('Content-Disposition', `attachment; filename="${zipName}"`);
      res.setHeader('Content-Type', 'application/zip');
      
      const archive = archiver('zip', { zlib: { level: 9 } });
      
      archive.on('error', (err) => {
        console.error('Archive error:', err);
        if (!res.headersSent) {
          res.status(500).send('Failed to create archive');
        }
      });
      
      archive.pipe(res);
      
      // Add all files from world directory into a folder named "world"
      // This makes it ready to use directly in Minecraft servers
      const files = fs.readdirSync(worldDir);
      for (const file of files) {
        const filePath = path.join(worldDir, file);
        const stat = fs.statSync(filePath);
        
        if (stat.isDirectory()) {
          // Archive directory with "world" as the parent folder
          archive.directory(filePath, `world/${file}`);
        } else {
          // Archive file with "world" as the parent folder
          archive.file(filePath, { name: `world/${file}` });
        }
      }
      
      await archive.finalize();
      console.log(`World downloaded: ${worldName} (packaged as "world" folder)`);
    } catch (err) {
      console.error(`Download world error for server ${serverId}`, err);
      if (!res.headersSent) {
        res.status(500).send('Download failed: ' + err.message);
      }
    }
  });
 
  // Delete World
  app.post('/servers/:id/worlds/delete', requireAuth, requirePermission('worlds_delete'), async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    
    const { worldName } = req.body;
    if (!worldName) return res.status(400).json({ error: 'World name required' });
    
    try {
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      if (!server) return res.status(404).json({ error: 'Server not found' });
      

      if (server.node_id) {
        console.log(`📤 Queuing world delete command for remote node ${server.node_id}, server ${serverId}`);
        await queueNodeAction(server.node_id, serverId, 'world-delete', {
          worldName: sanitize(worldName)
        });
        return res.json({ 
          success: true, 
          message: 'World deletion queued on remote node!',
          queued: true
        });
      }
      
      // Local Node: handle locally
      const propertiesPath = resolveServerPath(serverId, 'server.properties');
      let currentWorld = 'world';
      
      if (fs.existsSync(propertiesPath)) {
        const content = fs.readFileSync(propertiesPath, 'utf8');
        const match = content.match(/^level-name=(.*)$/m);
        if (match) currentWorld = match[1].trim();
      }
      
      if (worldName === currentWorld) {
        return res.status(400).json({ error: 'Cannot delete active world' });
      }
      
      const worldDir = resolveServerPath(serverId, worldName);
      if (fs.existsSync(worldDir)) {
        fs.rmSync(worldDir, { recursive: true, force: true });
        res.json({ success: true, message: 'World deleted successfully' });
      } else {
        res.status(404).json({ error: 'World not found' });
      }
    } catch (err) {
      console.error('Delete world error:', err);
      res.status(500).json({ error: 'Failed to delete world' });
    }
  });
  
  // Upload World
  app.post('/servers/:id/worlds/upload', requireAuth, upload.single('worldFile'), requirePermission('worlds_upload'), async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    
    const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
    if (!server) {
      if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
      return res.status(404).json({ error: 'Server not found' });
    }
    
    if (!req.file) return res.status(400).json({ error: 'World file required' });

    // World name optional: auto-generate from the archive file name (daemon uniquifies on collision)
    const { worldName } = req.body;
    let uploadName = worldName || req.body.name;
    if (!uploadName && req.file && req.file.originalname) {
      const base = path.basename(req.file.originalname)
        .replace(/\.(zip|rar|7z|tar|tar\.gz|tgz|tar\.bz2|tbz2|tbz)$/i, '')
        .trim();
      uploadName = sanitize(base || 'world') || 'world';
    }
    if (!uploadName) uploadName = 'world';
    

    if (server.node_id) {
      console.log(`📤 Queuing world upload command for remote node ${server.node_id}, server ${serverId}`);
      
      // Read the file and pass as base64
      const fileBuffer = fs.readFileSync(req.file.path);
      const fileBase64 = fileBuffer.toString('base64');
      
      // Clean up temp file
      fs.unlinkSync(req.file.path);
      
      await queueNodeAction(server.node_id, serverId, 'world-upload', {
        worldName: sanitize(uploadName),
        filename: (req.file.originalname || 'world.zip'),
        fileData: fileBase64
      });
      return res.json({ 
        success: true, 
        message: `World upload queued on remote node as "${uploadName}"!`,
        worldName: uploadName,
        queued: true
      });
    }
    
    // Local Node: handle locally
    try {
      const baseName = sanitize(uploadName);
      
      // Auto-generate a unique folder name so existing worlds are never overwritten
      let finalName = baseName;
      let i = 2;
      while (fs.existsSync(resolveServerPath(serverId, finalName))) {
        finalName = `${baseName}-${i}`;
        i++;
      }
      const worldDir = resolveServerPath(serverId, finalName);
      
      // Create world directory
      fs.mkdirSync(worldDir, { recursive: true });
      
      // Extract uploaded ZIP
      try {
        await new Promise((resolve, reject) => {
          fs.createReadStream(req.file.path)
            .pipe(unzipper.Extract({ path: worldDir }))
            .on('close', resolve)
            .on('error', reject);
        });
      } catch (extractErr) {
        try { fs.rmSync(worldDir, { recursive: true, force: true }); } catch (e) {}
        throw extractErr;
      }
      
      // Clean up uploaded file
      fs.unlinkSync(req.file.path);
      
      res.json({
        success: true,
        message: finalName !== baseName ? `World uploaded as "${finalName}" (name already existed)` : 'World uploaded successfully',
        worldName: finalName,
        renamed: finalName !== baseName
      });
    } catch (err) {
      console.error('Upload world error:', err);
      if (req.file && fs.existsSync(req.file.path)) {
        fs.unlinkSync(req.file.path);
      }
      res.status(500).json({ error: 'Failed to upload world' });
    }
  });
  
  // Switch World
  app.post('/servers/:id/worlds/switch', requireAuth, requirePermission('worlds'), async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    
    const { worldName } = req.body;
    if (!worldName) return res.status(400).json({ error: 'World name required' });
    
    try {
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      if (!server) return res.status(404).json({ error: 'Server not found' });
      
      if (server.node_id) {
        // Remote node - queue the action
        console.log(`📤 Queuing world switch command for remote node ${server.node_id}, server ${serverId}`);
        await queueNodeAction(server.node_id, serverId, 'world-switch', {
          worldName: sanitize(worldName)
        });
        return res.json({ 
          success: true, 
          message: 'World switch queued on remote node!',
          queued: true
        });
      }
      
      // Local Node: handle directly
      const worldDir = resolveServerPath(serverId, worldName);
      if (!fs.existsSync(worldDir)) {
        return res.status(404).json({ error: 'World not found' });
      }
      
      // Rename the selected world to "world" for easy deployment
      const targetWorldDir = resolveServerPath(serverId, 'world');
      
      // If "world" already exists and it's not the same as the selected world, back it up
      if (fs.existsSync(targetWorldDir) && worldName !== 'world') {
        const backupName = `world_backup_${Date.now()}`;
        const backupDir = resolveServerPath(serverId, backupName);
        console.log(`Backing up current world to: ${backupName}`);
        fs.renameSync(targetWorldDir, backupDir);
      }
      
      // Rename the selected world to "world"
      if (worldName !== 'world') {
        console.log(`Renaming ${worldName} to world`);
        fs.renameSync(worldDir, targetWorldDir);
      }
      
      // Update server.properties to use "world"
      const propertiesPath = resolveServerPath(serverId, 'server.properties');
      if (fs.existsSync(propertiesPath)) {
        let content = fs.readFileSync(propertiesPath, 'utf8');
        content = content.replace(/^level-name=.*$/m, `level-name=world`);
        fs.writeFileSync(propertiesPath, content);
      }
      
      res.json({ 
        success: true, 
        message: 'World switched successfully! The selected world has been renamed to "world" and set as active.' 
      });
    } catch (err) {
      console.error('Switch world error:', err);
      res.status(500).json({ error: 'Failed to switch world: ' + err.message });
    }
  });
 
  // Upload World
  // Upload World from URL (FIXED: use axios instead of fetch for compatibility)
  app.post('/servers/:id/worlds/upload_url', requireAuth, requirePermission('worlds_upload'), async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    const { url, name } = req.body;
    if (!url || !name) return res.status(400).json({ error: 'URL and name required' });
    const worldName = sanitize(name);
    if (!worldName) return res.status(400).json({ error: 'Invalid world name' });
    let tempPath = path.join(os.tmpdir(), `world-${Date.now()}.zip`);
    let targetDir = resolveServerPath(serverId, worldName);
    try {
      const response = await axios({
        url,
        method: 'GET',
        responseType: 'stream'
      });
      const fileStream = fs.createWriteStream(tempPath);
      await new Promise((resolve, reject) => {
        response.data.pipe(fileStream);
        response.data.on('error', reject);
        fileStream.on('finish', resolve);
      });
      if (fs.existsSync(targetDir)) throw new Error('World already exists');
      await new Promise((resolve, reject) => {
        fs.createReadStream(tempPath)
          .pipe(unzipper.Extract({ path: targetDir }))
          .on('close', resolve)
          .on('error', reject);
      });
      // Normalize directory structure if needed
      if (!fs.existsSync(path.join(targetDir, 'level.dat'))) {
        const subdirs = fs.readdirSync(targetDir, { withFileTypes: true }).filter(d => d.isDirectory());
        if (subdirs.length === 1) {
          const subDirPath = path.join(targetDir, subdirs[0].name);
          if (fs.existsSync(path.join(subDirPath, 'level.dat'))) {
            fs.readdirSync(subDirPath).forEach(f => {
              fs.renameSync(path.join(subDirPath, f), path.join(targetDir, f));
            });
            fs.rmdirSync(subDirPath);
          }
        }
      }
      if (!fs.existsSync(path.join(targetDir, 'level.dat'))) {
        fs.rmSync(targetDir, { recursive: true, force: true });
        throw new Error('Not a valid Minecraft world');
      }
      res.redirect(`/servers/${serverId}/worlds?success=World uploaded from URL`);
    } catch (err) {
      console.error(`Upload URL error for server ${serverId}`, err);
      if (fs.existsSync(targetDir)) fs.rmSync(targetDir, { recursive: true, force: true });
      res.redirect(`/servers/${serverId}/worlds?error=Failed to upload from URL: ${err.message}`);
    } finally {
      if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
    }
  });
 
  // Create Backup
  app.post('/servers/:id/worlds/backup', requireAuth, requirePermission('worlds'), async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    const { worldName } = req.body;
    if (!worldName) return res.status(400).json({ error: 'World name required' });
    try {
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      const worldDir = resolveServerPath(serverId, worldName);
      if (!fs.existsSync(path.join(worldDir, 'level.dat'))) return res.redirect(`/servers/${serverId}/worlds?error=Invalid world`);
      const backupsDir = path.join(resolveServerPath(serverId), 'backups');
      if (!fs.existsSync(backupsDir)) fs.mkdirSync(backupsDir, { recursive: true });
      const timestamp = new Date().toISOString().replace(/:/g, '-');
      const zipName = `${worldName}-${timestamp}.zip`;
      const zipPath = path.join(backupsDir, zipName);
      const output = fs.createWriteStream(zipPath);
      const archive = archiver('zip', { zlib: { level: 9 } });
      archive.pipe(output);
      archive.directory(worldDir, false);
      await archive.finalize();
      res.redirect(`/servers/${serverId}/worlds?success=Backup created: ${zipName}`);
    } catch (err) {
      console.error(`Backup error for server ${serverId}`, err);
      res.redirect(`/servers/${serverId}/worlds?error=Failed to create backup`);
    }
  });
 
  // Download Backup
  app.get('/servers/:id/worlds/backup/download/:backupName', requireAuth, requirePermission('worlds_download'), async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).send('Access denied');
    const backupName = req.params.backupName;
    try {
      const backupsDir = resolveServerPath(serverId, 'backups');
      const zipPath = path.join(backupsDir, backupName);
      if (!fs.existsSync(zipPath)) return res.status(404).send('Backup not found');
      res.download(zipPath);
    } catch (err) {
      console.error(`Download backup error for server ${serverId}`, err);
      res.status(500).send('Download failed');
    }
  });
 
  // Delete Backup
  app.post('/servers/:id/worlds/backup/delete', requireAuth, requirePermission('worlds_delete'), async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    
    const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
    if (!server) return res.status(404).json({ error: 'Server not found' });
    
    const { backupName } = req.body;
    if (!backupName) return res.status(400).json({ error: 'Backup name required' });
    

    if (server.node_id) {
      console.log(`📤 Queuing backup delete command for remote node ${server.node_id}, server ${serverId}`);
      await queueNodeAction(server.node_id, serverId, 'backup-delete', {
        backupName: sanitize(backupName)
      });
      return res.json({ 
        success: true, 
        message: 'Backup deletion queued on remote node!',
        queued: true
      });
    }
    
    // Local Node: handle locally
    try {
      const backupsDir = resolveServerPath(serverId, 'backups');
      const zipPath = path.join(backupsDir, backupName);
      if (fs.existsSync(zipPath)) {
        fs.unlinkSync(zipPath);
        res.redirect(`/servers/${serverId}/worlds?success=Backup deleted`);
      } else {
        res.redirect(`/servers/${serverId}/worlds?error=Backup not found`);
      }
    } catch (err) {
      console.error(`Delete backup error for server ${serverId}`, err);
      res.redirect(`/servers/${serverId}/worlds?error=Failed to delete backup`);
    }
  });
 
  // Restore from Backup
  app.post('/servers/:id/worlds/backup/restore', requireAuth, requirePermission('worlds'), async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    const { backupName, worldName } = req.body;
    if (!backupName || !worldName) return res.status(400).json({ error: 'Backup and world name required' });
    const sanitizedWorldName = sanitize(worldName);
    if (!sanitizedWorldName) return res.status(400).json({ error: 'Invalid world name' });
    try {
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      const targetDir = resolveServerPath(serverId, sanitizedWorldName);
      if (fs.existsSync(targetDir)) return res.redirect(`/servers/${serverId}/worlds?error=World already exists`);
      const backupsDir = resolveServerPath(serverId, 'backups');
      const zipPath = path.join(backupsDir, backupName);
      if (!fs.existsSync(zipPath)) return res.redirect(`/servers/${serverId}/worlds?error=Backup not found`);
      await new Promise((resolve, reject) => {
        fs.createReadStream(zipPath)
          .pipe(unzipper.Extract({ path: targetDir }))
          .on('close', resolve)
          .on('error', reject);
      });
      // Normalize directory structure if needed
      if (!fs.existsSync(path.join(targetDir, 'level.dat'))) {
        const subdirs = fs.readdirSync(targetDir, { withFileTypes: true }).filter(d => d.isDirectory());
        if (subdirs.length === 1) {
          const subDirPath = path.join(targetDir, subdirs[0].name);
          if (fs.existsSync(path.join(subDirPath, 'level.dat'))) {
            fs.readdirSync(subDirPath).forEach(f => {
              fs.renameSync(path.join(subDirPath, f), path.join(targetDir, f));
            });
            fs.rmdirSync(subDirPath);
          }
        }
      }
      if (!fs.existsSync(path.join(targetDir, 'level.dat'))) {
        fs.rmSync(targetDir, { recursive: true, force: true });
        return res.redirect(`/servers/${serverId}/worlds?error=Not a valid Minecraft world`);
      }
      res.redirect(`/servers/${serverId}/worlds?success=Restored from backup`);
    } catch (err) {
      console.error(`Restore error for server ${serverId}`, err);
      if (fs.existsSync(targetDir)) fs.rmSync(targetDir, { recursive: true, force: true });
      res.redirect(`/servers/${serverId}/worlds?error=Failed to restore`);
    }
  });
 
  // Rename World
  app.post('/servers/:id/worlds/rename', requireAuth, requirePermission('worlds'), async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    
    let { oldName, newName } = req.body;
    if (!oldName || !newName) return res.status(400).json({ error: 'Old and new names required' });
    
    const sanitizedNewName = sanitize(newName);
    if (!sanitizedNewName || oldName === sanitizedNewName) return res.status(400).json({ error: 'Invalid new name' });
    
    try {
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      if (!server) return res.status(404).json({ error: 'Server not found' });
      
      // Queue rename action to remote node
      await queueNodeAction(server.node_id, serverId, 'world-rename', {
        oldName: oldName,
        newName: sanitizedNewName
      });
      
      return res.json({ success: true, message: `World renamed to ${sanitizedNewName}` });
    } catch (err) {
      console.error(`Rename error for server ${serverId}`, err);
      return res.status(500).json({ error: err.message || 'Failed to rename world' });
    }
  });
 
  // Change World Seed
  app.post('/servers/:id/worlds/change_seed', requireAuth, requirePermission('worlds'), async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    const { worldName, newSeed } = req.body;
    if (!worldName || !newSeed) return res.status(400).json({ error: 'World name and seed required' });
    try {
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      const worldDir = resolveServerPath(serverId, worldName);
      const levelDatPath = path.join(worldDir, 'level.dat');
      
      // If level.dat exists, modify it
      if (fs.existsSync(levelDatPath)) {
        await setWorldSeed(worldDir, newSeed);
        res.redirect(`/servers/${serverId}/worlds?success=Seed changed to ${newSeed}`);
      } else {
        // If level.dat doesn't exist, update server.properties instead
        const propertiesPath = resolveServerPath(serverId, 'server.properties');
        if (fs.existsSync(propertiesPath)) {
          const propertiesContent = fs.readFileSync(propertiesPath, 'utf8');
          const properties = parseProperties(propertiesContent);
          properties['level-seed'] = newSeed;
          writeProperties(properties, propertiesPath);
          res.redirect(`/servers/${serverId}/worlds?success=Seed set to ${newSeed} (will apply on first start)`);
        } else {
          res.redirect(`/servers/${serverId}/worlds?error=Server properties not found`);
        }
      }
    } catch (err) {
      console.error(`Change seed error for server ${serverId}`, err);
      res.redirect(`/servers/${serverId}/worlds?error=Failed to change seed: ${err.message}`);
    }
  });

  // World Marketplace - View
  app.get('/servers/:id/worlds/marketplace', requireAuth, requirePermission('worlds'), async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).send('Access denied');
    
    try {
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      if (!server) return res.status(404).send('Server not found');
      
      res.render('servers/worlds_marketplace', await getTemplateVars(req, server, {
        serverId: server.id,
        activePage: 'worlds',
        currentPage: 'worlds_marketplace',
        title: `${server.name} - World Marketplace`
      }));
    } catch (err) {
      console.error('World marketplace page error:', err);
      res.status(500).send('Server error');
    }
  });

  // World Marketplace API - Multi-provider support
  app.get('/servers/:id/worlds/marketplace/api', requireAuth, requirePermission('worlds'), async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    
    const { provider = 'curseforge', search = '', page = 1 } = req.query;
    
    try {
      let worlds = [];
      
      switch (provider) {
        case 'curseforge':
          worlds = await fetchCurseForgeWorlds(search, page);
          break;
        case 'planetminecraft':
          worlds = await fetchPlanetMinecraftWorlds(search, page);
          break;
        case 'minecraftmaps':
          worlds = await fetchMinecraftMapsWorlds(search, page);
          break;
        case 'modrinth':
          worlds = await fetchModrinthWorlds(search, page);
          break;
        case '9minecraft':
          worlds = await fetchNineMinecraftWorlds(search, page);
          break;
        default:
          worlds = await fetchCurseForgeWorlds(search, page);
      }
      
      res.json({
        success: true,
        worlds: worlds,
        provider: provider,
        page: parseInt(page)
      });
      
    } catch (err) {
      console.error(`[Worlds Marketplace] ${provider} error:`, err.message);
      res.status(500).json({
        success: false,
        error: `Failed to fetch worlds from ${provider}`,
        details: err.message
      });
    }
  });

  // World Download endpoint - Multi-provider support
  app.post('/servers/:id/worlds/marketplace/download', requireAuth, requirePermission('worlds_download'), async (req, res) => {
    const serverId = req.params.id;
    if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
    
    const { worldId, worldName, provider, downloadUrl } = req.body;
    
    try {
      let downloadLink = downloadUrl;
      
      switch (provider) {
        case 'CurseForge':
          downloadLink = await getCurseForgeDownloadLink(worldId);
          break;
        case 'Planet Minecraft':
          downloadLink = `https://www.planetminecraft.com/project/view/${worldId}`;
          break;
        case 'MinecraftMaps':
          downloadLink = `https://www.minecraftmaps.com/world/${worldId}`;
          break;
        case 'Modrinth':
          downloadLink = `https://modrinth.com/worlds/${worldId}`;
          break;
        case '9Minecraft':
          downloadLink = `https://www.9minecraft.net/world/${worldId}/`;
          break;
      }
      
      res.json({
        success: true,
        downloadLink: downloadLink,
        worldName: worldName,
        instructions: `Download from ${provider} and use Files section to upload`
      });
      
    } catch (err) {
      console.error('[World Download]', err.message);
      res.status(500).json({ error: 'Failed to get download link' });
    }
  });

  // One-click world install endpoint
  app.post('/servers/:id/worlds/marketplace/install', requireAuth, requirePermission('worlds'), async (req, res) => {
    try {
      const serverId = req.params.id;
      const { worldId, worldName, provider } = req.body;
      
      const server = await dbGet('SELECT * FROM servers WHERE id=?', [serverId]);
      if (!server) return res.status(404).json({ error: 'Server not found' });
      if (!(await isAuthorized(req, serverId))) return res.status(403).json({ error: 'Access denied' });
      
      let downloadUrl = null;
      
      // Get download URL from provider
      if (provider === 'CurseForge') {
        // Get the latest file info from CurseForge API
        const apiKey = process.env.CURSEFORGE_API_KEY || '$2a$10$bL4bIL5pUWqfcO7KQtnMReakwtfHbNKh6v1uTpKlzhwoueEJQnPnm';
        try {
          const modRes = await axios.get(`https://api.curseforge.com/v1/mods/${worldId}/files?pageSize=1`, {
            headers: { 'x-api-key': apiKey },
            timeout: 10000
          });
          if (modRes.data?.data?.[0]?.downloadUrl) {
            downloadUrl = modRes.data.data[0].downloadUrl;
          }
        } catch (err) {
          console.error('[CurseForge Download] Error:', err.message);
        }
      } else if (provider === 'Modrinth') {
        // For Modrinth, get the latest version download URL
        try {
          const modRes = await axios.get(`https://api.modrinth.com/v2/project/${worldId}/latest_version`, { timeout: 10000 });
          if (modRes.data?.files?.[0]?.url) {
            downloadUrl = modRes.data.files[0].url;
          }
        } catch (err) {
          console.error('[Modrinth Download] Error:', err.message);
        }
      }
      
      if (!downloadUrl) {
        return res.status(400).json({ error: 'Could not resolve world download URL from ' + provider });
      }
      
      // Queue the world installation on remote node
      await queueNodeAction(server.node_id, serverId, 'world-install', {
        worldId,
        worldName,
        provider,
        url: downloadUrl
      });
      
      return res.json({ success: true, message: `${worldName} installation queued on remote node!`, queued: true });
      
    } catch (err) {
      console.error('[World Install]', err.message);
      res.status(500).json({ error: err.message || 'Failed to install world' });
    }
  });

// ============================================================
// MULTI-PROVIDER WORLD FETCHERS
// ============================================================

async function fetchCurseForgeWorlds(search = '', page = 1) {
  const apiKey = process.env.CURSEFORGE_API_KEY || '$2a$10$bL4bIL5pUWqfcO7KQtnMReakwtfHbNKh6v1uTpKlzhwoueEJQnPnm';
  
  const params = {
    gameId: 432, // Minecraft
    classId: 17, // Worlds
    sortField: 2, // Popularity
    sortOrder: 'desc',
    index: (page - 1) * 20,
    pageSize: 20
  };
  
  if (search) params.searchFilter = search;
  
  try {
    const response = await axios.get('https://api.curseforge.com/v1/mods/search', {
      headers: {
        'x-api-key': apiKey,
        'Accept': 'application/json',
        'User-Agent': 'MinecraftServerPanel/1.0'
      },
      params: params,
      timeout: 15000
    });
    
    return response.data.data.map(mod => {
      const latestFile = mod.latestFiles && mod.latestFiles.length > 0 ? mod.latestFiles[0] : null;
      return {
        id: mod.id,
        name: mod.name,
        description: (mod.summary || 'No description').substring(0, 150),
        author: mod.authors && mod.authors.length > 0 ? mod.authors[0].name : 'Unknown',
        downloads: mod.downloadCount || 0,
        image: mod.logo ? mod.logo.url : '',
        downloadUrl: mod.links?.websiteUrl || `https://www.curseforge.com/minecraft/worlds/${mod.slug}`,
        provider: 'CurseForge'
      };
    });
  } catch (err) {
    console.error('[CurseForge]', err.message);
    return [];
  }
}

async function fetchPlanetMinecraftWorlds(search = '', page = 1) {
  try {
    // Planet Minecraft doesn't have a public API, but we can construct search URLs
    // In production, you'd use web scraping here
    console.log('[PlanetMinecraft] Fetching worlds for search:', search);
    
    // Since we can't scrape easily, return curated popular worlds
    const popularWorlds = [
      {
        id: 'planet-1',
        name: 'Floating Islands Adventure',
        description: 'Explore beautiful floating islands with custom terrain',
        author: 'PlanetMinecraft Community',
        downloads: 50000,
        image: 'https://media.forgecdn.net/avatars/thumbnails/default.png',
        downloadUrl: 'https://www.planetminecraft.com/project/view/',
        provider: 'Planet Minecraft'
      },
      {
        id: 'planet-2',
        name: 'Custom Dimension World',
        description: 'Experience new dimensions and challenges',
        author: 'PlanetMinecraft Community',
        downloads: 35000,
        image: 'https://media.forgecdn.net/avatars/thumbnails/default.png',
        downloadUrl: 'https://www.planetminecraft.com/project/view/',
        provider: 'Planet Minecraft'
      }
    ];
    
    if (search) {
      return popularWorlds.filter(w => 
        w.name.toLowerCase().includes(search.toLowerCase()) ||
        w.description.toLowerCase().includes(search.toLowerCase())
      );
    }
    
    return popularWorlds;
  } catch (err) {
    console.error('[PlanetMinecraft]', err.message);
    return [];
  }
}

async function fetchMinecraftMapsWorlds(search = '', page = 1) {
  try {
    // MinecraftMaps.com doesn't have public API
    // Return popular worlds as examples
    console.log('[MinecraftMaps] Fetching worlds for search:', search);
    
    const popularWorlds = [
      {
        id: 'mcmaps-1',
        name: 'Fantasy Adventure Map',
        description: 'Epic fantasy world with quests and exploration',
        author: 'MinecraftMaps Community',
        downloads: 45000,
        image: 'https://media.forgecdn.net/avatars/thumbnails/default.png',
        downloadUrl: 'https://www.minecraftmaps.com/world/view/',
        provider: 'MinecraftMaps'
      },
      {
        id: 'mcmaps-2',
        name: 'Horror Survival Map',
        description: 'Survive in a dark and mysterious world',
        author: 'MinecraftMaps Community',
        downloads: 32000,
        image: 'https://media.forgecdn.net/avatars/thumbnails/default.png',
        downloadUrl: 'https://www.minecraftmaps.com/world/view/',
        provider: 'MinecraftMaps'
      }
    ];
    
    if (search) {
      return popularWorlds.filter(w => 
        w.name.toLowerCase().includes(search.toLowerCase()) ||
        w.description.toLowerCase().includes(search.toLowerCase())
      );
    }
    
    return popularWorlds;
  } catch (err) {
    console.error('[MinecraftMaps]', err.message);
    return [];
  }
}

async function fetchModrinthWorlds(search = '', page = 1) {
  try {
    // Modrinth API for worlds - use facets for proper filtering
    const offset = (page - 1) * 20;
    const searchQuery = search || 'world';
    
    const response = await axios.get('https://api.modrinth.com/v2/search', {
      params: {
        query: searchQuery,
        facets: '[["project_type:world"]]',
        limit: 20,
        offset: offset,
        index: 'relevance'
      },
      timeout: 15000
    });
    
    return response.data.hits.map(proj => ({
      id: proj.slug,
      name: proj.title,
      description: (proj.description || '').substring(0, 150),
      author: proj.author || 'Unknown',
      downloads: proj.downloads || 0,
      image: proj.icon_url || '',
      downloadUrl: `https://modrinth.com/worlds/${proj.slug}`,
      provider: 'Modrinth'
    }));
  } catch (err) {
    console.error('[Modrinth]', err.message);
    return [];
  }
}

async function fetchNineMinecraftWorlds(search = '', page = 1) {
  try {
    // 9Minecraft.net doesn't have a public API
    // Return popular worlds as examples
    console.log('[9Minecraft] Fetching worlds for search:', search);
    
    const popularWorlds = [
      {
        id: '9mc-1',
        name: 'City Build World',
        description: 'Build and expand your own city',
        author: '9Minecraft Community',
        downloads: 55000,
        image: 'https://media.forgecdn.net/avatars/thumbnails/default.png',
        downloadUrl: 'https://www.9minecraft.net/world/',
        provider: '9Minecraft'
      },
      {
        id: '9mc-2',
        name: 'Parkour Challenge World',
        description: 'Test your parkour skills with multiple challenges',
        author: '9Minecraft Community',
        downloads: 28000,
        image: 'https://media.forgecdn.net/avatars/thumbnails/default.png',
        downloadUrl: 'https://www.9minecraft.net/world/',
        provider: '9Minecraft'
      },
      {
        id: '9mc-3',
        name: 'Survival Island',
        description: 'Survive on a mysterious island',
        author: '9Minecraft Community',
        downloads: 41000,
        image: 'https://media.forgecdn.net/avatars/thumbnails/default.png',
        downloadUrl: 'https://www.9minecraft.net/world/',
        provider: '9Minecraft'
      }
    ];
    
    if (search) {
      return popularWorlds.filter(w => 
        w.name.toLowerCase().includes(search.toLowerCase()) ||
        w.description.toLowerCase().includes(search.toLowerCase())
      );
    }
    
    return popularWorlds;
  } catch (err) {
    console.error('[9Minecraft]', err.message);
    return [];
  }
}

async function getCurseForgeDownloadLink(worldId) {
  try {
    const apiKey = process.env.CURSEFORGE_API_KEY || '$2a$10$bL4bIL5pUWqfcO7KQtnMReakwtfHbNKh6v1uTpKlzhwoueEJQnPnm';
    
    const response = await axios.get(`https://api.curseforge.com/v1/mods/${worldId}`, {
      headers: {
        'x-api-key': apiKey,
        'Accept': 'application/json',
        'User-Agent': 'MinecraftServerPanel/1.0'
      },
      timeout: 10000
    });
    
    return response.data.data?.links?.websiteUrl || `https://www.curseforge.com/minecraft/worlds`;
  } catch (err) {
    return `https://www.curseforge.com/minecraft/worlds`;
  }
}

  // Direct download route - Shows CurseForge policy message
  app.get('/servers/:id/worlds/download/:worldId/:fileId', requireAuth, requirePermission('worlds_download'), async (req, res) => {
    const serverId = req.params.id;
    const { worldId, fileId } = req.params;
    
    try {
      // Check authorization
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      if (!server) {
        return res.status(404).json({ success: false, error: 'Server not found' });
      }
      
      // CurseForge API key
      const apiKey = process.env.CURSEFORGE_API_KEY || '$2a$10$bL4bIL5pUWqfcO7KQtnMReakwtfHbNKh6v1uTpKlzhwoueEJQnPnm';
      let fileName = `world-${worldId}-${fileId}.zip`;
      let curseForgeUrl = `https://www.curseforge.com/minecraft/worlds/`;
      
      try {
        // Get file info from CurseForge API
        const fileInfoResponse = await axios.get(`https://api.curseforge.com/v1/mods/${worldId}/files/${fileId}`, {
          headers: {
            'x-api-key': apiKey,
            'Accept': 'application/json',
            'User-Agent': 'MinecraftServerPanel/1.0'
          },
          timeout: 10000
        });
        
        const fileInfo = fileInfoResponse.data.data;
        fileName = fileInfo.fileName || fileName;
        
        // Get mod name for direct link
        const modResponse = await axios.get(`https://api.curseforge.com/v1/mods/${worldId}`, {
          headers: {
            'x-api-key': apiKey,
            'Accept': 'application/json',
            'User-Agent': 'MinecraftServerPanel/1.0'
          },
          timeout: 10000
        });
        
        const modData = modResponse.data.data;
        curseForgeUrl = modData.links?.websiteUrl || `https://www.curseforge.com/minecraft/worlds`;
        
      } catch (apiError) {
        console.log(`[World Download] Could not fetch file info: ${apiError.message}`);
      }
      
      // Return user-friendly message about CurseForge policy
      return res.json({
        success: false,
        error: 'CurseForge Automated Downloads Not Available',
        reason: 'curseforge_policy',
        message: 'CurseForge does not allow automated downloads for worlds. Please download manually from CurseForge.',
        fileName: fileName,
        downloadLink: curseForgeUrl,
        instructions: [
          '1. Click the link above to open the world page on CurseForge',
          '2. Click the "Files" tab',
          '3. Find the latest version and click "Download"',
          '4. You can then upload the ZIP file using the Files manager'
        ]
      });
      
    } catch (err) {
      console.error('[World Download] Error:', err.message);
      return res.status(500).json({
        success: false,
        error: 'Failed to fetch world information',
        message: err.message
      });
    }
  });

  // List downloaded worlds
  app.get('/servers/:id/worlds/downloaded', requireAuth, requirePermission('worlds'), async (req, res) => {
    const serverId = req.params.id;
    
    try {
      const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
      if (!server) {
        return res.status(404).json({ error: 'Server not found' });
      }
      
      const serverDir = resolveServerPath(serverId);
      
      if (!fs.existsSync(serverDir)) {
        return res.json({ success: true, worlds: [] });
      }
      
      const files = fs.readdirSync(serverDir);
      const zipFiles = files.filter(f => f.endsWith('.zip'));
      
      const worlds = zipFiles.map(fileName => {
        const filePath = path.join(serverDir, fileName);
        const stats = fs.statSync(filePath);
        const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);
        
        return {
          fileName: fileName,
          filePath: `servers/${serverId}/${fileName}`,
          fileSize: `${fileSizeMB} MB`,
          downloadedAt: stats.mtime
        };
      });
      
      res.json({ success: true, worlds: worlds });
      
    } catch (err) {
      console.error('Error listing downloaded worlds:', err);
      res.status(500).json({ error: 'Failed to list downloaded worlds' });
    }
  });


// ================================================
// SERVER PROPERTIES ROUTES
// ================================================

// Properties editor page
app.get('/servers/:id/properties', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!(await isAuthorized(req, serverId))) {
            return res.status(403).send('Access denied');
        }

        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).send('Server not found');
        }

        res.render('servers/properties', await getTemplateVars(req, server, {
            activePage: 'properties',
            currentPage: 'server-properties'
        }));
    } catch (err) {
        console.error('Properties page error:', err);
        res.status(500).send('Internal server error');
    }
});

// Get current properties as JSON
app.get('/servers/:id/properties/get', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!(await isAuthorized(req, serverId))) {
            return res.status(403).json({ error: 'Access denied' });
        }

        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }

        const propertiesPath = resolveServerPath(serverId, 'server.properties');
        let properties = {};

        if (fs.existsSync(propertiesPath)) {
            try {
                const content = fs.readFileSync(propertiesPath, 'utf8');
                properties = parseProperties(content);
            } catch (err) {
                console.error('Error reading server.properties:', err);
                // Return default properties if file can't be read
                properties = getDefaultProperties(server);
            }
        } else {
            // Create default properties file if it doesn't exist
            properties = getDefaultProperties(server);
            await updateServerPropertiesPort(serverId, server.port);
        }

        res.json({ success: true, properties });
    } catch (err) {
        console.error('Get properties error:', err);
        res.status(500).json({ error: 'Failed to load properties' });
    }
});

// Save properties
app.post('/servers/:id/properties/save', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!(await isAuthorized(req, serverId))) {
            return res.status(403).json({ error: 'Access denied' });
        }

        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }

        const { properties } = req.body;
        if (!properties || typeof properties !== 'object') {
            return res.status(400).json({ error: 'Invalid properties data' });
        }

        // Ensure server port is protected
        properties['server-port'] = server.port;


        if (server.node_id) {
            console.log(`📤 Queuing properties save command for remote node ${server.node_id}, server ${serverId}`);
            await queueNodeAction(server.node_id, serverId, 'properties-save', {
                properties: properties
            });
            return res.json({ 
                success: true, 
                message: 'Properties save queued on remote node!',
                queued: true,
                warning: 'Server port was protected and not changed'
            });
        }

        // Local Node: write properties to file
        const propertiesPath = resolveServerPath(serverId, 'server.properties');
        
        // Write properties to file
        writeProperties(properties, propertiesPath);

        console.log(`Properties saved for server ${serverId}`);
        
        res.json({ 
            success: true, 
            message: 'Properties saved successfully!',
            warning: properties['server-port'] !== server.port ? 'Server port was protected and not changed' : null
        });
    } catch (err) {
        console.error('Save properties error:', err);
        res.status(500).json({ error: 'Failed to save properties' });
    }
});

// Reset properties to defaults
app.post('/servers/:id/properties/reset', requireAuth, async (req, res) => {
    try {
        const serverId = req.params.id;
        if (!(await isAuthorized(req, serverId))) {
            return res.status(403).json({ error: 'Access denied' });
        }

        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) {
            return res.status(404).json({ error: 'Server not found' });
        }

        // Get default properties and ensure correct port
        const defaultProperties = getDefaultProperties(server);
        defaultProperties['server-port'] = server.port;


        if (server.node_id) {
            console.log(`📤 Queuing properties reset command for remote node ${server.node_id}, server ${serverId}`);
            await queueNodeAction(server.node_id, serverId, 'properties-reset', {
                properties: defaultProperties
            });
            return res.json({ 
                success: true, 
                message: 'Properties reset queued on remote node!',
                queued: true
            });
        }

        // Local Node: write default properties to file
        const propertiesPath = resolveServerPath(serverId, 'server.properties');
        
        // Write default properties to file
        writeProperties(defaultProperties, propertiesPath);

        console.log(`Properties reset to defaults for server ${serverId}`);
        
        res.json({ 
            success: true, 
            message: 'Properties reset to defaults successfully!'
        });
    } catch (err) {
        console.error('Reset properties error:', err);
        res.status(500).json({ error: 'Failed to reset properties' });
    }
});

// Helper function to get default server properties
function getDefaultProperties(server) {
    return {
        'server-ip': '',
        'server-port': server.port,
        'motd': server.name || 'Minecraft Server',
        'max-players': 20,
        'gamemode': 'survival',
        'difficulty': 'normal',
        'hardcore': false,
        'pvp': true,
        'allow-flight': false,
        'level-name': 'world',
        'level-seed': '',
        'level-type': 'minecraft:normal',
        'generate-structures': true,
        'spawn-animals': true,
        'spawn-monsters': true,
        'view-distance': 10,
        'simulation-distance': 10,
        'max-tick-time': 60000,
        'online-mode': true,
        'white-list': false,
        'enforce-whitelist': false,
        'spawn-protection': 16,
        'enable-command-block': false,
        'function-permission-level': 2,
        'op-permission-level': 4,
        'resource-pack': '',
        'resource-pack-sha1': ''
    };
}
 
// ================================================
// SOCKET.IO HANDLERS (enhanced with live stats)
// ================================================
io.on('connection', (socket) => {
    // Client connected - log silently unless debugging
   
    // ================================================
    // PING/PONG KEEPALIVE
    // ================================================
    
    socket.on('ping', (data) => {
        socket.emit('pong', { timestamp: Date.now() });
    });
    
    // ================================================
    // JOIN/LEAVE SERVER ROOMS
    // ================================================
    
    socket.on('join-server', async (serverId) => {
        // Generation token prevents overlapping async join requests from starting duplicate streams.
        if (!socket.consoleStreamGenerations) socket.consoleStreamGenerations = {};
        const streamGeneration = (socket.consoleStreamGenerations[serverId] || 0) + 1;
        socket.consoleStreamGenerations[serverId] = streamGeneration;
        // Replace existing per-socket streams instead of creating duplicate intervals.
        if (socket.streams && socket.streams[serverId]) {
            clearInterval(socket.streams[serverId]);
            delete socket.streams[serverId];
        }
        if (socket.consoleStreams && socket.consoleStreams[serverId]) {
            // consoleStreams stores {stop} controls, not interval ids — the old
            // loop keeps emitting (duplicate lines) unless stop() is called.
            if (typeof socket.consoleStreams[serverId].stop === 'function') {
                socket.consoleStreams[serverId].stop();
            }
            delete socket.consoleStreams[serverId];
        }
        console.log(`\n========== JOIN-SERVER HANDLER ==========`);
        console.log(`Socket ID: ${socket.id}`);
        console.log(`Server ID: ${serverId}`);
        console.log(`Current rooms BEFORE join:`, Array.from(socket.rooms));
        
        socket.join(`server:${serverId}`);
        
        console.log(`Current rooms AFTER join:`, Array.from(socket.rooms));
        console.log(`Room successfully joined: server:${serverId}`);
        console.log(`=========================================\n`);
        
        try {
            // Get initial stats and status
            const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
            if (!server) {
                console.warn(`Server ${serverId} not found`);
                return;
            }
            
    
            if (server.node_id) {
                try {
                    await refreshRemoteServerStats(server);
                } catch (err) {
                    console.warn(`Failed to fetch remote stats for server ${serverId}:`, err.message);
                }
            }
            
            // Send initial stats immediately
            const initialStats = await getServerStats(serverId);
            const initialStatus = await getServerStatus(serverId);
            const serverStats = {
                serverId: serverId,
                serverName: server.name,
                cpu: Number(initialStats.cpu || 0),
                ram: Number(initialStats.ram || 0),  // Already in GB from getServerStats
                disk: Number(initialStats.disk || 0),
                diskUsedMB: Number(initialStats.diskUsedMB || 0),
                tps: (initialStats.tps === null || initialStats.tps === undefined) ? null : Number(initialStats.tps),
                uptime: Number(initialStats.uptime || 0),
                players: Number(initialStats.players || 0),
                status: initialStatus.status || 'offline',
                online: initialStatus.online || false,
                timestamp: Date.now()
            };
            console.log(`[INITIAL STATS] Server ${serverId}: CPU=${serverStats.cpu}%, RAM=${serverStats.ram.toFixed(2)}GB, Disk=${serverStats.disk.toFixed(2)}%, Status=${initialStatus.status}`);
            socket.emit('server-stats', serverStats);
            console.log(`📊 Sent initial stats to client`);
            
            // A newer join request may have arrived while the stats were being fetched.
            if (socket.consoleStreamGenerations[serverId] !== streamGeneration) return;

            // Live online-player list: push the current list immediately (the page
            // renders a snapshot on load) and keep it fresh while anyone watches.
            syncOnlinePlayers(server, socket)
                .catch(err => console.warn(`[player-sync] initial sync failed for server ${serverId}:`, err.message));
            ensurePlayerSync(server);

            // Start live streaming stats for this socket/server combo
            // Generate unique stream ID for this connection
            const streamId = `${socket.id}:${serverId}`;
            
            // Create streaming interval for this specific client watching this server
            const streamInterval = setInterval(async () => {
                try {
                    // Only stream if socket is still connected and in room
                    if (!socket.connected || !socket.rooms.has(`server:${serverId}`)) {
                        clearInterval(streamInterval);
                        // Stream stopped silently
                        return;
                    }
                    
                    // Get fresh stats
                    const stats = await getServerStats(serverId);
                    const status = await getServerStatus(serverId);
                    
                    // Build stats object - ensure consistent types
                    const liveStats = {
                        serverId: serverId,
                        serverName: server.name,
                        cpu: Number(stats.cpu || 0),
                        ram: Number(stats.ram || 0),  // Already in GB from getServerStats
                        disk: Number(stats.disk || 0),  // Percentage
                        diskUsedMB: Number(stats.diskUsedMB || 0),
                        tps: (stats.tps === null || stats.tps === undefined) ? null : Number(stats.tps),
                        uptime: Number(stats.uptime || 0),
                        players: Number(stats.players || 0),
                        status: status.status || 'offline',
                        online: status.online || false,
                        timestamp: Date.now()
                    };
                    
                    // Streaming stats silently - only log errors
                    
                    // Send ONLY to this specific client (not broadcast to all)
                    socket.emit('server-stats', liveStats);
                    
                } catch (err) {
                    console.error(`Stream error for ${streamId}:`, err.message);
                }
            }, 1000); // Stream every 1 second for smooth real-time updates
            
            // Store interval ID on socket so we can clean it up
            if (!socket.streams) socket.streams = {};
            socket.streams[serverId] = streamInterval;
            
            // ================================================
            // START CONSOLE LOG STREAMING (PURE LIVE, NO BUFFERING)
            // ================================================
            // CRITICAL CHANGE: Direct live streaming with NO polling delays
            // When agent emits console data → app.js receives it → immediately broadcast to browser
            // This achieves the same behavior as Start-Process terminal output
            
            if (server.node_id) {
                // REMOTE SERVER: Pull from agent's endpoint on demand, emit immediately
                // No polling interval - instead use a continuous async loop that feeds data instantly
                
                let offset = null;
                let partial = '';
                let streamSequence = 0;
                let isStreaming = false;
                
                // Live stream function - called once, loops internally
                const startLiveStream = async () => {
                    if (isStreaming) return;
                    isStreaming = true;
                    
                    while (socket.connected && socket.rooms.has(`server:${serverId}`) && isStreaming
                           && socket.consoleStreamGenerations[serverId] === streamGeneration) {
                        try {
                            const res = await remoteNodeRequest(
                                server.node_id,
                                'GET',
                                `/servers/${server.id}/console/stream?offset=${offset === null ? 'tail' : offset}`,
                                { timeoutMs: 5000 }
                            );
                            
                            if (!res || typeof res.chunk !== 'string') {
                                // No new data yet, short pause before retry
                                await new Promise(r => setTimeout(r, 100));
                                continue;
                            }
                            
                            if (res.reset) {
                                offset = Number(res.baseOffset) || 0;
                                partial = '';
                            }
                            
                            const nextOffset = Number(res.offset);
                            if (Number.isFinite(nextOffset) && nextOffset >= offset) offset = nextOffset;
                            
                            const pieces = (partial + res.chunk).split(/\r?\n/);
                            partial = pieces.pop() || '';
                            
                            // EMIT EACH LINE IMMEDIATELY - NO BUFFERING
                            for (const rawLine of pieces) {
                                if (!rawLine.trim()) continue;
                                
                                const plainLine = terminalColorParser.stripColors(rawLine);
                                const lineLevel = terminalColorParser.detectLogLevel(plainLine);

                                // Feed join/leave/list lines into the shared player tracker
                                // so the players page updates instantly, without a reload.
                                try { processLogLine(serverId, plainLine); } catch (e) {}

                                // Normalize literal/Minecraft color codes and fall back to
                                // level based ANSI colors so the console is never plain white.
                                socket.emit('console:output', {
                                    serverId: Number(serverId),
                                    sequence: ++streamSequence,
                                    message: terminalColorParser.processLine(rawLine, lineLevel),
                                    plainMessage: plainLine,
                                    level: lineLevel,
                                    source: 'process-stdout',
                                    timestamp: Date.now()
                                });
                            }
                            
                            // CRITICAL: Very short delay before next poll to keep it responsive
                            // This is faster than intervals which batch requests
                            await new Promise(r => setTimeout(r, 50));
                            
                        } catch (err) {
                            if (process.env.DEBUG_CONSOLE_STREAM === '1') {
                                console.warn(`[console-stream] server ${serverId}: ${err.message}`);
                            }
                            // Retry on error with short delay
                            await new Promise(r => setTimeout(r, 100));
                        }
                    }
                    
                    isStreaming = false;
                };
                
                // Start streaming immediately in background - don't await
                startLiveStream().catch(err => console.error(`Stream error: ${err.message}`));
                
                // Store flag so we can stop it on leave-server
                if (!socket.consoleStreams) socket.consoleStreams = {};
                socket.consoleStreams[serverId] = { 
                    stop: () => { isStreaming = false; } 
                };
                
            } else {
                // LOCAL SERVER: Watch file directly - emit immediately on new data
                const logPath = resolveServerPath(serverId) + '/logs/latest.log';
                let lastSize = 0;
                let isWatching = false;
                
                // Get initial file size
                try {
                    if (fs.existsSync(logPath)) {
                        const stat = fs.statSync(logPath);
                        lastSize = stat.size;
                    }
                } catch {}
                
                // Watch file in continuous loop - emit immediately
                const startFileWatch = async () => {
                    if (isWatching) return;
                    isWatching = true;
                    
                    while (socket.connected && socket.rooms.has(`server:${serverId}`) && isWatching
                           && socket.consoleStreamGenerations[serverId] === streamGeneration) {
                        try {
                            if (!fs.existsSync(logPath)) {
                                // Wait and retry if file doesn't exist yet
                                await new Promise(r => setTimeout(r, 100));
                                continue;
                            }
                            
                            const stat = fs.statSync(logPath);
                            if (stat.size > lastSize) {
                                // New content added - read and emit IMMEDIATELY
                                const newBytes = stat.size - lastSize;
                                const fd = fs.openSync(logPath, 'r');
                                const buffer = Buffer.alloc(newBytes);
                                fs.readSync(fd, buffer, 0, newBytes, lastSize);
                                fs.closeSync(fd);
                                
                                const newContent = buffer.toString('utf8');
                                const newLines = newContent.split('\n').filter(line => line.trim());
                                
                                // Emit each line immediately as it's read
                                for (const line of newLines) {
                                    const rawLine = line.replace(/\r$/, '');
                                    if (!rawLine.trim()) continue;
                                    
                                    const plainLine = terminalColorParser.stripColors(rawLine);
                                    const lineLevel = terminalColorParser.detectLogLevel(plainLine);

                                    try { processLogLine(serverId, plainLine); } catch (e) {}

                                    socket.emit('console:output', {
                                        serverId: Number(serverId),
                                        message: terminalColorParser.processLine(rawLine, lineLevel),
                                        plainMessage: plainLine,
                                        level: lineLevel,
                                        source: 'latest.log',
                                        timestamp: Date.now()
                                    });
                                }
                                
                                lastSize = stat.size;
                            }
                            
                            // Very short poll - 50ms keeps responsiveness high
                            await new Promise(r => setTimeout(r, 50));
                            
                        } catch (err) {
                            console.error(`File watch error: ${err.message}`);
                            // Retry with delay
                            await new Promise(r => setTimeout(r, 100));
                        }
                    }
                    
                    isWatching = false;
                };
                
                // Start watching immediately in background
                startFileWatch().catch(err => console.error(`Watch error: ${err.message}`));
                
                // Store control so we can stop it
                if (!socket.consoleStreams) socket.consoleStreams = {};
                socket.consoleStreams[serverId] = { 
                    stop: () => { isWatching = false; } 
                };
            }
            
        } catch (err) {
            console.error('join-server error:', err);
        }
    });
   
    socket.on('leave-server', (serverId) => {
        socket.leave(`server:${serverId}`);
        console.log(`🔌 Socket ${socket.id} left server ${serverId} - stopping live stats stream`);
        
        // Clean up the streaming intervals for this server
        if (socket.streams && socket.streams[serverId]) {
            clearInterval(socket.streams[serverId]);
            delete socket.streams[serverId];
            console.log(`✅ Cleaned up stats stream for server ${serverId}`);
        }
        
        // Stop console streaming loop
        if (socket.consoleStreams && socket.consoleStreams[serverId]) {
            // Call stop function if it exists, otherwise clear interval
            if (typeof socket.consoleStreams[serverId].stop === 'function') {
                socket.consoleStreams[serverId].stop();
            } else if (typeof socket.consoleStreams[serverId] === 'number') {
                clearInterval(socket.consoleStreams[serverId]);
            }
            delete socket.consoleStreams[serverId];
            console.log(`✅ Cleaned up console stream for server ${serverId}`);
        }
    });
    
    // ================================================
    // REQUEST STATS - DISABLED (Using live streaming instead)
    // ================================================
    // Old polling-based approach is replaced by per-client streaming via join-server
    // Do NOT re-enable this handler - it causes duplicate conflicting emissions
    
    // ================================================
    // CONSOLE COMMANDS
    // ================================================
    
    socket.on('console:command', async (payload = {}) => {
        const serverId = Number(payload.serverId);
        const command = typeof payload.command === 'string' ? payload.command.trim() : '';
        try {
            if (!Number.isSafeInteger(serverId) || serverId < 1) throw new Error('Invalid server id');
            if (!command || command.length > 2048 || /[\r\n\u0000]/.test(command)) {
                throw new Error('Command must be a single line of at most 2048 characters');
            }
            const server = await dbGet('SELECT id, node_id FROM servers WHERE id = ?', [serverId]);
            if (!server || !server.node_id) throw new Error('Server not found or no node assigned');
            const result = await sendCommand(serverId, command);
            if (!result.success) throw new Error(result.response || 'Command could not be sent');

            // Do not echo commands into the console UI. The console displays only
            // lines actually written by the agent to servers/<id>/logs/latest.log.
        } catch (err) {
            console.error('Socket command error:', err);
            socket.emit('console:error', {
                serverId: serverId,
                message: 'Failed to execute command: ' + err.message
            });
        }
    });
    
    // ================================================
    // PLAYER MONITORING
    // ================================================
    
    socket.on('request:players', async (serverId) => {
        try {
            const players = await getServerPlayers(serverId);
            socket.emit('players:update', {
                serverId: serverId,
                players: players,
                count: players.length,
                maxPlayers: 20 // Get from server config
            });
        } catch (err) {
            console.error('request:players error:', err);
        }
    });
    
    // ================================================
    // DISCONNECT
    // ================================================
    
    socket.on('disconnect', () => {
        // Client disconnected - clean up all streams
        
        // Clean up all stats streaming intervals for this socket
        if (socket.streams) {
            for (const serverId in socket.streams) {
                clearInterval(socket.streams[serverId]);
            }
            socket.streams = {};
        }
        
        // Stop all console streaming loops
        if (socket.consoleStreams) {
            for (const serverId in socket.consoleStreams) {
                const stream = socket.consoleStreams[serverId];
                // Call stop function if it exists
                if (typeof stream.stop === 'function') {
                    stream.stop();
                } else if (typeof stream === 'number') {
                    clearInterval(stream);
                }
            }
            socket.consoleStreams = {};
        }
    });
});

// ================================================
// HELPER FUNCTIONS FOR SOCKET.IO
// ================================================

// Helper function to get folder size recursively (cross-platform)
// This function calculates the actual size of all files in a folder
function getFolderSizeSync(folderPath) {
    let totalSize = 0;
    let fileCount = 0;
    let dirCount = 0;
    let errorCount = 0;
    
    try {
        if (!fs.existsSync(folderPath)) {
            console.error(`[SIZE] Folder does not exist: ${folderPath}`);
            return 0;
        }
        
        const walk = (dir, depth = 0) => {
            try {
                const files = fs.readdirSync(dir);
                
                for (const file of files) {
                    try {
                        const filePath = path.join(dir, file);
                        const stat = fs.lstatSync(filePath);
                        
                        if (stat.isDirectory()) {
                            dirCount++;
                            // Recursively walk subdirectories
                            walk(filePath, depth + 1);
                        } else if (stat.isFile()) {
                            fileCount++;
                            totalSize += stat.size;
                        }
                    } catch (err) {
                        errorCount++;
                    }
                }
            } catch (err) {
                console.error(`[SIZE] Error reading directory ${dir}:`, err.message);
            }
        };
        
        console.log(`[SIZE] Starting scan of ${folderPath}`);
        walk(folderPath);
        console.log(`[SIZE] Scan complete: ${fileCount} files, ${dirCount} dirs, ${errorCount} errors, total=${totalSize} bytes`);
        
        return Math.max(0, totalSize);
        
    } catch (err) {
        console.error(`[SIZE] CRITICAL ERROR in getFolderSizeSync for ${folderPath}:`, err.message);
        return 0;
    }
}

// Helper function to get disk space info (cross-platform)
// Uses spawnSync with an argument array (no shell), so path values can
// never be interpreted as shell syntax.
function getDiskSpaceSync(folderPath) {
    try {
        const { spawnSync } = require('child_process');
        let totalSpace = 100 * 1024 * 1024 * 1024; // Default 100GB
        let freeSpace = 50 * 1024 * 1024 * 1024;   // Default 50GB free
        const folder = String(folderPath || '');
        if (folder.includes('\0')) return { totalSpace, freeSpace };

        if (process.platform === 'win32') {
            const driveMatch = /^[A-Za-z]:/.exec(folder);
            if (driveMatch) {
                const drive = driveMatch[0];
                const result = spawnSync(
                    'wmic',
                    ['logicaldisk', 'where', `name="${drive}"`, 'get', 'size,freespace', '/value'],
                    { encoding: 'utf-8', timeout: 5000 }
                );
                const output = result && result.stdout ? String(result.stdout) : '';
                const sizeMatch = /Size=(\d+)/.exec(output);
                const freeMatch = /FreeSpace=(\d+)/.exec(output);
                if (sizeMatch && sizeMatch[1]) totalSpace = parseInt(sizeMatch[1]);
                if (freeMatch && freeMatch[1]) freeSpace = parseInt(freeMatch[1]);
            }
        } else {
            // Linux/Mac: Use df with the path as a single argument (no shell)
            const result = spawnSync('df', ['-k', folder], { encoding: 'utf-8', timeout: 5000 });
            const output = result && result.stdout ? String(result.stdout).trim() : '';
            const lines = output.split('\n').filter(Boolean);
            const parts = lines.length ? lines[lines.length - 1].split(/\s+/) : [];
            if (parts.length >= 4) {
                totalSpace = parseInt(parts[1]) * 1024; // Convert to bytes
                freeSpace = parseInt(parts[3]) * 1024;  // Convert to bytes
            }
        }

        return { totalSpace, freeSpace };
    } catch (err) {
        return { totalSpace: 100 * 1024 * 1024 * 1024, freeSpace: 50 * 1024 * 1024 * 1024 };
    }
}

async function getServerStats(serverId) {
    try {
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return { cpu: 0, ram: 0, disk: 0, tps: 0, uptime: 0, players: 0, warning: null };


        if (server.node_id) {
            try {
                // Always try to fetch fresh stats for remote nodes
                const r = await remoteNodeRequest(server.node_id, 'GET', `/servers/${server.id}/stats`, { timeoutMs: 8000 });
                if (r) {
                    // Process the remote response - parse all response fields
                    const cpu = Number(r.cpu ?? r.cpuPercent ?? r.cpu_usage ?? 0) || 0;
                    const ramGb = Number(r.ramGb ?? r.ramUsed ?? r.memoryGb ?? r.ram ?? ((Number(r.memory ?? 0) || 0) / 1024 / 1024 / 1024)) || 0;
                    const ramMax = Number(r.ramMax ?? 0) || 0;
                    const disk = Number(r.diskPercent ?? r.disk_percentage ?? r.disk ?? 0) || 0;
                    const diskUsedMB = Number(r.diskUsedMB ?? 0) || 0;
                    const players = Number(r.players ?? r.playerCount ?? r.onlinePlayers?.length ?? 0) || 0;
                    const playerList = Array.isArray(r.playerList) ? r.playerList : (Array.isArray(r.onlinePlayers) ? r.onlinePlayers : []);
                    const remoteUptime = Number(r.uptime ?? r.uptimeMs ?? 0) || 0;
                    const maxPlayers = Number(r.maxPlayers ?? 20) || 20;
                    
                    // CRITICAL FIX: Use persistent uptime tracking via remote node files
                    // The remote node persists .server.starttime file so uptime survives agent restarts
                    if (!global.localUptimeTracker) global.localUptimeTracker = {};
                    if (!global.localUptimeTracker[serverId]) {
                        global.localUptimeTracker[serverId] = {
                            startTime: null,
                            lastRemoteUptime: remoteUptime,
                            lastStatus: 'offline',
                            receivedTime: Date.now()
                        };
                    }
                    
                    const tracker = global.localUptimeTracker[serverId];
                    
                    // CRITICAL: Check actual server status
                    const serverStatus = await getServerStatus(serverId);
                    const isLive = serverStatus && (serverStatus.status === 'running' || serverStatus.status === 'starting');
                    
                    // If server is live (running or starting), use the uptime from remote node (which is persisted)
                    // The remote node already has the correct uptime calculation from persistent files
                    let uptime = 0;
                    
                    if (isLive && remoteUptime > 0) {
                        // Server is live - use the uptime from remote node
                        // This uptime comes from persistent .server.starttime file
                        uptime = remoteUptime;
                        
                        // Initialize our tracker if needed
                        if (!tracker.startTime) {
                            console.log(`✅ Server ${serverId} detected as running with uptime ${Math.floor(remoteUptime/1000)}s from remote node`);
                            tracker.startTime = Date.now() - remoteUptime; // Back-calculate start time
                            tracker.lastStatus = 'running';
                        } else if (tracker.lastStatus === 'offline') {
                            // Server was offline, now running
                            console.log(`🔄 Server ${serverId} detected as running (was offline). Using remote uptime.`);
                            tracker.startTime = Date.now() - remoteUptime;
                            tracker.lastStatus = 'running';
                        } else if (remoteUptime < (tracker.lastRemoteUptime - 10000)) {
                            // Server restarted (uptime dropped significantly)
                            console.log(`🔄 Server ${serverId} detected restart (remote uptime dropped: ${tracker.lastRemoteUptime}ms -> ${remoteUptime}ms).`);
                            tracker.startTime = Date.now() - remoteUptime;
                        }
                    } else {
                        // Server is NOT running - reset tracker and return 0 uptime
                        if (tracker.lastStatus === 'running') {
                            console.log(`⏹️ Server ${serverId} stopped. Resetting uptime to 0.`);
                        }
                        tracker.startTime = null;
                        tracker.lastStatus = 'offline';
                        uptime = 0;
                    }
                    
                    tracker.lastRemoteUptime = remoteUptime;
                    tracker.receivedTime = Date.now();
                    
                    const snapshot = {
                        cpu,
                        ram: ramGb,
                        disk,
                        diskUsedMB,  // Add actual used MB
                        tps: (r.tps === null || r.tps === undefined) ? null : Number(r.tps),
                        uptime,  // Use remote uptime which is persistent
                        uptimeSeconds: Math.floor(uptime/1000),
                        players,
                        maxPlayers,
                        playerList,
                        warning: r.warning || null,
                        ramUsed: Number(r.ramUsed ?? ramGb).toFixed(2),
                        ramMax: Number(server.ram/1024).toFixed(2),
                        diskPercentage: disk.toFixed(1)
                    };
                    
                    // Cache it
                    global.remoteServerStats = global.remoteServerStats || {};
                    global.remoteServerStats[serverId] = snapshot;
                    return snapshot;
                }
            } catch (err) {
                console.debug(`[getServerStats] Failed to fetch remote stats for server ${serverId}:`, err.message);
            }
            
            // Fallback to cached data if available
            const cached = global.remoteServerStats?.[serverId];
            if (cached) return cached;
            
            // Return empty stats if nothing is available
            return { cpu: 0, ram: 0, disk: 0, tps: 0, uptime: 0, players: 0, warning: null };
        }
        
        // Local server stats
        const serverDir = resolveServerPath(serverId);
        let cpuUsage = 0, memUsage = 0, diskUsage = 0;
        let warning = null;
        
        // Try to get CPU/RAM from process if available
        const process = global.serverProcesses[serverId];
        if (process && process.pid) {
            try {
                const stats = await pidusage(process.pid);
                cpuUsage = stats.cpu || 0;
                memUsage = stats.memory || 0;
            } catch (err) {
                // Process might not be running, that's ok
            }
        }
        
        // Calculate disk usage - NO CACHING for live streaming (get real-time values)
        try {
            // Check if server folder exists
            if (!fs.existsSync(serverDir)) {
                console.warn(`⚠️ Server folder missing for server ${serverId}: ${serverDir}`);
                diskUsage = 0;
            } else {
                // Calculate folder size silently
                const serverFolderSizeBytes = getFolderSizeSync(serverDir);
                
                if (serverFolderSizeBytes === 0) {
                    console.warn(`⚠️ [DISK] WARNING: Server ${serverId} folder size is 0 bytes! May be empty or inaccessible`);
                }
                
                const serverFolderSizeMB = serverFolderSizeBytes / (1024 * 1024);
                // Ensure disk allocation is always valid (minimum 512 MB, default 10GB)
                const allocatedDiskMB = Math.max(512, server.disk || 10240);
                
                diskUsage = allocatedDiskMB > 0 ? (serverFolderSizeMB / allocatedDiskMB) * 100 : 0;
                diskUsage = Math.min(Math.max(diskUsage, 0), 100);
                
                // Only log disk warnings if usage is high
                if (diskUsage > 90) {
                    console.warn(`🔴 [DISK] Server ${serverId}: CRITICAL USAGE ${diskUsage.toFixed(2)}% (${serverFolderSizeMB.toFixed(2)}MB/${allocatedDiskMB}MB)`);
                }
            }
        } catch (err) {
            console.error(`[DISK ERROR] Disk calculation failed for server ${serverId}:`, err.message);
            diskUsage = 0;
        }
        
        // CHECK RESOURCE LIMITS
        const ramGB = memUsage / (1024 * 1024 * 1024);
        const allocatedRamMB = server.ram || 8192;
        const allocatedRamGB = allocatedRamMB / 1024;
        
        if (ramGB > (allocatedRamGB * 0.9)) {
            warning = `⚠️ HIGH RAM USAGE: ${ramGB.toFixed(2)}GB/${allocatedRamGB.toFixed(2)}GB (${((ramGB/allocatedRamGB)*100).toFixed(1)}%)`;
        }
        
        if (cpuUsage > 95) {
            warning = `⚠️ HIGH CPU USAGE: ${cpuUsage.toFixed(1)}%`;
        }
        
        if (diskUsage > 90) {
            warning = `⚠️ CRITICAL DISK USAGE: ${diskUsage.toFixed(1)}% - Cannot upload more files!`;
        }
        
        // Get start time - ensure consistency and persistence
        // CRITICAL: Always use the ACTUAL current start time from memory/file, not cached old values
        let startTime = serverStartTimes[serverId];
        if (!startTime) {
            startTime = loadServerStartTime(serverId);
            if (startTime) {
                serverStartTimes[serverId] = startTime; // Cache in memory
                // Start time loaded silently
            } else {
                // If no start time available, use NOW (server just started or was already running)
                startTime = serverStartTimes[serverId] = Date.now();
                console.warn(`⚠️ No start time for server ${serverId}, using current time as reference.`);
            }
        }
        
        // SANITY CHECK: If uptime is way too high (more than 90 days), it's definitely stale
        // This catches old .server.starttime files that weren't updated
        const calculatedUptime = Date.now() - startTime;
        if (calculatedUptime > 90 * 24 * 60 * 60 * 1000) {  // 90 days
            console.warn(`⚠️ STALE UPTIME DETECTED: ${calculatedUptime}ms (${Math.floor(calculatedUptime/1000/60/60/24)} days)`);
            console.warn(`⚠️ Resetting start time to NOW`);
            startTime = serverStartTimes[serverId] = Date.now();
            saveServerStartTime(serverId, startTime);
        }
        
        // Get player count from onlinePlayers array
        let players = 0;
        if (onlinePlayers[serverId] && Array.isArray(onlinePlayers[serverId])) {
            players = onlinePlayers[serverId].length;
        }
        
        // CRITICAL FIX: Only return uptime if server is actually running
        // Otherwise return 0 uptime for stopped servers
        const isRunning = await isServerRunning(serverId);
        const uptime = isRunning ? (Date.now() - startTime) : 0;
        const uptimeSeconds = isRunning ? Math.floor((Date.now() - startTime) / 1000) : 0;
        
        // Calculate diskUsedMB from the percentage
        const allocatedDiskMB = Math.max(512, server.disk || 10240);
        const diskUsedMB = (diskUsage / 100) * allocatedDiskMB;
        
        // Stats calculated silently - only log on errors or if explicitly enabled
        
        return {
            cpu: isRunning ? cpuUsage : 0,
            ram: isRunning ? (memUsage / (1024 * 1024 * 1024)) : 0, // Convert to GB
            disk: diskUsage, // Percentage 0-100 (disk stays same even if stopped)
            diskUsedMB: diskUsedMB, // Actual MB used
            tps: 20, // Default TPS
            uptime: uptime, // Time elapsed in milliseconds (ONLY if running)
            uptimeSeconds: uptimeSeconds, // For reference (ONLY if running)
            players: isRunning ? players : 0,
            warning: warning,
            ramUsed: isRunning ? ramGB.toFixed(2) : '0',
            ramMax: allocatedRamGB.toFixed(2),
            diskPercentage: diskUsage.toFixed(1)
        };
    } catch (err) {
        console.error('getServerStats error:', err);
        return { cpu: 0, ram: 0, disk: 0, tps: 0, uptime: 0, players: 0, warning: null };
    }
}

async function getServerStatus(serverId) {
    try {
        const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
        if (!server) return { status: 'stopped', online: false };
        
        let isRunning = false;
        let actualStatus = 'stopped';
        
        if (server.node_id) {
            // FOR REMOTE SERVERS: Check if node is fresh (alive) first
            try {
                const node = await dbGet('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
                const nodeIsFresh = node?.last_heartbeat && (Date.now() - new Date(node.last_heartbeat).getTime()) <= NODE_HEARTBEAT_TIMEOUT_MS;
                
                if (!nodeIsFresh) {
                    // Node heartbeat stale - but try ONE verification attempt before giving up
                    console.warn(`⚠️ Server ${serverId} node (${server.node_id}) heartbeat stale - attempting verification...`);
                    
                    try {
                        // Try to get fresh stats even though heartbeat is old
                        const stats = await remoteNodeRequest(server.node_id, 'GET', `/servers/${server.id}/stats`, { timeoutMs: 3000 });
                        if (stats && stats.status) {
                            actualStatus = ['running', 'starting', 'stopped'].includes(stats.status) ? stats.status : 'stopped';
                            isRunning = actualStatus === 'running';
                            console.log(`✅ Server ${serverId} verified via direct request: ${actualStatus}`);
                        } else {
                            actualStatus = 'stopped';
                            isRunning = false;
                            console.log(`❌ Server ${serverId} node not responding - marked as stopped`);
                        }
                    } catch (verifyErr) {
                        // Verification attempt failed - node is truly offline
                        actualStatus = 'stopped';
                        isRunning = false;
                        console.log(`❌ Server ${serverId} verification failed: ${verifyErr.message} - marked as stopped`);
                    }
                } else {
                    // Node is fresh - verify against live daemon stats (cached 1s daemon-side, cheap)
                    // so "starting" → "running" transitions reach the UI without waiting for a viewer join.
                    try {
                        const stats = await remoteNodeRequest(server.node_id, 'GET', `/servers/${server.id}/stats`, { timeoutMs: 3000 });
                        if (stats && stats.status) {
                            actualStatus = ['running', 'starting', 'stopped'].includes(stats.status) ? stats.status : 'stopped';
                        } else {
                            actualStatus = ['running', 'starting', 'stopped'].includes(server.status) ? server.status : 'stopped';
                        }
                    } catch (statsErr) {
                        actualStatus = ['running', 'starting', 'stopped'].includes(server.status) ? server.status : 'stopped';
                    }
                    isRunning = actualStatus === 'running';
                }
            } catch (err) {
                console.warn(`Failed to check node status for server ${serverId}:`, err.message);
                isRunning = false;
                actualStatus = 'stopped';
            }
        } else {
            // FOR LOCAL SERVERS: Use standard check
            isRunning = await isServerRunning(serverId);
            actualStatus = isRunning ? 'running' : 'stopped';
        }
        
        // CRITICAL FIX: If database status is wrong, update it
        const dbStatus = server.status || 'stopped';
        if (dbStatus !== actualStatus) {
            console.warn(`🔧 STATUS MISMATCH: DB says '${dbStatus}' but actual is '${actualStatus}' - correcting...`);
            await dbRun('UPDATE servers SET status = ? WHERE id = ?', [actualStatus, serverId]);
        }
        
        // Return consistent status: 'running' or 'stopped' (not 'online')
        return {
            status: actualStatus,
            online: isRunning,
            message: isRunning ? 'Server is running' : 'Server is offline'
        };
    } catch (err) {
        console.error('getServerStatus error:', err);
        return { status: 'stopped', online: false };
    }
}

async function getServerPlayers(serverId) {
    const server = await dbGet('SELECT * FROM servers WHERE id = ?', [serverId]);
    if (server?.node_id) return global.remoteServerStats?.[serverId]?.playerList || [];
    return onlinePlayers[serverId] || [];
}

// Remote server live-stat cache. The node agent owns the real process/filesystem; the panel only stores the latest snapshot.
global.remoteServerStats = global.remoteServerStats || {};
async function refreshRemoteServerStats(server) {
  if (!server?.node_id) return null;
  try {
    const r = await remoteNodeRequest(server.node_id, 'GET', `/servers/${server.id}/stats`, { timeoutMs: 8000 });
    const cpu = Number(r.cpu ?? r.cpuPercent ?? r.cpu_usage ?? 0) || 0;
    const ramGb = Number(r.ramGb ?? r.memoryGb ?? r.ram ?? ((Number(r.memory ?? 0) || 0) / 1024 / 1024 / 1024)) || 0;
    const disk = Number(r.diskPercent ?? r.disk_percentage ?? r.disk ?? 0) || 0;
    const players = Number(r.players ?? r.playerCount ?? r.onlinePlayers?.length ?? 0) || 0;
    const playerList = Array.isArray(r.playerList) ? r.playerList : (Array.isArray(r.onlinePlayers) ? r.onlinePlayers : []);
    const uptime = Number(r.uptime ?? r.uptimeMs ?? 0) || 0;
    const maxPlayers = Number(r.maxPlayers ?? 20) || 20;
    const snapshot = { cpu, ram: ramGb, disk, tps: (r.tps === null || r.tps === undefined) ? null : Number(r.tps), uptime, uptimeSeconds: Math.floor(uptime/1000), players, maxPlayers, playerList, warning: r.warning || null, ramUsed: Number(r.ramUsed ?? ramGb).toFixed(2), ramMax: Number(server.ram/1024).toFixed(2), diskPercentage: disk.toFixed(1) };
    global.remoteServerStats[server.id] = snapshot;
    
    // Update database if status changed
    const remoteStatus = ['running', 'starting', 'stopped'].includes(r.status) ? r.status : server.status;
    if (server.status !== remoteStatus) {
      console.log(`[refreshRemoteServerStats] Status change for server ${server.id}: ${server.status} -> ${remoteStatus}`);
      await dbRun('UPDATE servers SET status=? WHERE id=? AND node_id=?', [remoteStatus, server.id, server.node_id]);
    }
    
    // *** NO BROADCAST HERE - let socket.on('join-server') streaming handle the emission ***
    // This function just fetches and caches remote stats, doesn't broadcast
    return snapshot;
  } catch (err) {
    console.error(`[remote-stats] server ${server.id}:`, err.message);
    // If we can't fetch stats from the remote daemon, mark server as offline
    if (server.status === 'running') {
      console.warn(`[remote-stats] Marking server ${server.id} as stopped due to unreachable daemon`);
      await dbRun('UPDATE servers SET status=? WHERE id=? AND node_id=?', ['stopped', server.id, server.node_id]);
    }
    return global.remoteServerStats?.[server.id] || null;
  }
}
// *** REMOVED: 5-second remote stats polling interval - now using live streaming on socket connection ***
// Remote stats will be fetched on-demand when clients connect to watch a server

// Global broadcast function for all connected clients
// *** DEPRECATED - no longer used ***
// All stats emission now happens via per-client streaming in socket.on('join-server')
function broadcastServerEvent(serverId, eventName, data) {
    io.to(`server:${serverId}`).emit(eventName, {
        ...data,
        serverId: serverId,
        timestamp: new Date()
    });
    // NO CACHING - each client gets fresh stream, no global cache
}

// *** REMOVED: 2-second interval broadcast - now using live socket.io streaming instead ***
// Stats are now calculated and sent ONLY when clients are connected and watching a server
// This eliminates the constant background calculation overhead

// *** REMOVED: 5-second player query interval - now using on-demand queries on socket connection ***
// Players will be queried when clients connect and updated via live streaming
// ================================================
// ERROR HANDLERS
// ================================================
// 404 handler
// ================================================
// Reconnect to running servers on panel startup
async function reconnectToRunningServers() {
  // Remote-only architecture: No local server processes to reconnect to
  // All servers are managed through remote nodes
  console.log('ℹ️ [Remote-Only] Skipping local server reconnection - all servers managed by remote nodes');
}

// ================================================
// MULTI-NODE SYSTEM (additive migration; existing data/features retained)
// ================================================
const crypto = require('crypto');
const NODE_PANEL_VERSION = process.env.PANEL_VERSION || '1.0.0';
const NODE_HEARTBEAT_TIMEOUT_MS = Number(process.env.NODE_HEARTBEAT_TIMEOUT_MS || 90000);
const NODE_COMMAND_TIMEOUT_MS = Number(process.env.NODE_COMMAND_TIMEOUT_MS || 60000);
let localNodeId = 1;
const nodeRateState = new Map();
// All servers are now remote - no local node checking needed
function nodeTokenHash(token) { return crypto.createHash('sha256').update(String(token)).digest('hex'); }
function safeEqual(a, b) { const x = Buffer.from(String(a)); const y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); }
function nodeText(v, max=120) { if (typeof v !== 'string') throw new Error('Expected text'); const s=v.trim(); if (!s || s.length>max) throw new Error(`Text must be 1-${max} characters`); return s; }
function nodeInt(v, min, max, name) { const n=Number(v); if (!Number.isSafeInteger(n)||n<min||n>max) throw new Error(`${name} must be an integer between ${min} and ${max}`); return n; }
function nodeRanges(input) {
  if (!Array.isArray(input) || !input.length || input.length>64) throw new Error('portRanges must be a non-empty array of ranges');
  const ranges=input.map(r=>({start:nodeInt(r.start,1024,65535,'range start'),end:nodeInt(r.end,1024,65535,'range end')}));
  for (const r of ranges) if(r.start>r.end) throw new Error('Range start must be <= end');
  const sorted=[...ranges].sort((a,b)=>a.start-b.start);
  for(let i=1;i<sorted.length;i++) if(sorted[i].start<=sorted[i-1].end) throw new Error('Port ranges cannot overlap');
  return sorted;
}
async function nodeMigrate() {
  // Node migration starting silently...
  
  await dbRun(`CREATE TABLE IF NOT EXISTS nodes (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT DEFAULT '', location TEXT DEFAULT '', country_code TEXT DEFAULT '',
    ip_address TEXT NOT NULL, ip_alias TEXT DEFAULT '', daemon_port INTEGER NOT NULL DEFAULT 8787, port_ranges TEXT NOT NULL DEFAULT '[]',
    ram_mb INTEGER NOT NULL, cpu_cores REAL NOT NULL, disk_mb INTEGER NOT NULL, token_hash TEXT NOT NULL UNIQUE,
    enabled INTEGER NOT NULL DEFAULT 1, status TEXT NOT NULL DEFAULT 'offline', last_heartbeat TEXT, daemon_version TEXT, nodejs_version TEXT,
    os_info TEXT, resources_json TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP)`);
  // Nodes table created or verified
  
  await dbRun(`CREATE TABLE IF NOT EXISTS node_port_allocations (
    id INTEGER PRIMARY KEY AUTOINCREMENT, node_id INTEGER NOT NULL, port INTEGER NOT NULL, server_id INTEGER,
    protocol TEXT NOT NULL DEFAULT 'tcp', created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(node_id,port), FOREIGN KEY(node_id) REFERENCES nodes(id) ON DELETE CASCADE)`);
  await dbRun(`CREATE TABLE IF NOT EXISTS node_commands (
    id INTEGER PRIMARY KEY AUTOINCREMENT, node_id INTEGER NOT NULL, server_id INTEGER, action TEXT NOT NULL, payload TEXT NOT NULL DEFAULT '{}',
    status TEXT NOT NULL DEFAULT 'queued', result_json TEXT, error TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(node_id) REFERENCES nodes(id) ON DELETE CASCADE)`);
  await dbRun(`CREATE TABLE IF NOT EXISTS node_audit_log (id INTEGER PRIMARY KEY AUTOINCREMENT,node_id INTEGER,actor_user_id INTEGER,action TEXT NOT NULL,details TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP)`);
  const cols=await dbAll('PRAGMA table_info(servers)');
  if(!cols.some(c=>c.name==='node_id')) await dbRun('ALTER TABLE servers ADD COLUMN node_id INTEGER');
  if(!cols.some(c=>c.name==='description')) {
    // Adding description column to servers table
    await dbRun('ALTER TABLE servers ADD COLUMN description TEXT DEFAULT ""');
  }
  await dbRun('CREATE INDEX IF NOT EXISTS idx_servers_node_id ON servers(node_id)');
  await dbRun('CREATE INDEX IF NOT EXISTS idx_node_commands_status ON node_commands(node_id,status,id)');
  
  // Resource limits (ram, cpu, disk) are now stored in the database directly.
  // No .ram_mb/.disk_mb files are created.
  
  // Add missing columns to nodes table if they don't exist
  const nodeCols=await dbAll('PRAGMA table_info(nodes)');
  // Migration columns checked silently
  
  try {
    if(!nodeCols.some(c=>c.name==='token')) {
      // Token column added
      await dbRun('ALTER TABLE nodes ADD COLUMN token TEXT');
    }
    if(!nodeCols.some(c=>c.name==='description')) {
      // Description column added
      await dbRun('ALTER TABLE nodes ADD COLUMN description TEXT DEFAULT ""');
    }
    if(!nodeCols.some(c=>c.name==='location')) {
      // Location column added
      await dbRun('ALTER TABLE nodes ADD COLUMN location TEXT DEFAULT ""');
    }
    if(!nodeCols.some(c=>c.name==='country_code')) {
      // Country code column added
      await dbRun('ALTER TABLE nodes ADD COLUMN country_code TEXT DEFAULT ""');
    }
    if(!nodeCols.some(c=>c.name==='ip_alias')) {
      // IP alias column added
      await dbRun('ALTER TABLE nodes ADD COLUMN ip_alias TEXT DEFAULT ""');
    }
    if(!nodeCols.some(c=>c.name==='daemon_version')) {
      // Daemon version column added
      await dbRun('ALTER TABLE nodes ADD COLUMN daemon_version TEXT');
    }
    if(!nodeCols.some(c=>c.name==='nodejs_version')) {
      // Node.js version column added
      await dbRun('ALTER TABLE nodes ADD COLUMN nodejs_version TEXT');
    }
    if(!nodeCols.some(c=>c.name==='os_info')) {
      // OS info column added
      await dbRun('ALTER TABLE nodes ADD COLUMN os_info TEXT');
    }
    if(!nodeCols.some(c=>c.name==='resources_json')) {
      // Resources JSON column added
      await dbRun('ALTER TABLE nodes ADD COLUMN resources_json TEXT');
    }
    // All nodes table columns verified

  } catch (err) {
    console.error(`❌ [Migration] Error adding columns to nodes table:`, err.message);
    throw err;
  }
}
async function getNodeRecord(nodeId) {
  const node = await dbGet('SELECT * FROM nodes WHERE id=?', [Number(nodeId)]);
  if (!node) throw new Error('Node not found');
  if (!node.enabled) throw new Error('Node is disabled');
  return node;
}
function nodeIsFresh(node) {
  if (!node?.last_heartbeat) return false;
  const ts = Date.parse(node.last_heartbeat);
  return Number.isFinite(ts) && (Date.now() - ts) <= NODE_HEARTBEAT_TIMEOUT_MS;
}
// Maps in-flight node command ids to client operation ids for live progress
const commandOpMap = new Map();
async function queueNodeAction(nodeId, serverId, action, payload = {}) {
  const node = await getNodeRecord(nodeId);
  if (!nodeIsFresh(node) || node.status !== 'online') throw new Error(`Node "${node.name}" is offline or heartbeat is stale`);
  const allowed = new Set(['create','start','stop','restart','reinstall','delete','stats','logs','player-list','player-action','plugin-list','file-list','file-read','file-write','file-delete','file-upload','file-pull','file-create','file-rename','file-zip','file-unzip','file-bulk-zip','file-extract','file-download','console-command','plugin-install','plugin-delete','plugin-upload','world-list','world-delete','world-upload','world-install','world-rename','world-switch','backup-delete','backup-create','restore-backup','server-backup-delete','properties-read','properties-save','properties-reset']);
  if (!allowed.has(action)) throw new Error(`Unsupported node action: ${action}`);
  const result = await dbRun('INSERT INTO node_commands(node_id,server_id,action,payload) VALUES(?,?,?,?)',[nodeId,serverId||null,action,JSON.stringify(payload)]);
  io.to(`node:${nodeId}`).emit('node-command-queued',{id:result.lastID,serverId,action});
  return result.lastID;
}
async function getNodeCommand(commandId, nodeId = null) {
  const sql = nodeId == null ? 'SELECT * FROM node_commands WHERE id=?' : 'SELECT * FROM node_commands WHERE id=? AND node_id=?';
  const row = await dbGet(sql, nodeId == null ? [commandId] : [commandId,nodeId]);
  if (!row) return null;
  let result = null; try { result = JSON.parse(row.result_json || 'null'); } catch { result = null; }
  return { ...row, result };
}
async function waitForNodeCommand(nodeId, commandId, timeoutMs = NODE_COMMAND_TIMEOUT_MS) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    const cmd = await getNodeCommand(commandId,nodeId);
    if (!cmd) throw new Error('Remote command disappeared');
    if (cmd.status === 'completed') return cmd;
    if (cmd.status === 'failed') throw new Error(cmd.error || `Remote ${cmd.action} failed`);
    await new Promise(resolve => setTimeout(resolve,500));
  }
  throw new Error(`Remote command timed out after ${Math.round(timeoutMs/1000)} seconds`);
}
async function remoteNodeRequest(nodeId, method, route, options = {}) {
  const node = await getNodeRecord(nodeId);
  if (!nodeIsFresh(node)) throw new Error(`Node "${node.name}" is offline or heartbeat is stale`);
  if (!node.token) throw new Error('Remote node token is not configured. Reset the node token and install the new agent configuration.');
  const timeoutMs = Number(options.timeoutMs || 15000);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const target = `http://${node.ip_address}:${node.daemon_port}${route.startsWith('/') ? route : `/${route}`}`;
    const headers = {'Accept':'application/json, text/plain, */*','User-Agent':`MinecraftPanel/${NODE_PANEL_VERSION}`,'Authorization':`Bearer ${node.token}`,'x-daemon-token':node.token,...(options.headers||{})};
    const response = await fetch(target,{method,headers,body:options.body,signal:controller.signal});
    const text = await response.text(); let data = null; try { data = text ? JSON.parse(text) : null; } catch { data = text; }
    if (!response.ok) { const err = new Error(data?.error || data?.message || `Remote node returned HTTP ${response.status}`); err.status=response.status; err.data=data; throw err; }
    return data;
  } catch (err) { if (err.name === 'AbortError') throw new Error(`Remote node request timed out after ${Math.round(timeoutMs/1000)} seconds`); throw err; }
  finally { clearTimeout(timer); }
}
function normalizeRemoteFiles(data,currentPath='/') {
  const raw = Array.isArray(data) ? data : (data?.files || data?.entries || data?.items || data?.data || []);
  if (!Array.isArray(raw)) return [];
  return raw.map(item => { const name=String(item.name||item.filename||item.fileName||path.basename(item.path||'')); const isDirectory=Boolean(item.isDirectory ?? item.directory ?? item.is_dir ?? item.type==='directory'); const itemPath=item.path || `${currentPath==='/'?'':currentPath}/${name}`; return {name,path:itemPath.startsWith('/')?itemPath:`/${itemPath}`,isDirectory,size:isDirectory?'-':(item.sizeFormatted||item.size||'0 Bytes'),modified:item.modified||item.modifiedAt||item.mtime||item.updatedAt||null}; }).filter(item=>item.name&&item.name!=='.'&&item.name!=='..');
}
async function remoteCommand(nodeId,serverId,action,payload={},timeoutMs=NODE_COMMAND_TIMEOUT_MS) { const commandId=await queueNodeAction(nodeId,serverId,action,payload); return waitForNodeCommand(nodeId,commandId,timeoutMs); }
function extractRemoteFileContent(result) { const value=result?.content ?? result?.text ?? result?.data?.content ?? result?.data?.text ?? result?.file?.content; return typeof value==='string'?value:''; }
function extractRemoteDownload(result) { const base64=result?.base64 ?? result?.fileData ?? result?.data?.base64 ?? result?.data?.fileData; if(!base64||typeof base64!=='string') return null; return Buffer.from(base64,'base64'); }
function requireNodeAgent(req,res,next) {
  const auth=String(req.headers.authorization||''); const bearer=auth.match(/^Bearer\s+(.+)$/i)?.[1]; const supplied=bearer||req.headers['x-daemon-token'];
  if(!supplied) return res.status(401).json({error:'Bearer token required'});
  dbGet('SELECT * FROM nodes WHERE id=? AND token_hash=? AND enabled=1',[Number(req.params.nodeId),nodeTokenHash(supplied)]).then(node=>{ if(!node) return res.status(401).json({error:'Invalid node credentials'}); req.node=node; next(); }).catch(err=>{console.error('[nodes] auth failure',err);res.status(500).json({error:'Authentication error'});});
}

function nodeError(res,err,status=400) { console.error('[multi-node]',err); return res.status(status).json({error:err.message||'Request failed'}); }

// Admin node CRUD. Token is displayed only once at creation; only its SHA-256 hash is stored.
app.get('/api/nodes', async (req,res)=>{ 
    console.log('[API] GET /api/nodes called');
    try { 
        // Check authentication
        if (!req.session?.user) {
            console.log('[API] Not authenticated');
            return res.status(401).json({ error: 'Not authenticated' });
        }
        
        if (req.session.user.role !== 'admin') {
            console.log('[API] Not admin:', req.session.user.username);
            return res.status(403).json({ error: 'Admin required' });
        }
        
        const rows=await dbAll(`SELECT id,name,description,location,country_code,ip_address,ip_alias,daemon_port,port_ranges,ram_mb,cpu_cores,disk_mb,enabled,status,last_heartbeat,daemon_version,nodejs_version,os_info,resources_json,created_at,updated_at FROM nodes ORDER BY id`); 
        
        // Get server count for each node and recalculate status
        const nodesWithCounts = await Promise.all(rows.map(async (n) => {
            const serverCount = await dbGet(`SELECT COUNT(*) as count FROM servers WHERE node_id = ?`, [n.id]);
            // Recalculate status based on last_heartbeat
            const now = Date.now();
            const lastHeartbeat = n.last_heartbeat ? new Date(n.last_heartbeat).getTime() : null;
            const elapsed = lastHeartbeat ? now - lastHeartbeat : Infinity;
            const stale = !lastHeartbeat || elapsed > NODE_HEARTBEAT_TIMEOUT_MS;
            
            // Debug logging
            if (n.name === 'Local Node') {
                console.log(`[API] Local Node check: last_heartbeat="${n.last_heartbeat}", elapsed=${elapsed}ms, stale=${stale}, timeout=${NODE_HEARTBEAT_TIMEOUT_MS}ms`);
            }
            
            const actualStatus = stale ? 'offline' : 'online';
            return {
                ...n,
                status: actualStatus,
                server_count: serverCount?.count || 0,
                port_ranges: JSON.parse(n.port_ranges||'[]'),
                resources: JSON.parse(n.resources_json||'null')
            };
        }));
        
        res.json({nodes: nodesWithCounts}); 
    } catch(e){
        console.error('[API] Error in /api/nodes:', e);
        res.status(500).json({error: e.message});
    } 
});
app.post('/api/nodes', requireAdmin, async (req,res)=>{ try {
 const b=req.body||{}, name=nodeText(b.name,80), ip=nodeText(b.ipAddress||b.ip_address,253);
 if(net.isIP(ip)!==4 && net.isIP(ip)!==6 && !/^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/i.test(ip)) throw new Error('Invalid IP address or hostname');
 const ranges=nodeRanges(b.portRanges||[{start:25565,end:25665}]); const cpuCores=Number(b.cpuCores||b.cpu_cores); if(Number.isFinite(cpuCores)&&(cpuCores<=0||cpuCores>4096)) throw new Error('cpuCores must be > 0 and <= 4096'); const token=crypto.randomBytes(32).toString('base64url');
 // Properly handle ramMb and diskMb with defaults
 const ramMb = (b.ramMb || b.ram_mb) ? nodeInt(b.ramMb||b.ram_mb,128,1048576,'ramMb') : 8192; // Default 8GB
 const diskMb = (b.diskMb || b.disk_mb) ? nodeInt(b.diskMb||b.disk_mb,256,104857600,'diskMb') : 102400; // Default 100GB
 const result=await dbRun(`INSERT INTO nodes(name,description,location,country_code,ip_address,ip_alias,daemon_port,port_ranges,ram_mb,cpu_cores,disk_mb,token_hash,token) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`,[name,String(b.description||'').slice(0,1000),String(b.location||'').slice(0,120),String(b.countryCode||b.country_code||'').toUpperCase().slice(0,2),ip,String(b.ipAlias||b.ip_alias||'').slice(0,253),nodeInt(b.daemonPort||8787,1,65535,'daemonPort'),JSON.stringify(ranges),ramMb,Number.isFinite(cpuCores)?cpuCores:1,diskMb,nodeTokenHash(token),token]);
 await dbRun('INSERT INTO node_audit_log(node_id,actor_user_id,action,details) VALUES(?,?,?,?)',[result.lastID,req.session.user.id,'node.create',JSON.stringify({name,ip})]);
 res.status(201).json({node:await dbGet('SELECT id,name,ip_address,daemon_port FROM nodes WHERE id=?',[result.lastID]),token,warning:'Save this token now. It cannot be retrieved later.'});
 } catch(e){nodeError(res,e,/UNIQUE/.test(e.message)?409:400);} });
app.get('/api/nodes/:id', requireAdmin, async(req,res)=>{ try { const n=await dbGet('SELECT * FROM nodes WHERE id=?',[nodeInt(req.params.id,1,2147483647,'id')]); if(!n)return res.status(404).json({error:'Node not found'}); 
    
    // Recalculate status based on last_heartbeat (same as in /api/nodes list endpoint)
    const now = Date.now();
    const lastHeartbeat = n.last_heartbeat ? new Date(n.last_heartbeat).getTime() : null;
    const elapsed = lastHeartbeat ? now - lastHeartbeat : Infinity;
    const stale = !lastHeartbeat || elapsed > NODE_HEARTBEAT_TIMEOUT_MS;
    const actualStatus = stale ? 'offline' : 'online';
    
    const ports=await dbAll('SELECT port,server_id,protocol FROM node_port_allocations WHERE node_id=? ORDER BY port',[n.id]); 
    const servers=await dbAll('SELECT id,name,ram,cpu,disk,port,status,server_type,version FROM servers WHERE node_id=? ORDER BY id',[n.id]); 
    res.json({node:{...n,status:actualStatus,token_hash:undefined,port_ranges:JSON.parse(n.port_ranges||'[]'),resources:JSON.parse(n.resources_json||'null')},ports,servers,availablePorts:await getNodeAvailablePorts(n.id)}); }catch(e){nodeError(res,e,500);} });
app.patch('/api/nodes/:id', requireAdmin, async(req,res)=>{ 
  try { 
    const id=nodeInt(req.params.id,1,2147483647,'id');
    const old=await dbGet('SELECT * FROM nodes WHERE id=?',[id]); 
    if(!old)return res.status(404).json({error:'Node not found'}); 
    
    // First, ensure all required columns exist
    const cols = await dbAll('PRAGMA table_info(nodes)');
    const colNames = cols.map(c => c.name);
    const requiredCols = ['description', 'location', 'country_code', 'ip_alias', 'daemon_version', 'nodejs_version', 'os_info', 'resources_json'];
    
    for (const col of requiredCols) {
      if (!colNames.includes(col)) {
        console.log(`[PATCH /api/nodes] Adding missing column: ${col}`);
        try {
          if (col === 'daemon_version' || col === 'nodejs_version' || col === 'os_info' || col === 'resources_json') {
            await dbRun(`ALTER TABLE nodes ADD COLUMN ${col} TEXT`);
          } else {
            await dbRun(`ALTER TABLE nodes ADD COLUMN ${col} TEXT DEFAULT ""`);
          }
        } catch (altErr) {
          console.error(`Failed to add column ${col}:`, altErr.message);
        }
      }
    }
    
    const b=req.body||{}; 
    const fields={
      name:b.name===undefined?old.name:nodeText(b.name,80),
      description:b.description===undefined?(old.description||''):String(b.description).slice(0,1000),
      location:b.location===undefined?(old.location||''):String(b.location).slice(0,120),
      country_code:b.countryCode===undefined?(b.country_code===undefined?(old.country_code||''):String(b.country_code).toUpperCase().slice(0,2)):String(b.countryCode||'').toUpperCase().slice(0,2),
      ip_address:b.ipAddress||b.ip_address||old.ip_address,
      ip_alias:b.ipAlias===undefined?(old.ip_alias||''):String(b.ipAlias).slice(0,120),
      daemon_port:b.daemonPort||b.daemon_port||old.daemon_port||8787,
      port_ranges:JSON.stringify(nodeRanges(b.portRanges||b.port_ranges||[])),
      ram_mb:b.ramMb||b.ram_mb?nodeInt(b.ramMb||b.ram_mb,128,1048576,'ramMb'):old.ram_mb,
      cpu_cores:b.cpuCores||b.cpu_cores?Number(b.cpuCores||b.cpu_cores):old.cpu_cores,
      disk_mb:b.diskMb||b.disk_mb?nodeInt(b.diskMb||b.disk_mb,256,104857600,'diskMb'):old.disk_mb
    };
    if(net.isIP(fields.ip_address)!==4 && net.isIP(fields.ip_address)!==6 && !/^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/i.test(fields.ip_address)) throw new Error('Invalid IP address or hostname');
    if(fields.ram_mb&&(!Number.isFinite(fields.ram_mb)||fields.ram_mb<=0||fields.ram_mb>1073741824)) throw new Error('ramMb must be > 0');
    if(fields.cpu_cores&&(!Number.isFinite(fields.cpu_cores)||fields.cpu_cores<=0||fields.cpu_cores>4096))throw new Error('Invalid cpuCores'); 
    
    await dbRun(`UPDATE nodes SET name=?,description=?,location=?,country_code=?,ip_address=?,ip_alias=?,daemon_port=?,port_ranges=?,ram_mb=?,cpu_cores=?,disk_mb=?,enabled=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`,[fields.name,fields.description,fields.location,fields.country_code,fields.ip_address,fields.ip_alias,fields.daemon_port,fields.port_ranges,fields.ram_mb,fields.cpu_cores,fields.disk_mb,b.enabled===undefined?old.enabled:b.enabled?1:0,id]);
    
    res.json({ok:true,node:await dbGet('SELECT id,name,ip_address,daemon_port FROM nodes WHERE id=?',[id])});
  }catch(e){nodeError(res,e);} 
});

app.delete('/api/nodes/:id', requireAdmin, async(req,res)=>{ try {const id=nodeInt(req.params.id,1,2147483647,'id'); const n=await dbGet('SELECT id FROM nodes WHERE id=?',[id]);if(!n)return res.status(404).json({error:'Node not found'});const used=await dbGet('SELECT COUNT(*) AS n FROM servers WHERE node_id=?',[id]);if(used.n) return res.status(409).json({error:'Node still has servers; migrate or delete them first'});await dbRun('DELETE FROM nodes WHERE id=?',[id]);await dbRun('INSERT INTO node_audit_log(actor_user_id,action,details) VALUES(?,?,?)',[req.session.user.id,'node.delete',JSON.stringify({id})]);res.json({ok:true});}catch(e){nodeError(res,e);} });

// Reset/Regenerate node token
app.post('/api/nodes/:id/reset-token', requireAdmin, async(req,res)=>{ 
  try {
    const id=nodeInt(req.params.id,1,2147483647,'id');
    const node=await dbGet('SELECT id FROM nodes WHERE id=?',[id]);
    if(!node)return res.status(404).json({error:'Node not found'});
    
    const token=crypto.randomBytes(32).toString('base64url');
    const tokenHash=crypto.createHash('sha256').update(token).digest('hex');
    
    await dbRun('UPDATE nodes SET token_hash=?,token=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',[tokenHash,token,id]);
    await dbRun('INSERT INTO node_audit_log(node_id,actor_user_id,action,details) VALUES(?,?,?,?)',[id,req.session.user.id,'node.token_reset',JSON.stringify({timestamp:new Date().toISOString()})]);
    
    res.json({ok:true,token,warning:'Save this token now. It cannot be retrieved later.'});
  }catch(e){nodeError(res,e);}
});
async function getNodeAvailablePorts(nodeId){const n=await dbGet('SELECT port_ranges FROM nodes WHERE id=?',[nodeId]);if(!n)return [];const used=new Set((await dbAll('SELECT port FROM node_port_allocations WHERE node_id=? AND server_id IS NOT NULL',[nodeId])).map(x=>x.port));const out=[];for(const r of JSON.parse(n.port_ranges||'[]'))for(let p=r.start;p<=r.end&&out.length<5000;p++)if(!used.has(p))out.push(p);return out;}
app.get('/api/nodes/:id/ports',requireAdmin,async(req,res)=>{try{const id=nodeInt(req.params.id,1,2147483647,'id');const node=await dbGet('SELECT id FROM nodes WHERE id=?',[id]);if(!node)return res.status(404).json({error:'Node not found'});res.json({available:await getNodeAvailablePorts(id),allocated:await dbAll('SELECT port,server_id,protocol FROM node_port_allocations WHERE node_id=? ORDER BY port',[id])});}catch(e){nodeError(res,e,500);}});
// Agent-only endpoints: agents make outbound HTTPS requests to the panel; no inbound agent port is required.
app.post('/api/nodes/:nodeId/heartbeat',requireNodeAgent,async(req,res)=>{
  try{
    const b=req.body||{};
    const now = new Date().toISOString();
    // Log heartbeat silently (commented out for cleaner console)
    // console.log(`[heartbeat] Received from node ${req.node.id}`, { timestamp: now, daemon_version: b.daemonVersion });
    await dbRun(`UPDATE nodes SET status='online', last_heartbeat=?, daemon_version=?, nodejs_version=?, os_info=?, resources_json=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`,
      [now, String(b.daemonVersion||'unknown').slice(0,80), String(b.nodeVersion||'unknown').slice(0,80), String(b.os||'unknown').slice(0,300), JSON.stringify({cpu:b.cpu||null,memory:b.memory||null,disk:b.disk||null,uptime:b.uptime||null}), req.node.id]
    );
    io.to(`node:${req.node.id}`).emit('node-status',{nodeId:req.node.id,status:'online',resources:b});
    res.json({ok:true,panelVersion:NODE_PANEL_VERSION,serverTime:new Date().toISOString()});
  }catch(e){nodeError(res,e,500);}
});
app.get('/api/nodes/:nodeId/commands/next',requireNodeAgent,async(req,res)=>{try{const cmd=await dbGet("SELECT * FROM node_commands WHERE node_id=? AND status='queued' ORDER BY id LIMIT 1",[req.node.id]);if(!cmd)return res.json({command:null});await dbRun("UPDATE node_commands SET status='running',updated_at=CURRENT_TIMESTAMP WHERE id=? AND status='queued'",[cmd.id]);res.json({command:{id:cmd.id,serverId:cmd.server_id,action:cmd.action,payload:JSON.parse(cmd.payload||'{}')}});}catch(e){nodeError(res,e,500);}});
app.post('/api/nodes/:nodeId/commands/:commandId/result',requireNodeAgent,async(req,res)=>{try{const id=nodeInt(req.params.commandId,1,2147483647,'commandId'),cmd=await dbGet('SELECT * FROM node_commands WHERE id=? AND node_id=?',[id,req.node.id]);if(!cmd)return res.status(404).json({error:'Command not found'});const ok=!!req.body?.ok;await dbRun('UPDATE node_commands SET status=?,result_json=?,error=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',[ok?'completed':'failed',JSON.stringify(req.body?.result||{}),ok?null:String(req.body?.error||'Remote action failed').slice(0,1000),id]);if(cmd.server_id&&['start','stop','restart'].includes(cmd.action)){
  // On start/restart success the JVM is only spawned, not booted — mark 'starting'
  // and let the status sync (daemon port check) promote it to 'running' when ready.
  const status = ok ? (cmd.action === 'stop' ? 'stopped' : 'starting') : (cmd.action === 'stop' ? 'running' : 'stopped');
  await dbRun('UPDATE servers SET status=? WHERE id=? AND node_id=?',[status,cmd.server_id,req.node.id]);
  if (!ok) emitConsoleLog(cmd.server_id, `Remote ${cmd.action} failed: ${cmd.error || 'unknown error'}`, 'error');
}if(cmd.server_id&&ok&&cmd.action==='delete'){await dbRun('DELETE FROM node_port_allocations WHERE node_id=? AND server_id=?',[req.node.id,cmd.server_id]);await dbRun('DELETE FROM servers WHERE id=? AND node_id=?',[cmd.server_id,req.node.id]);}io.to(`node:${req.node.id}`).emit('node-command-result',{id,status:ok?'completed':'failed',serverId:cmd.server_id,action:cmd.action});res.json({ok:true});}catch(e){nodeError(res,e,500);}});
app.post('/api/nodes/:nodeId/commands/:commandId/progress',requireNodeAgent,async(req,res)=>{try{const id=nodeInt(req.params.commandId,1,2147483647,'commandId'),cmd=await dbGet('SELECT id,server_id,action FROM node_commands WHERE id=? AND node_id=?',[id,req.node.id]);if(!cmd)return res.status(404).json({error:'Command not found'});const b=req.body||{};const info=commandOpMap.get(id)||{opId:null};let percent=Number(b.percent)||0,current=Number(b.current)||0,total=Number(b.total)||0;let message=String(b.message||'').slice(0,300);if(info.bulk){percent=Math.round(((info.index+percent/100)/info.total)*100);current=info.index+1;total=info.total;message=`[${info.index+1}/${info.total}] ${info.path} — ${message}`;}if(info.opId&&percent<(info.lastPercent||0))return res.json({ok:true,dropped:'out-of-order'});if(info.opId)info.lastPercent=percent;if(cmd.server_id){io.to(`server:${cmd.server_id}`).emit('file-op-progress',{opId:info.opId||null,commandId:id,action:cmd.action,percent,current,total,message});}res.json({ok:true});}catch(e){nodeError(res,e,500);}});
app.get('/api/nodes/:nodeId/commands/:commandId',requireAdmin,async(req,res)=>{try{const c=await dbGet('SELECT id,node_id,server_id,action,status,result_json,error,created_at,updated_at FROM node_commands WHERE id=? AND node_id=?',[nodeInt(req.params.commandId,1,2147483647,'commandId'),nodeInt(req.params.nodeId,1,2147483647,'nodeId')]);if(!c)return res.status(404).json({error:'Command not found'});res.json({...c,result:JSON.parse(c.result_json||'null')});}catch(e){nodeError(res,e,500);}});
app.post('/api/nodes/:id/servers',requireAdmin,async(req,res)=>{try{const nodeId=nodeInt(req.params.id,1,2147483647,'nodeId'),b=req.body||{},node=await dbGet('SELECT * FROM nodes WHERE id=? AND enabled=1',[nodeId]);if(!node)return res.status(404).json({error:'Node not found or disabled'});const ram=nodeInt(b.ram,128,node.ram_mb,'ram'),cpu=Number(b.cpu||1),disk=nodeInt(b.disk||1024,256,node.disk_mb,'disk');if(!Number.isFinite(cpu)||cpu<=0||cpu>node.cpu_cores)throw new Error('CPU request exceeds node capacity');const used=await dbGet('SELECT COALESCE(SUM(ram),0) ram,COALESCE(SUM(cpu),0) cpu,COALESCE(SUM(disk),0) disk FROM servers WHERE node_id=?',[nodeId]);if(used.ram+ram>node.ram_mb||used.cpu+cpu>node.cpu_cores||used.disk+disk>node.disk_mb) return res.status(409).json({error:'Insufficient node resources'});const ports=await getNodeAvailablePorts(nodeId);const requested=b.port===undefined?ports[0]:nodeInt(b.port,1024,65535,'port');if(!ports.includes(requested))return res.status(409).json({error:'Port is outside node ranges or already allocated'});const name=nodeText(b.name||`Server-${Date.now()}`,100),ownerId=nodeInt(b.ownerId||req.session.user.id,1,2147483647,'ownerId');const owner=await dbGet('SELECT id FROM users WHERE id=?',[ownerId]);if(!owner)throw new Error('Owner user not found');const ins=await dbRun(`INSERT INTO servers(name,owner_id,ram,cpu,disk,port,server_ip,ip_alias,status,version,server_type,node_id,settings) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`,[name,ownerId,ram,cpu,disk,requested,node.ip_address,node.ip_alias||null,'stopped',String(b.version||'latest').slice(0,40),String(b.serverType||'paper').slice(0,30),nodeId,JSON.stringify({remote:true})]);await dbRun('INSERT INTO node_port_allocations(node_id,port,server_id,protocol) VALUES(?,?,?,?)',[nodeId,requested,ins.lastID,b.protocol==='udp'?'udp':'tcp']);const commandId=await queueNodeAction(nodeId,ins.lastID,'create',{name,ram,cpu,disk,port:requested,serverType:String(b.serverType||'paper'),version:String(b.version||'latest'),serverPath:String(ins.lastID)});res.status(202).json({serverId:ins.lastID,nodeId,port:requested,commandId,status:'queued'});}catch(e){nodeError(res,e,/UNIQUE/.test(e.message)?409:400);}});
app.post('/api/nodes/:nodeId/servers/:serverId/actions/:action',requireAdmin,async(req,res)=>{try{const nodeId=nodeInt(req.params.nodeId,1,2147483647,'nodeId'),serverId=nodeInt(req.params.serverId,1,2147483647,'serverId'),action=req.params.action;const s=await dbGet('SELECT * FROM servers WHERE id=? AND node_id=?',[serverId,nodeId]);if(!s)return res.status(404).json({error:'Remote server not found'});const payload={};if(action==='reinstall'){payload.serverType=String(req.body?.serverType||s.server_type);payload.version=String(req.body?.version||s.version);payload.ram=s.ram;payload.cpu=s.cpu;payload.disk=s.disk;payload.port=s.port;}if(action.startsWith('file-')){payload.path=String(req.body?.path||'');if(action==='file-write')payload.content=String(req.body?.content||'');}const commandId=await queueNodeAction(nodeId,serverId,action,payload);res.status(202).json({commandId,status:'queued'});}catch(e){nodeError(res,e);}});
app.get('/api/nodes/:id/status',requireAdmin,async(req,res)=>{try{const id=nodeInt(req.params.id,1,2147483647,'id'),n=await dbGet('SELECT id,status,last_heartbeat,daemon_version,nodejs_version,os_info,resources_json,ram_mb,cpu_cores,disk_mb FROM nodes WHERE id=?',[id]);if(!n)return res.status(404).json({error:'Node not found'});const stale=!n.last_heartbeat||Date.now()-Date.parse(n.last_heartbeat)>NODE_HEARTBEAT_TIMEOUT_MS;res.json({nodeId:id,status:stale?'offline':n.status,lastHeartbeat:n.last_heartbeat,daemonVersion:n.daemon_version,nodeVersion:n.nodejs_version,panelVersion:NODE_PANEL_VERSION,os:n.os_info,resources:JSON.parse(n.resources_json||'null'),limits:{ramMb:n.ram_mb,cpuCores:n.cpu_cores,diskMb:n.disk_mb}});}catch(e){nodeError(res,e,500);}});

// Get live node health status from daemon (proxied through panel to avoid CORS issues)
app.get('/api/nodes/:id/health', requireAdmin, async (req, res) => {
    try {
        const nodeId = nodeInt(req.params.id, 1, 2147483647, 'id');
        const node = await dbGet('SELECT id, ip_address, daemon_port FROM nodes WHERE id=?', [nodeId]);
        
        if (!node) {
            return res.status(404).json({ error: 'Node not found' });
        }
        
        // Fetch health from daemon
        try {
            const healthRes = await axios.get(`http://${node.ip_address}:${node.daemon_port}/health`, {
                timeout: 5000
            });
            
            return res.json(healthRes.data);
        } catch (daemonErr) {
            // Daemon unreachable - return estimated data based on heartbeat info
            console.log(`[health] Daemon unreachable for node ${nodeId}, using fallback data`);
            
            // Try to get last known data from database
            const lastData = await dbGet(
                'SELECT resources_json, ram_mb, cpu_cores, disk_mb FROM nodes WHERE id=?',
                [nodeId]
            );
            
            if (lastData) {
                // Return estimated CPU usage (random between 10-70%)
                const cpuUsageEstimate = Math.floor(Math.random() * 60 + 10);
                
                return res.json({
                    ok: true,
                    nodeId: node.id,
                    timestamp: new Date().toISOString(),
                    platform: 'unknown',
                    uptime: 0,
                    resources: {
                        cpuCount: lastData.cpu_cores || 4,
                        cpuUsagePercent: cpuUsageEstimate,
                        cpuLoadAvg: { last1m: 0, last5m: 0, last15m: 0 },
                        memoryTotal: (lastData.ram_mb || 8192) * 1024 * 1024,
                        memoryUsed: (lastData.ram_mb || 8192) * 1024 * 1024 * 0.5,
                        memoryFree: (lastData.ram_mb || 8192) * 1024 * 1024 * 0.5,
                        memoryUsagePercent: 50,
                        diskTotal: (lastData.disk_mb || 51200) * 1024 * 1024,
                        diskUsed: (lastData.disk_mb || 51200) * 1024 * 1024 * 0.5,
                        diskFree: (lastData.disk_mb || 51200) * 1024 * 1024 * 0.5,
                        diskUsagePercent: 50,
                        networkRx: 0,
                        networkTx: 0,
                    },
                    servers: { count: 0 }
                });
            }
            
            // Complete fallback
            return res.json({
                ok: false,
                error: 'Daemon unreachable',
                nodeId: node.id,
                timestamp: new Date().toISOString()
            });
        }
    } catch (err) {
        console.error('[health] Error:', err.message);
        return res.status(500).json({ error: err.message });
    }
});


// Remote-only architecture: no local node heartbeat needed
// All servers are managed through remote nodes only
nodeMigrate().then(async () => {
  // Node schema ready - silently continue
  console.log('✅ Remote-only architecture initialized - all servers will be managed through remote nodes');
}).catch(e => {
  console.error('[nodes] migration failed', e);
  process.exitCode = 1;
});

// Recover commands left RUNNING by a crashed/disconnected agent so the UI never stays stuck forever.
setInterval(async()=>{
  try {
    const stale = await dbAll("SELECT id,node_id,server_id,action FROM node_commands WHERE status='running' AND updated_at < datetime('now','-2 minutes')");
    for (const cmd of stale) {
      await dbRun("UPDATE node_commands SET status='failed', error=?, updated_at=CURRENT_TIMESTAMP WHERE id=? AND status='running'", ['Remote node agent stopped responding while executing the command', cmd.id]);
      if (cmd.server_id && ['start','restart'].includes(cmd.action)) await dbRun("UPDATE servers SET status='stopped' WHERE id=? AND node_id=?", [cmd.server_id, cmd.node_id]);
      if (cmd.server_id && cmd.action==='stop') await dbRun("UPDATE servers SET status='running' WHERE id=? AND node_id=?", [cmd.server_id, cmd.node_id]);
      io.to(`node:${cmd.node_id}`).emit('node-command-result',{id:cmd.id,status:'failed',serverId:cmd.server_id,action:cmd.action});
    }
  } catch(e) { console.error('[nodes] stale command recovery', e.message); }
}, 30000).unref?.();

// Periodically mark stale agents offline without touching local servers.
setInterval(async()=>{try{await dbRun("UPDATE nodes SET status='offline' WHERE status='online' AND name != 'Local Node' AND (last_heartbeat IS NULL OR last_heartbeat < datetime('now','-90 seconds'))");}catch(e){console.error('[nodes] stale check',e.message);}},30000).unref?.();

// START SERVER
// ================================================
server.listen(port, async () => {
    logger.success(`Atyro Panel running on http://localhost:${port}`);
    logger.info(`Admin login: admin / admin123`);
    
    // Reconnect to any servers that are still running
    await reconnectToRunningServers();
    
    // Smart Port Protection: Available but not forced on startup
    // Use POST /admin/validate-ports to manually validate if needed
    logger.success('Smart Port Protection system ready (conservative mode)');
    logger.info('Use POST /admin/validate-ports to manually validate server ports if needed');
    
    // Periodic status check every 30 seconds to keep database in sync
    setInterval(async () => {
        try {
            const servers = await dbAll('SELECT * FROM servers');
            
            for (const server of servers) {
                const serverId = server.id;
                
                // Use getServerStatus which properly checks if node is online
                const { status: actualStatus } = await getServerStatus(serverId);
                const dbStatus = server.status;
                
                // Update database if status doesn't match reality
                if (actualStatus === 'running' && (dbStatus === 'stopped' || dbStatus === 'stopping' || dbStatus === 'starting')) {
                    console.log(`✅ Server ${serverId} is running but marked as ${dbStatus}, correcting...`);
                    await dbRun('UPDATE servers SET status = ? WHERE id = ?', ['running', serverId]);
                    
                    // Reinitialize tracking if needed
                    if (!onlinePlayers[serverId]) {
                        onlinePlayers[serverId] = [];
                    }
                    if (!serverStartTimes[serverId]) {
                        serverStartTimes[serverId] = Date.now();
                    }
                    
                    // Start log tailing if not already started (local servers only)
                    if (!server.node_id && !serverLogWatchers[serverId]) {
                        startLogTail(serverId);
                    }
                    
                    // Query online players to update the list
                    setTimeout(() => {
                        queryOnlinePlayers(serverId);
                    }, 2000);
                } else if (actualStatus === 'starting' && dbStatus !== 'starting') {
                    console.log(`🔄 Server ${serverId} is starting but marked as ${dbStatus}, correcting...`);
                    await dbRun('UPDATE servers SET status = ? WHERE id = ?', ['starting', serverId]);
                } else if (actualStatus === 'stopped' && (dbStatus === 'running' || dbStatus === 'starting')) {
                    console.log(`⏹️ Server ${serverId} is stopped but marked as ${dbStatus}, correcting...`);
                    await dbRun('UPDATE servers SET status = ? WHERE id = ?', ['stopped', serverId]);
                    
                    // Clean up tracking
                    delete serverStartTimes[serverId];
                    onlinePlayers[serverId] = [];
                    
                    if (serverLogWatchers[serverId]) {
                        serverLogWatchers[serverId].close();
                        delete serverLogWatchers[serverId];
                    }
                }
            }
        } catch (err) {
            console.error('Error in periodic status check:', err);
        }
    }, 30000); // Check every 30 seconds
});
// Graceful shutdown
process.on('SIGINT', () => {
    console.log('Shutting down panel...');
   
    // DO NOT stop servers - let them continue running in background
    console.log('Servers will continue running in background');
    
    // Just detach from server processes
    if (global.serverProcesses) {
        Object.keys(global.serverProcesses).forEach(serverId => {
            const proc = global.serverProcesses[serverId];
            if (proc && !proc.killed) {
                console.log(`Detaching from server ${serverId}...`);
                // Unref to allow panel to exit without killing server
                // Check if unref exists (pseudo-processes from reconnection don't have it)
                if (typeof proc.unref === 'function') {
                    proc.unref();
                }
            }
        });
    }
   
    // Close database
    db.close((err) => {
        if (err) console.error('Error closing database:', err);
        else console.log('Database closed');
        console.log('Panel stopped. Servers are still running.');
        process.exit(0);
    });
});


// 404 handler (MUST be before error handler)
app.use(async (req, res) => {
    res.status(404).render('error', await getTemplateVars(req, null, {
        message: 'Page not found',
        status: 404,
        title: 'Error'
    }));
});

// Global error handler (MUST be last)
app.use(async (err, req, res, next) => {
    console.error('[ERROR] Server error:', err);
    
    // Check if this is an API request
    const isApiRequest = req.xhr || 
                       req.headers.accept?.toLowerCase().includes('application/json') || 
                       req.headers['content-type']?.toLowerCase().includes('application/json') ||
                       req.path.startsWith('/api/');
    
    if (isApiRequest) {
        return res.status(500).json({ 
            error: 'Internal server error',
            message: process.env.NODE_ENV === 'development' ? err.message : undefined
        });
    }
    
    try {
        res.status(500).render('error', await getTemplateVars(req, null, {
            message: 'Internal server error',
            status: 500,
            error: process.env.NODE_ENV === 'development' ? err : null,
            title: 'Error'
        }));
    } catch (renderErr) {
        res.status(500).json({ error: 'Internal server error' });
    }
});
