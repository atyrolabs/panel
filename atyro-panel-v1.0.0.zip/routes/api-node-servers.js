/**
 * Node Server Management API Routes
 * Handles server allocation, control, and file operations on remote nodes
 */

const express = require('express');
const router = express.Router();
const NodeUtilities = require('../utilities/node-utilities');

/**
 * Middleware to ensure user is admin
 */
function requireAdmin(req, res, next) {
  if (!req.session.userId || req.session.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
}

/**
 * POST /api/nodes/:nodeId/servers
 * Allocate/create a server on a specific node
 */
router.post('/nodes/:nodeId/servers', requireAdmin, async (req, res) => {
  const { nodeId } = req.params;
  const { serverId, port, workingDir } = req.body;

  try {
    // Verify node exists and is online
    const node = await new Promise((resolve, reject) => {
      req.db.get(
        `SELECT * FROM nodes WHERE id = ? AND enabled = 1`,
        [nodeId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!node) {
      return res.status(404).json({ error: 'Node not found or disabled' });
    }

    if (node.status === 'offline') {
      return res.status(503).json({ error: 'Node is currently offline' });
    }

    // Verify server exists
    const server = await new Promise((resolve, reject) => {
      req.db.get(
        `SELECT * FROM servers WHERE id = ?`,
        [serverId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!server) {
      return res.status(404).json({ error: 'Server not found' });
    }

    // Check port availability
    const portAvailable = await new NodeUtilities(req.db).isPortAvailable(nodeId, port);
    if (!portAvailable) {
      return res.status(400).json({ error: 'Port is not available on this node' });
    }

    // Allocate port
    await new NodeUtilities(req.db).allocatePort(nodeId, serverId, port);

    // Record server allocation
    await new Promise((resolve, reject) => {
      req.db.run(
        `INSERT OR REPLACE INTO server_node_allocations 
         (server_id, node_id, remote_server_path, status)
         VALUES (?, ?, ?, 'active')`,
        [serverId, nodeId, workingDir || `/opt/minecraft-servers/${serverId}`],
        (err) => {
          if (err) reject(err);
          else resolve();
        }
      );
    });

    // Update server node_id
    await new Promise((resolve, reject) => {
      req.db.run(
        `UPDATE servers SET node_id = ?, port = ? WHERE id = ?`,
        [nodeId, port, serverId],
        (err) => {
          if (err) reject(err);
          else resolve();
        }
      );
    });

    res.status(201).json({
      success: true,
      message: 'Server allocated to node successfully',
      allocation: {
        serverId,
        nodeId,
        port,
        workingDir: workingDir || `/opt/minecraft-servers/${serverId}`
      }
    });

  } catch (err) {
    console.error('Error allocating server to node:', err);
    res.status(500).json({ error: err.message });
  }
});

/**
 * POST /api/nodes/:nodeId/servers/:serverId/start
 * Start a server on a remote node
 */
router.post('/nodes/:nodeId/servers/:serverId/start', requireAdmin, async (req, res) => {
  const { nodeId, serverId } = req.params;
  const { jvmArgs } = req.body;

  try {
    const node = await new Promise((resolve, reject) => {
      req.db.get(
        `SELECT * FROM nodes WHERE id = ? AND enabled = 1`,
        [nodeId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!node || node.status === 'offline') {
      return res.status(503).json({ error: 'Node is not available' });
    }

    const allocation = await new Promise((resolve, reject) => {
      req.db.get(
        `SELECT * FROM server_node_allocations WHERE server_id = ? AND node_id = ?`,
        [serverId, nodeId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!allocation) {
      return res.status(404).json({ error: 'Server not allocated to this node' });
    }

    // Send start command to daemon
    const result = await NodeUtilities.sendToDaemon(
      node.ip_address,
      node.daemon_port,
      'POST',
      `/servers/${serverId}/start`,
      {
        jarFile: 'server.jar',
        jvmArgs: jvmArgs || '-Xmx1024M -Xms512M',
        workingDir: allocation.remote_server_path
      },
      node.daemon_token
    );

    // Update server status
    req.db.run(
      `UPDATE servers SET status = 'running' WHERE id = ?`,
      [serverId]
    );

    res.json({
      success: true,
      message: 'Server started successfully',
      pid: result.pid
    });

  } catch (err) {
    console.error('Error starting server:', err);
    res.status(500).json({ error: err.message });
  }
});

/**
 * POST /api/nodes/:nodeId/servers/:serverId/stop
 * Stop a running server on a remote node
 */
router.post('/nodes/:nodeId/servers/:serverId/stop', requireAdmin, async (req, res) => {
  const { nodeId, serverId } = req.params;
  const { timeout = 30 } = req.body;

  try {
    const node = await new Promise((resolve, reject) => {
      req.db.get(
        `SELECT * FROM nodes WHERE id = ?`,
        [nodeId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!node) {
      return res.status(404).json({ error: 'Node not found' });
    }

    // Send stop command to daemon
    const result = await NodeUtilities.sendToDaemon(
      node.ip_address,
      node.daemon_port,
      'POST',
      `/servers/${serverId}/stop`,
      { timeout },
      node.daemon_token
    );

    // Update server status
    req.db.run(
      `UPDATE servers SET status = 'stopped' WHERE id = ?`,
      [serverId]
    );

    res.json({
      success: true,
      message: 'Server stopped successfully'
    });

  } catch (err) {
    console.error('Error stopping server:', err);
    res.status(500).json({ error: err.message });
  }
});

/**
 * POST /api/nodes/:nodeId/servers/:serverId/restart
 * Restart a server on a remote node
 */
router.post('/nodes/:nodeId/servers/:serverId/restart', requireAdmin, async (req, res) => {
  const { nodeId, serverId } = req.params;

  try {
    const node = await new Promise((resolve, reject) => {
      req.db.get(
        `SELECT * FROM nodes WHERE id = ?`,
        [nodeId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!node) {
      return res.status(404).json({ error: 'Node not found' });
    }

    // Send restart command to daemon
    const result = await NodeUtilities.sendToDaemon(
      node.ip_address,
      node.daemon_port,
      'POST',
      `/servers/${serverId}/restart`,
      {},
      node.daemon_token
    );

    res.json({
      success: true,
      message: 'Server restart command sent'
    });

  } catch (err) {
    console.error('Error restarting server:', err);
    res.status(500).json({ error: err.message });
  }
});

/**
 * GET /api/nodes/:nodeId/servers/:serverId/logs
 * Get server logs from remote node
 */
router.get('/nodes/:nodeId/servers/:serverId/logs', requireAdmin, async (req, res) => {
  const { nodeId, serverId } = req.params;
  const { lines = 50 } = req.query;

  try {
    const node = await new Promise((resolve, reject) => {
      req.db.get(
        `SELECT * FROM nodes WHERE id = ?`,
        [nodeId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!node) {
      return res.status(404).json({ error: 'Node not found' });
    }

    // Get logs from daemon
    const result = await NodeUtilities.sendToDaemon(
      node.ip_address,
      node.daemon_port,
      'GET',
      `/servers/${serverId}/logs?lines=${lines}`,
      null,
      node.daemon_token
    );

    res.json(result);

  } catch (err) {
    console.error('Error fetching logs:', err);
    res.status(500).json({ error: err.message });
  }
});

/**
 * GET /api/nodes/:nodeId/servers/:serverId/stats
 * Get server statistics from remote node
 */
router.get('/nodes/:nodeId/servers/:serverId/stats', requireAdmin, async (req, res) => {
  const { nodeId, serverId } = req.params;

  try {
    const node = await new Promise((resolve, reject) => {
      req.db.get(
        `SELECT * FROM nodes WHERE id = ?`,
        [nodeId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!node) {
      return res.status(404).json({ error: 'Node not found' });
    }

    // Get stats from daemon
    const result = await NodeUtilities.sendToDaemon(
      node.ip_address,
      node.daemon_port,
      'GET',
      `/servers/${serverId}/stats`,
      null,
      node.daemon_token
    );

    res.json(result);

  } catch (err) {
    console.error('Error fetching stats:', err);
    res.status(500).json({ error: err.message });
  }
});

/**
 * POST /api/nodes/:nodeId/servers/:serverId/command
 * Send a command to server console
 */
router.post('/nodes/:nodeId/servers/:serverId/command', requireAdmin, async (req, res) => {
  const { nodeId, serverId } = req.params;
  const { command } = req.body;

  if (!command || command.trim() === '') {
    return res.status(400).json({ error: 'Command is required' });
  }

  try {
    const node = await new Promise((resolve, reject) => {
      req.db.get(
        `SELECT * FROM nodes WHERE id = ?`,
        [nodeId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!node) {
      return res.status(404).json({ error: 'Node not found' });
    }

    // Send command to daemon
    const result = await NodeUtilities.sendToDaemon(
      node.ip_address,
      node.daemon_port,
      'POST',
      `/servers/${serverId}/command`,
      { command },
      node.daemon_token
    );

    res.json({
      success: true,
      message: 'Command executed',
      command
    });

  } catch (err) {
    console.error('Error executing command:', err);
    res.status(500).json({ error: err.message });
  }
});

/**
 * GET /api/nodes/:nodeId/servers/:serverId/files
 * List files on remote server
 */
router.get('/nodes/:nodeId/servers/:serverId/files', requireAdmin, async (req, res) => {
  const { nodeId, serverId } = req.params;
  const { path = '/servers' } = req.query;

  try {
    const node = await new Promise((resolve, reject) => {
      req.db.get(
        `SELECT * FROM nodes WHERE id = ?`,
        [nodeId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!node) {
      return res.status(404).json({ error: 'Node not found' });
    }

    // Get file listing from daemon
    const result = await NodeUtilities.sendToDaemon(
      node.ip_address,
      node.daemon_port,
      'GET',
      `/files?path=${encodeURIComponent(path)}`,
      null,
      node.daemon_token
    );

    res.json(result);

  } catch (err) {
    console.error('Error listing files:', err);
    res.status(500).json({ error: err.message });
  }
});

/**
 * DELETE /api/nodes/:nodeId/servers/:serverId
 * Deallocate and remove server from node
 */
router.delete('/nodes/:nodeId/servers/:serverId', requireAdmin, async (req, res) => {
  const { nodeId, serverId } = req.params;

  try {
    // Get allocation info
    const allocation = await new Promise((resolve, reject) => {
      req.db.get(
        `SELECT * FROM server_node_allocations WHERE server_id = ? AND node_id = ?`,
        [serverId, nodeId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!allocation) {
      return res.status(404).json({ error: 'Server allocation not found' });
    }

    // Get server port
    const server = await new Promise((resolve, reject) => {
      req.db.get(
        `SELECT * FROM servers WHERE id = ?`,
        [serverId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (server && server.port) {
      // Deallocate port
      await new NodeUtilities(req.db).deallocatePort(nodeId, server.port);
    }

    // Delete allocation
    await new Promise((resolve, reject) => {
      req.db.run(
        `DELETE FROM server_node_allocations WHERE server_id = ? AND node_id = ?`,
        [serverId, nodeId],
        (err) => {
          if (err) reject(err);
          else resolve();
        }
      );
    });

    res.json({
      success: true,
      message: 'Server deallocated from node'
    });

  } catch (err) {
    console.error('Error deallocating server:', err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
