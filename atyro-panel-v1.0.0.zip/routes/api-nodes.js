/**
 * Node Management API Routes
 * Handles CRUD operations for Pterodactyl-style nodes
 */

const express = require('express');
const router = express.Router();
const NodeUtilities = require('../utilities/node-utilities');

/**
 * Middleware to ensure user is admin
 */
function requireAdmin(req, res, next) {
  if (!req.session.userId || req.session.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
}

/**
 * GET /api/nodes
 * List all nodes with pagination and filtering
 */
router.get('/nodes', requireAdmin, (req, res) => {
  const { page = 1, limit = 20, status, enabled } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(limit);

  let query = 'SELECT * FROM nodes';
  let params = [];

  if (status) {
    query += ' AND status = ?';
    params.push(status);
  }

  if (typeof enabled !== 'undefined') {
    query += ' AND enabled = ?';
    params.push(enabled === 'true' ? 1 : 0);
  }

  query += ` ORDER BY created_at DESC LIMIT ? OFFSET ?`;
  params.push(parseInt(limit), offset);

  req.db.all(query, params, (err, nodes) => {
    if (err) {
      console.error('Error fetching nodes:', err);
      return res.status(500).json({ error: 'Failed to fetch nodes' });
    }

    // Get total count
    req.db.get(
      `SELECT COUNT(*) as total FROM nodes`,
      (err, countResult) => {
        res.json({
          nodes: nodes || [],
          pagination: {
            page: parseInt(page),
            limit: parseInt(limit),
            total: countResult?.total || 0,
            pages: Math.ceil((countResult?.total || 0) / parseInt(limit))
          }
        });
      }
    );
  });
});

/**
 * GET /api/nodes/:id
 * Get detailed node information
 */
router.get('/nodes/:id', requireAdmin, (req, res) => {
  const { id } = req.params;

  req.db.get(
    `SELECT * FROM nodes WHERE id = ?`,
    [id],
    async (err, node) => {
      if (err) {
        console.error('Error fetching node:', err);
        return res.status(500).json({ error: 'Failed to fetch node' });
      }

      if (!node) {
        return res.status(404).json({ error: 'Node not found' });
      }

      // Get port ranges
      req.db.all(
        `SELECT * FROM node_port_ranges WHERE node_id = ?`,
        [id],
        (err, ranges) => {
          if (err) {
            ranges = [];
          }

          // Get servers on this node
          req.db.all(
            `SELECT s.* FROM servers s
             JOIN server_node_allocations sna ON s.id = sna.server_id
             WHERE sna.node_id = ?`,
            [id],
            (err, servers) => {
              if (err) {
                servers = [];
              }

              // Get port statistics
              req.db.get(
                `SELECT 
                  COUNT(*) as total_ports,
                  SUM(CASE WHEN assigned = 0 THEN 1 ELSE 0 END) as available_ports,
                  SUM(CASE WHEN assigned = 1 THEN 1 ELSE 0 END) as allocated_ports
                 FROM port_allocations WHERE node_id = ?`,
                [id],
                (err, portStats) => {
                  // Get resource statistics
                  req.db.get(
                    `SELECT * FROM node_resources WHERE node_id = ? ORDER BY timestamp DESC LIMIT 1`,
                    [id],
                    (err, resources) => {
                      res.json({
                        node: node,
                        portRanges: ranges || [],
                        servers: servers || [],
                        portStatistics: portStats || { total_ports: 0, available_ports: 0, allocated_ports: 0 },
                        resources: resources || {}
                      });
                    }
                  );
                }
              );
            }
          );
        }
      );
    }
  );
});

/**
 * POST /api/nodes
 * Create a new node
 */
router.post('/nodes', requireAdmin, async (req, res) => {
  const {
    name,
    description,
    location,
    country_code,
    ip_address,
    ip_alias,
    daemon_port,
    ram_mb,
    cpu_cores,
    disk_mb,
    port_ranges
  } = req.body;

  // Validate input
  const validation = NodeUtilities.validateNodeConfig({
    name,
    ip_address,
    daemon_port,
    ram_mb,
    cpu_cores,
    disk_mb,
    port_ranges
  });

  if (!validation.valid) {
    return res.status(400).json({ error: 'Validation failed', errors: validation.errors });
  }

  // Generate daemon token
  const daemonToken = NodeUtilities.generateToken();
  const daemonTokenHash = NodeUtilities.hashToken(daemonToken);

  req.db.run(
    `INSERT INTO nodes (
      name, description, location, country_code, ip_address, ip_alias, 
      daemon_port, daemon_token, daemon_token_hash, ram_mb, cpu_cores, disk_mb
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      name,
      description || null,
      location || null,
      country_code || null,
      ip_address,
      ip_alias || null,
      daemon_port,
      daemonToken,
      daemonTokenHash,
      ram_mb,
      cpu_cores,
      disk_mb
    ],
    async function(err) {
      if (err) {
        console.error('Error creating node:', err);
        if (err.message.includes('UNIQUE')) {
          return res.status(400).json({ error: 'Node name or IP already exists' });
        }
        return res.status(500).json({ error: 'Failed to create node' });
      }

      const nodeId = this.lastID;

      // Initialize port allocations
      if (port_ranges && Array.isArray(port_ranges) && port_ranges.length > 0) {
        try {
          const portCount = await NodeUtilities.prototype.initializeNodePorts(
            req.db,
            nodeId,
            port_ranges
          );

          // Store port ranges
          for (const range of port_ranges) {
            req.db.run(
              `INSERT INTO node_port_ranges (node_id, port_start, port_end) VALUES (?, ?, ?)`,
              [nodeId, range.start, range.end]
            );
          }
        } catch (err) {
          console.error('Error initializing ports:', err);
        }
      }

      // Log action
      await NodeUtilities.prototype.logNodeAction(
        req.db,
        nodeId,
        req.session.userId,
        'create',
        `Node created by ${req.session.username}`,
        'success',
        { name, ip_address },
        req.ip
      );

      res.status(201).json({
        success: true,
        node: {
          id: nodeId,
          name,
          daemon_port,
          status: 'offline'
        },
        token: daemonToken,
        message: 'Node created successfully. Copy the token and configure the daemon.'
      });
    }
  );
});

/**
 * PUT /api/nodes/:id
 * Update node configuration
 */
router.put('/nodes/:id', requireAdmin, (req, res) => {
  const { id } = req.params;
  const {
    name,
    description,
    location,
    country_code,
    ip_address,
    ip_alias,
    daemon_port,
    ram_mb,
    cpu_cores,
    disk_mb,
    enabled
  } = req.body;

  // Validate input
  const validation = NodeUtilities.validateNodeConfig({
    name: name || '',
    ip_address: ip_address || '',
    daemon_port: daemon_port || 8787,
    ram_mb: ram_mb || 1024,
    cpu_cores: cpu_cores || 4,
    disk_mb: disk_mb || 51200
  });

  if (!validation.valid) {
    return res.status(400).json({ error: 'Validation failed', errors: validation.errors });
  }

  req.db.run(
    `UPDATE nodes SET
      name = ?, description = ?, location = ?, country_code = ?,
      ip_address = ?, ip_alias = ?, daemon_port = ?,
      ram_mb = ?, cpu_cores = ?, disk_mb = ?, enabled = ?,
      updated_at = CURRENT_TIMESTAMP
     WHERE id = ?`,
    [
      name, description, location, country_code,
      ip_address, ip_alias, daemon_port,
      ram_mb, cpu_cores, disk_mb,
      enabled !== undefined ? (enabled ? 1 : 0) : undefined,
      id
    ],
    (err) => {
      if (err) {
        console.error('Error updating node:', err);
        if (err.message.includes('UNIQUE')) {
          return res.status(400).json({ error: 'Node name or IP already exists' });
        }
        return res.status(500).json({ error: 'Failed to update node' });
      }

      res.json({ success: true, message: 'Node updated successfully' });
    }
  );
});

/**
 * DELETE /api/nodes/:id
 * Delete a node
 */
router.delete('/nodes/:id', requireAdmin, (req, res) => {
  const { id } = req.params;

  // Check if node has servers
  req.db.get(
    `SELECT COUNT(*) as count FROM server_node_allocations WHERE node_id = ?`,
    [id],
    (err, result) => {
      if (err) {
        return res.status(500).json({ error: 'Failed to check node' });
      }

      if (result?.count > 0) {
        return res.status(400).json({ error: 'Cannot delete node with allocated servers' });
      }

      // Delete node (cascade will handle related records)
      req.db.run(
        `DELETE FROM nodes WHERE id = ?`,
        [id],
        (err) => {
          if (err) {
            console.error('Error deleting node:', err);
            return res.status(500).json({ error: 'Failed to delete node' });
          }

          res.json({ success: true, message: 'Node deleted successfully' });
        }
      );
    }
  );
});

/**
 * POST /api/nodes/:id/heartbeat
 * Check node health and update statistics
 */
router.post('/nodes/:id/heartbeat', requireAdmin, async (req, res) => {
  const { id } = req.params;

  try {
    const health = await NodeUtilities.checkNodeHealth(req.db, id);

    if (health.healthy) {
      res.json({
        success: true,
        healthy: true,
        data: health.data
      });
    } else {
      res.status(503).json({
        success: false,
        healthy: false,
        error: health.error
      });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * POST /api/nodes/:id/regenerate-token
 * Regenerate daemon token for a node
 */
router.post('/nodes/:id/regenerate-token', requireAdmin, (req, res) => {
  const { id } = req.params;

  const newToken = NodeUtilities.generateToken();
  const newTokenHash = NodeUtilities.hashToken(newToken);

  req.db.run(
    `UPDATE nodes SET daemon_token = ?, daemon_token_hash = ? WHERE id = ?`,
    [newToken, newTokenHash, id],
    (err) => {
      if (err) {
        return res.status(500).json({ error: 'Failed to regenerate token' });
      }

      res.json({
        success: true,
        token: newToken,
        message: 'Token regenerated. Reconfigure your daemon with the new token.'
      });
    }
  );
});

/**
 * GET /api/nodes/:id/stats
 * Get node resource statistics
 */
router.get('/nodes/:id/stats', requireAdmin, async (req, res) => {
  const { id } = req.params;
  const { hours = 24 } = req.query;

  try {
    const utils = new NodeUtilities(req.db);
    const stats = await utils.getNodeStats(id);
    const history = await utils.getNodeResourceHistory(id, parseInt(hours));

    res.json({
      current: stats,
      history: history
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * GET /api/nodes/:id/ports
 * Get port allocation information for a node
 */
router.get('/nodes/:id/ports', requireAdmin, (req, res) => {
  const { id } = req.params;

  req.db.all(
    `SELECT * FROM port_allocations WHERE node_id = ? ORDER BY port`,
    [id],
    (err, ports) => {
      if (err) {
        return res.status(500).json({ error: 'Failed to fetch ports' });
      }

      const available = ports?.filter(p => !p.assigned) || [];
      const allocated = ports?.filter(p => p.assigned) || [];

      res.json({
        available: available.length,
        allocated: allocated.length,
        total: ports?.length || 0,
        ports: ports || [],
        availablePorts: available.map(p => p.port),
        allocatedPorts: allocated.map(p => p.port)
      });
    }
  );
});

module.exports = router;
