/**
 * ANSI Color Parser for Minecraft Server Logs
 * Handles ANSI RGB, Minecraft § codes, and hex formatting
 * Converts everything to ANSI escape sequences for xterm.js rendering
 */

class AnsiColorParser {
  constructor() {
    // Minecraft color code map (§0-§f)
    this.minecraftColors = {
      '0': { r: 0, g: 0, b: 0 },           // Black
      '1': { r: 0, g: 0, b: 170 },         // Dark Blue
      '2': { r: 0, g: 170, b: 0 },         // Dark Green
      '3': { r: 0, g: 170, b: 170 },       // Dark Cyan
      '4': { r: 170, g: 0, b: 0 },         // Dark Red
      '5': { r: 170, g: 0, b: 170 },       // Dark Magenta
      '6': { r: 255, g: 170, b: 0 },       // Gold/Orange
      '7': { r: 170, g: 170, b: 170 },     // Gray
      '8': { r: 85, g: 85, b: 85 },        // Dark Gray
      '9': { r: 85, g: 85, b: 255 },       // Blue
      'a': { r: 85, g: 255, b: 85 },       // Green
      'b': { r: 85, g: 255, b: 255 },      // Cyan
      'c': { r: 255, g: 85, b: 85 },       // Red
      'd': { r: 255, g: 85, b: 255 },      // Magenta
      'e': { r: 255, g: 255, b: 85 },      // Yellow
      'f': { r: 255, g: 255, b: 255 }      // White
    };

    // Minecraft formatting codes
    this.minecraftFormats = {
      'l': 'bold',      // Bold
      'o': 'italic',    // Italic
      'm': 'strike',    // Strikethrough
      'n': 'underline', // Underline
      'k': 'obfuscate', // Obfuscated
      'r': 'reset'      // Reset
    };
  }

  /**
   * Convert RGB to ANSI 24-bit escape code
   */
  rgbToAnsi(r, g, b) {
    return `\x1b[38;2;${Math.floor(r)};${Math.floor(g)};${Math.floor(b)}m`;
  }

  /**
   * Parse hex color string to RGB
   */
  hexToRgb(hex) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    if (!result) return null;
    return {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    };
  }

  /**
   * Convert Minecraft § codes to ANSI sequences
   */
  convertMinecraftCodes(line) {
    if (!line) return line;

    let result = line;

    // Convert Minecraft color codes (§0-§f)
    for (const [code, rgb] of Object.entries(this.minecraftColors)) {
      const regex = new RegExp(`§${code}`, 'g');
      const ansiCode = this.rgbToAnsi(rgb.r, rgb.g, rgb.b);
      result = result.replace(regex, ansiCode);
    }

    // Convert Minecraft formatting codes
    const formatMap = {
      'l': '\x1b[1m',      // Bold
      'o': '\x1b[3m',      // Italic
      'm': '\x1b[9m',      // Strikethrough
      'n': '\x1b[4m',      // Underline
      'k': '\x1b[1m',      // Obfuscate (use bold as fallback)
      'r': '\x1b[0m'       // Reset
    };

    for (const [code, ansiCode] of Object.entries(formatMap)) {
      const regex = new RegExp(`§${code}`, 'g');
      result = result.replace(regex, ansiCode);
    }

    return result;
  }

  /**
   * Parse hex color codes in format #RRGGBB and convert to ANSI
   */
  convertHexColors(line) {
    if (!line) return line;

    // Match #RRGGBB hex codes
    const hexRegex = /#[0-9a-fA-F]{6}/g;
    let result = line;

    const matches = line.match(hexRegex);
    if (matches) {
      for (const hex of matches) {
        const rgb = this.hexToRgb(hex);
        if (rgb) {
          const ansiCode = this.rgbToAnsi(rgb.r, rgb.g, rgb.b);
          result = result.replace(new RegExp(hex, 'g'), ansiCode);
        }
      }
    }

    return result;
  }

  /**
   * Strip all color codes (for deduplication)
   */
  stripColors(line) {
    if (!line) return '';

    let result = String(line);

    // Remove ANSI escape sequences
    result = result.replace(/\x1b\[[0-9;]*m/g, '');
    result = result.replace(/\033\[[0-9;]*m/g, '');

    // Remove Minecraft color codes
    result = result.replace(/§[0-9a-fk-orx]/gi, '');

    // Remove hex codes
    result = result.replace(/#[0-9a-fA-F]{6}/g, '');

    return result.trim();
  }

  /**
   * Process raw log line: convert all color codes to ANSI and add missing colors based on log level
   */
  processLine(line) {
    if (!line) return line;

    let processed = String(line);

    // First: Convert Minecraft § codes
    processed = this.convertMinecraftCodes(processed);

    // Second: Convert hex colors
    processed = this.convertHexColors(processed);

    // Third: If no ANSI codes present yet, add color based on log level detection
    if (!processed.includes('\x1b[') && !processed.includes('\u001b[')) {
      // No ANSI codes found - add color based on log level
      const level = this.detectLevel(line);
      
      const colorCodes = {
        error: '\x1b[38;2;255;85;85m',    // Red
        warn: '\x1b[38;2;255;165;0m',     // Orange
        debug: '\x1b[38;2;128;128;128m',  // Dark Gray
        success: '\x1b[38;2;85;255;85m',  // Green
        info: '\x1b[38;2;220;220;220m'    // Light Gray
      };

      const color = colorCodes[level] || colorCodes.info;
      processed = color + processed + '\x1b[0m'; // Add color code at start and reset at end
    }

    // Return ANSI-formatted line
    return processed;
  }

  /**
   * Detect log level from line
   */
  detectLevel(line) {
    const clean = this.stripColors(line);

    if (/\[ERROR\]|ERROR:|Exception|Exception at/i.test(clean)) return 'error';
    if (/\[WARN\]|WARNING:/i.test(clean)) return 'warn';
    if (/\[DEBUG\]/i.test(clean)) return 'debug';
    if (/\bSUCCESS\b|\bDONE\b|Loaded/i.test(clean)) return 'success';

    return 'info';
  }

  /**
   * Normalize line for deduplication
   */
  normalizeForDedup(line) {
    let normalized = this.stripColors(line);

    // Remove timestamps [HH:MM:SS]
    normalized = normalized.replace(/^\[\d{1,2}:\d{2}:\d{2}[^\]]*\]\s*/i, '');

    // Remove ISO timestamps
    normalized = normalized.replace(/^\[\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}[^\]]*\]\s*/i, '');

    // Remove thread info [Server thread/INFO]:
    normalized = normalized.replace(/^\[[^\]]*\/[A-Z]+\]:\s*/i, '');

    // Remove log level [INFO]: [WARN]: etc
    normalized = normalized.replace(/^\[[A-Z]+\]:\s*/i, '');

    return normalized.trim();
  }
}

module.exports = new AnsiColorParser();
