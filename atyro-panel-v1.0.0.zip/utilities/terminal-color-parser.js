// ANSI / Minecraft color parser for the live console.
// Normalizes literal ANSI text, Minecraft section codes and hex colors into
// real ESC sequences, then adds level based colors when a line has none.

const ESC = '\x1b';
const RESET = `${ESC}[0m`;

const MC_COLORS = {
  '0': [0, 0, 0],
  '1': [0, 0, 170],
  '2': [0, 170, 0],
  '3': [0, 170, 170],
  '4': [170, 0, 0],
  '5': [170, 0, 170],
  '6': [255, 170, 0],
  '7': [170, 170, 170],
  '8': [85, 85, 85],
  '9': [85, 85, 255],
  'a': [85, 255, 85],
  'b': [85, 255, 255],
  'c': [255, 85, 85],
  'd': [255, 85, 255],
  'e': [255, 255, 85],
  'f': [255, 255, 255]
};

const MC_FORMATS = {
  l: `${ESC}[1m`,
  o: `${ESC}[3m`,
  n: `${ESC}[4m`,
  m: `${ESC}[9m`,
  r: RESET
};

const LEVEL_COLORS = {
  error: [255, 90, 90],
  fatal: [255, 90, 90],
  warn: [255, 200, 60],
  warning: [255, 200, 60],
  success: [85, 255, 85],
  debug: [140, 140, 140],
  trace: [120, 120, 120],
  system: [120, 180, 255],
  info: [220, 220, 220],
  log: [220, 220, 220]
};

// Brighter colors for the "[Server thread/INFO]:" tag itself.
const TAG_COLORS = {
  error: [255, 90, 90],
  warn: [255, 200, 60],
  debug: [140, 140, 140],
  success: [85, 255, 85],
  info: [90, 200, 255]
};

// [14:30:09] [Server thread/INFO]: message
const TAGGED_LINE = /^(\[\d{1,2}:\d{2}:\d{2}(?:[.,]\d+)?\])\s*(\[[^\]]+\]:)\s*([\s\S]*)$/;

function rgb(r, g, b) {
  return `${ESC}[38;2;${r};${g};${b}m`;
}

function colorForLevel(level) {
  const c = LEVEL_COLORS[String(level || 'info').toLowerCase()] || LEVEL_COLORS.info;
  return rgb(c[0], c[1], c[2]);
}

function tagColorForLevel(level) {
  const c = TAG_COLORS[String(level || 'info').toLowerCase()] || TAG_COLORS.info;
  return rgb(c[0], c[1], c[2]);
}

class TerminalColorParser {
  /**
   * Convert literal "[38;2;255;85;85m" text (ESC missing) into real ANSI.
   * Sequences already prefixed with ESC are left untouched.
   */
  normalizeAnsi(text) {
    return String(text ?? '').replace(
      /(^|[^\x1b])\[([0-9]{1,3}(?:;[0-9]{1,3})*)m/g,
      (match, prefix, codes) => `${prefix}${ESC}[${codes}m`
    );
  }

  /**
   * Convert Minecraft section codes (colors, formats and §x/§# hex) to ANSI.
   */
  convertMinecraftCodes(text) {
    let out = String(text ?? '');

    out = out.replace(/§x((?:§[0-9a-fA-F]){6})/g, (match, seq) => {
      const hex = seq.replace(/§/g, '');
      return rgb(
        parseInt(hex.slice(0, 2), 16),
        parseInt(hex.slice(2, 4), 16),
        parseInt(hex.slice(4, 6), 16)
      );
    });

    out = out.replace(/§#([0-9a-fA-F]{6})/g, (match, hex) => rgb(
      parseInt(hex.slice(0, 2), 16),
      parseInt(hex.slice(2, 4), 16),
      parseInt(hex.slice(4, 6), 16)
    ));

    out = out.replace(/§([0-9a-fk-or])/gi, (match, code) => {
      const key = code.toLowerCase();
      if (MC_COLORS[key]) {
        const c = MC_COLORS[key];
        return rgb(c[0], c[1], c[2]);
      }
      return MC_FORMATS[key] || '';
    });

    return out;
  }

  /**
   * Normalize a log line and add colors when it does not carry any.
   * Existing ANSI colors (real or literal) are preserved as-is.
   */
  processLine(line, level) {
    if (line === null || line === undefined) return '';

    const original = String(line).replace(/\r$/, '');
    const hadAnsi = original.includes(`${ESC}[`);

    let text = this.normalizeAnsi(original);
    text = this.convertMinecraftCodes(text);

    // Colors produced by §/literal codes need a reset to avoid bleeding
    // into the next line; lines with their own ANSI are passed through.
    if (text.includes(`${ESC}[`)) return hadAnsi ? text : `${text}${RESET}`;

    const resolved = String(level || '').toLowerCase() || this.detectLogLevel(text);
    const tagged = TAGGED_LINE.exec(text);

    if (tagged) {
      const [, time, tag, message] = tagged;
      const tagLevel = this.detectLogLevel(tag) || resolved;
      const bodyLevel = ['error', 'warn', 'debug', 'success'].includes(tagLevel) ? tagLevel : 'info';
      return `${rgb(130, 130, 130)}${time}${RESET} ${tagColorForLevel(tagLevel)}${tag}${RESET} ${colorForLevel(bodyLevel)}${message}${RESET}`;
    }

    return `${colorForLevel(resolved)}${text}${RESET}`;
  }

  stripColors(line) {
    if (!line) return '';
    let cleaned = String(line);
    cleaned = cleaned.replace(/\x1b\[[0-9;?]*[A-Za-z]/g, '');
    cleaned = cleaned.replace(/\[[0-9]{1,3}(?:;[0-9]{1,3})*m/g, '');
    cleaned = cleaned.replace(/§x(?:§[0-9a-fA-F]){6}/g, '');
    cleaned = cleaned.replace(/§#[0-9a-fA-F]{6}/g, '');
    cleaned = cleaned.replace(/§[0-9a-fk-or]/gi, '');
    return cleaned.trim();
  }

  detectLogLevel(text) {
    if (!text) return 'info';
    const upper = String(text).toUpperCase();
    if (upper.includes('ERROR') || upper.includes('FATAL') || upper.includes('EXCEPTION')) return 'error';
    if (upper.includes('WARN')) return 'warn';
    if (upper.includes('DEBUG') || upper.includes('TRACE')) return 'debug';
    if (upper.includes('DONE') || upper.includes('LOADED') || upper.includes('SUCCESS')) return 'success';
    return 'info';
  }

  normalizeForDedup(line) {
    let normalized = this.stripColors(line);

    normalized = normalized.replace(/^\[\d{1,2}:\d{2}:\d{2}(?:[.,]\d+)?[^\]]*\]\s*/i, '');
    normalized = normalized.replace(/^\[\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}[^\]]*\]\s*/i, '');
    normalized = normalized.replace(/^\[[^\]]*\/[A-Z]+\]:\s*/i, '');
    normalized = normalized.replace(/^\[[A-Z]+\]:\s*/i, '');
    normalized = normalized.replace(/\s+/g, ' ');

    return normalized.trim().toLowerCase();
  }

  hashLine(line) {
    let hash = 0;
    const str = String(line ?? '');
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << 5) - hash) + str.charCodeAt(i);
      hash = hash & hash;
    }
    return Math.abs(hash);
  }
}

module.exports = new TerminalColorParser();
