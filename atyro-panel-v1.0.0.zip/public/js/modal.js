/**
 * ================================================
 * Custom Modal System - Beautiful & Reusable
 * Replaces all browser-native dialogs (alert, confirm, prompt)
 * Supports: success, error, warning, info, confirmation
 * Features: Async/await, smooth animations, responsive design
 * ================================================
 */

const Modal = {
  config: {
    animationDuration: 300,
    defaultWidth: 'clamp(320px, 90vw, 500px)',
    zIndex: 9999,
  },

  _createModalElement() {
    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop';
    backdrop.setAttribute('role', 'presentation');

    const modal = document.createElement('div');
    modal.className = 'modal-container';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');

    const content = document.createElement('div');
    content.className = 'modal-content';
    modal.appendChild(content);

    let wrapper = document.getElementById('modal-root');
    if (!wrapper) {
      wrapper = document.createElement('div');
      wrapper.id = 'modal-root';
      document.body.appendChild(wrapper);
    }

    wrapper.appendChild(backdrop);
    wrapper.appendChild(modal);

    return { backdrop, modal, content };
  },

  async alert(message, type = 'info', title = null) {
    return new Promise((resolve) => {
      const { backdrop, modal, content } = this._createModalElement();

      const iconMap = {
        success: { icon: 'fas fa-check-circle', color: 'success' },
        error: { icon: 'fas fa-exclamation-circle', color: 'danger' },
        warning: { icon: 'fas fa-exclamation-triangle', color: 'warning' },
        info: { icon: 'fas fa-info-circle', color: 'info' },
      };

      const { icon, color } = iconMap[type] || iconMap.info;
      const dialogTitle =
        title ||
        (type === 'success' ? 'Success' :
         type === 'error' ? 'Error' :
         type === 'warning' ? 'Warning' : 'Information');

      content.innerHTML = `
        <div class="modal-header">
          <div class="modal-icon modal-icon-${color}">
            <i class="${icon}"></i>
          </div>
          <div class="modal-title-group">
            <h2 class="modal-title">${this._escapeHtml(dialogTitle)}</h2>
          </div>
        </div>
        <div class="modal-body">
          <p class="modal-message">${this._escapeHtml(message)}</p>
        </div>
        <div class="modal-footer">
          <button class="btn btn-primary modal-btn-ok" style="width:100%;">OK</button>
        </div>
      `;

      modal.style.zIndex = this.config.zIndex;
      backdrop.style.zIndex = this.config.zIndex - 1;

      this._showModal(modal, backdrop);

      const btnOk = content.querySelector('.modal-btn-ok');

      // FIX: single cleanup guard + remove keydown listener
      let closed = false;
      const onKey = (e) => {
        if (e.key === 'Escape') cleanup();
      };
      const cleanup = () => {
        if (closed) return;
        closed = true;
        document.removeEventListener('keydown', onKey);
        this._hideModal(modal, backdrop, () => {
          backdrop.remove();
          modal.remove();
          resolve();
        });
      };

      btnOk.addEventListener('click', cleanup);
      backdrop.addEventListener('click', cleanup);
      document.addEventListener('keydown', onKey);
    });
  },

  async confirm(message, options = {}) {
    const {
      title = 'Confirm',
      confirmText = 'Confirm',
      cancelText = 'Cancel',
      confirmColor = 'primary',
      isDangerous = false,
    } = options;

    return new Promise((resolve) => {
      const { backdrop, modal, content } = this._createModalElement();
      const buttonColor = isDangerous ? 'danger' : confirmColor;

      content.innerHTML = `
        <div class="modal-header">
          <div class="modal-icon modal-icon-warning">
            <i class="fas fa-question-circle"></i>
          </div>
          <div class="modal-title-group">
            <h2 class="modal-title">${this._escapeHtml(title)}</h2>
          </div>
        </div>
        <div class="modal-body">
          <p class="modal-message">${this._escapeHtml(message)}</p>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary modal-btn-cancel" style="flex:1;">
            <i class="fas fa-times"></i> ${this._escapeHtml(cancelText)}
          </button>
          <button class="btn btn-${buttonColor} modal-btn-confirm" style="flex:1;">
            <i class="fas fa-check"></i> ${this._escapeHtml(confirmText)}
          </button>
        </div>
      `;

      modal.style.zIndex = this.config.zIndex;
      backdrop.style.zIndex = this.config.zIndex - 1;

      this._showModal(modal, backdrop);

      const btnConfirm = content.querySelector('.modal-btn-confirm');
      const btnCancel = content.querySelector('.modal-btn-cancel');

      let closed = false;
      const onKey = (e) => {
        if (e.key === 'Escape') cleanup(false);
      };
      const cleanup = (result) => {
        if (closed) return;
        closed = true;
        document.removeEventListener('keydown', onKey);
        this._hideModal(modal, backdrop, () => {
          backdrop.remove();
          modal.remove();
          resolve(result);
        });
      };

      btnConfirm.addEventListener('click', () => cleanup(true));
      btnCancel.addEventListener('click', () => cleanup(false));
      backdrop.addEventListener('click', () => cleanup(false));
      document.addEventListener('keydown', onKey);
    });
  },

  async prompt(message, defaultValue = '', options = {}) {
    const {
      title = 'Enter Value',
      inputType = 'text',
      placeholder = '',
      confirmText = 'OK',
      cancelText = 'Cancel',
      validate = null,
    } = options;

    return new Promise((resolve) => {
      const { backdrop, modal, content } = this._createModalElement();

      content.innerHTML = `
        <div class="modal-header">
          <div class="modal-icon modal-icon-info">
            <i class="fas fa-pen-to-square"></i>
          </div>
          <div class="modal-title-group">
            <h2 class="modal-title">${this._escapeHtml(title)}</h2>
          </div>
        </div>
        <div class="modal-body">
          <p class="modal-message">${this._escapeHtml(message)}</p>
          <div class="form-group" style="margin-top: 16px;">
            <input type="${inputType}" class="form-control modal-input"
                   placeholder="${this._escapeHtml(placeholder)}"
                   value="${this._escapeHtml(defaultValue)}"
                   autocomplete="off">
            <div class="modal-error" style="display:none; color:var(--danger); font-size:0.8rem; margin-top:6px;"></div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary modal-btn-cancel" style="flex:1;">
            <i class="fas fa-times"></i> ${this._escapeHtml(cancelText)}
          </button>
          <button class="btn btn-primary modal-btn-confirm" style="flex:1;">
            <i class="fas fa-check"></i> ${this._escapeHtml(confirmText)}
          </button>
        </div>
      `;

      modal.style.zIndex = this.config.zIndex;
      backdrop.style.zIndex = this.config.zIndex - 1;

      this._showModal(modal, backdrop);

      const input = content.querySelector('.modal-input');
      const btnConfirm = content.querySelector('.modal-btn-confirm');
      const btnCancel = content.querySelector('.modal-btn-cancel');
      const errorMsg = content.querySelector('.modal-error');

      setTimeout(() => input.focus(), 100);
      input.select();

      let closed = false;
      const cleanup = (result) => {
        if (closed) return;
        closed = true;
        this._hideModal(modal, backdrop, () => {
          backdrop.remove();
          modal.remove();
          resolve(result);
        });
      };

      const handleConfirm = () => {
        const value = input.value;
        if (validate) {
          const validation = validate(value);
          if (validation.valid === false) {
            errorMsg.textContent = validation.message || 'Invalid input';
            errorMsg.style.display = 'block';
            input.focus();
            return;
          }
        }
        cleanup(value);
      };

      btnConfirm.addEventListener('click', handleConfirm);
      btnCancel.addEventListener('click', () => cleanup(null));
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') handleConfirm();
        if (e.key === 'Escape') cleanup(null);
      });
      backdrop.addEventListener('click', () => cleanup(null));
    });
  },

  async custom(options = {}) {
    const {
      title = 'Dialog',
      message = '',
      content = '',
      icon = 'fas fa-info-circle',
      iconColor = 'info',
      buttons = [{ text: 'OK', color: 'primary', callback: null }],
    } = options;

    return new Promise((resolve) => {
      // FIX: original destructured `contentEl` which doesn't exist -> use `content` from helper
      const { backdrop, modal, content: contentEl } = this._createModalElement();

      let buttonsHtml = '';
      buttons.forEach((btn, idx) => {
        buttonsHtml += `
          <button class="btn btn-${btn.color || 'primary'} modal-btn-custom" data-index="${idx}" style="flex:1;">
            ${btn.icon ? `<i class="${btn.icon}"></i>` : ''} ${this._escapeHtml(btn.text)}
          </button>
        `;
      });

      contentEl.innerHTML = `
        <div class="modal-header">
          <div class="modal-icon modal-icon-${iconColor}">
            <i class="${icon}"></i>
          </div>
          <div class="modal-title-group">
            <h2 class="modal-title">${this._escapeHtml(title)}</h2>
          </div>
        </div>
        <div class="modal-body">
          ${message ? `<p class="modal-message">${this._escapeHtml(message)}</p>` : ''}
          ${content ? `<div class="modal-custom-content">${content}</div>` : ''}
        </div>
        <div class="modal-footer">
          ${buttonsHtml}
        </div>
      `;

      modal.style.zIndex = this.config.zIndex;
      backdrop.style.zIndex = this.config.zIndex - 1;

      this._showModal(modal, backdrop);

      let closed = false;
      const onKey = (e) => {
        if (e.key === 'Escape') cleanup(null);
      };
      const cleanup = (result) => {
        if (closed) return;
        closed = true;
        document.removeEventListener('keydown', onKey);
        this._hideModal(modal, backdrop, () => {
          backdrop.remove();
          modal.remove();
          resolve(result);
        });
      };

      const customBtns = contentEl.querySelectorAll('.modal-btn-custom');
      customBtns.forEach((btn, idx) => {
        btn.addEventListener('click', () => {
          if (buttons[idx].callback && buttons[idx].callback() === false) return;
          cleanup(idx);
        });
      });

      backdrop.addEventListener('click', () => cleanup(null));
      document.addEventListener('keydown', onKey);
    });
  },

  showLoading(message = 'Loading...', title = 'Please Wait') {
    const { backdrop, modal, content } = this._createModalElement();

    content.innerHTML = `
      <div class="modal-header">
        <div class="modal-icon modal-icon-info">
          <i class="fas fa-spinner fa-spin"></i>
        </div>
        <div class="modal-title-group">
          <h2 class="modal-title">${this._escapeHtml(title)}</h2>
        </div>
      </div>
      <div class="modal-body">
        <p class="modal-message">${this._escapeHtml(message)}</p>
      </div>
    `;

    modal.style.zIndex = this.config.zIndex;
    backdrop.style.zIndex = this.config.zIndex - 1;
    backdrop.style.pointerEvents = 'none';

    this._showModal(modal, backdrop);

    return {
      update: (newMessage) => {
        const msgEl = content.querySelector('.modal-message');
        if (msgEl) msgEl.textContent = newMessage;
      },
      close: () => {
        this._hideModal(modal, backdrop, () => {
          backdrop.remove();
          modal.remove();
        });
      },
    };
  },

  progress(options = {}) {
    const {
      title = 'Processing…',
      message = 'Please wait',
      icon = 'fas fa-tasks',
      iconColor = 'info',
    } = options;

    const { backdrop, modal, content } = this._createModalElement();

    content.innerHTML = `
      <div class="modal-header">
        <div class="modal-icon modal-icon-${iconColor}">
          <i class="${icon}"></i>
        </div>
        <div class="modal-title-group">
          <h2 class="modal-title">${this._escapeHtml(title)}</h2>
        </div>
      </div>
      <div class="modal-body">
        <p class="modal-message">${this._escapeHtml(message)}</p>
        <div class="modal-progress">
          <div class="modal-progress-bar">
            <div class="modal-progress-fill"></div>
          </div>
          <div class="modal-progress-row">
            <span class="modal-progress-status"></span>
            <span class="modal-progress-percent">0%</span>
          </div>
        </div>
      </div>
    `;

    modal.style.zIndex = this.config.zIndex;
    backdrop.style.zIndex = this.config.zIndex - 1;
    backdrop.style.pointerEvents = 'none';

    this._showModal(modal, backdrop);

    const fill = content.querySelector('.modal-progress-fill');
    const pctEl = content.querySelector('.modal-progress-percent');
    const statusEl = content.querySelector('.modal-progress-status');

    let closed = false;
    return {
      ui: { bar: fill, pct: pctEl, status: statusEl },
      update(data = {}) {
        if (closed) return;
        const percent = Number(data.percent);
        if (Number.isFinite(percent) && Number(data.total) > 0) {
          fill.classList.remove('indeterminate');
          fill.style.width = Math.max(0, Math.min(100, percent)) + '%';
          pctEl.textContent = Math.round(percent) + '%';
        } else {
          fill.classList.add('indeterminate');
          pctEl.textContent = '';
        }
        if (data.message) statusEl.textContent = data.message;
      },
      close() {
        if (closed) return;
        closed = true;
        this._hideModal(modal, backdrop, () => {
          backdrop.remove();
          modal.remove();
        });
      },
    };
  },

  _showModal(modal, backdrop) {
    void modal.offsetWidth;
    backdrop.classList.add('active');
    modal.classList.add('active');
    
    // Lock scrolling for all modals (works for both admin and public pages)
    document.documentElement.style.overflow = 'hidden';
    document.body.style.overflow = 'hidden';
    
    // Store previous scroll position for restoration
    const scrollY = window.scrollY;
    document.documentElement.setAttribute('data-scroll-y', scrollY);
  },

  _hideModal(modal, backdrop, callback) {
    backdrop.classList.remove('active');
    modal.classList.remove('active');

    setTimeout(() => {
      const activeModals = document.querySelectorAll('.modal-container.active');
      if (activeModals.length === 0) {
        document.documentElement.style.overflow = '';
        document.body.style.overflow = '';
        
        // Restore scroll position if stored
        const scrollY = document.documentElement.getAttribute('data-scroll-y');
        if (scrollY) {
          window.scrollY = parseInt(scrollY);
          document.documentElement.removeAttribute('data-scroll-y');
        }
      }
      if (callback) callback();
    }, this.config.animationDuration);
  },

  _escapeHtml(text) {
    if (typeof text !== 'string') return text;
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
    return text.replace(/[&<>"']/g, (m) => map[m]);
  },
};

/**
 * Global convenience functions (replaces browser natives)
 */
window.alert = async function (message) {
  await Modal.alert(message, 'info');
};

window.confirm = async function (message) {
  return await Modal.confirm(message, {
    title: 'Confirm',
    confirmText: 'OK',
    cancelText: 'Cancel',
  });
};

window.prompt = async function (message, defaultValue = '') {
  return await Modal.prompt(message, defaultValue || '', {
    title: 'Prompt',
    placeholder: 'Enter value...',
  });
};

/**
 * ================================================
 * Toast Notification System
 * ================================================
 */
const Toast = {
  container: null,

  _init() {
    if (!this.container) {
      this.container = document.createElement('div');
      this.container.id = 'toast-container';
      this.container.style.cssText = `
        position: fixed;
        top: 24px;
        right: 24px;
        z-index: ${Modal.config.zIndex + 100};
        max-width: 400px;
        pointer-events: none;
      `;
      document.body.appendChild(this.container);
    }
  },

  show(message, type = 'info', duration = 3500) {
    this._init();

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    const iconMap = {
      success: 'fas fa-check-circle',
      error: 'fas fa-exclamation-circle',
      warning: 'fas fa-exclamation-triangle',
      info: 'fas fa-info-circle',
    };
    const icon = iconMap[type] || iconMap.info;

    toast.innerHTML = `
      <div class="toast-content">
        <i class="toast-icon ${icon}"></i>
        <span class="toast-message">${this._escapeHtml(message)}</span>
      </div>
      <button class="toast-close" aria-label="Close">
        <i class="fas fa-times"></i>
      </button>
    `;

    toast.style.pointerEvents = 'auto';
    this.container.appendChild(toast);

    void toast.offsetWidth;
    toast.classList.add('show');

    const closeBtn = toast.querySelector('.toast-close');
    const remove = () => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    };

    closeBtn.addEventListener('click', remove);
    if (duration > 0) setTimeout(remove, duration);

    return { close: remove };
  },

  success: (msg, duration) => Toast.show(msg, 'success', duration),
  error: (msg, duration) => Toast.show(msg, 'error', duration),
  warning: (msg, duration) => Toast.show(msg, 'warning', duration),
  info: (msg, duration) => Toast.show(msg, 'info', duration),

  _escapeHtml(text) {
    if (typeof text !== 'string') return text;
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
    return text.replace(/[&<>"']/g, (m) => map[m]);
  },
};

window.showToast = function (message, type = 'info', duration = 3500) {
  Toast.show(message, type, duration);
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { Modal, Toast };
}